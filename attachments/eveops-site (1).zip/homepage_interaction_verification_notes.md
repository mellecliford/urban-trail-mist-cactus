# Homepage Interaction Verification Notes

## Public quick-contact modal

On 27 August 2026, the public English homepage was reviewed in the browser. The new **Talk to eveOps Group** trigger is visible directly below the hero introduction. Opening it showed a focused dialog with the intended minimal required inputs: name, email, and a concise message. The dialog exposed a visible close control and the expected English routing copy. It was closed without form submission so no operational lead or email record was created during verification.

The French homepage was also reviewed. Its **Parler à eveOps Group** trigger opened the same focused pattern with French labels, guidance, and submit text. The modal’s top close-control label is localized to match the active public language. No browser form submission was made.

Following the localized close-control update, the French modal was reopened in the browser. Its accessible control exposes **Fermer la fenêtre de contact** and the visual label **Fermer**, alongside the expected French name, email, message, and submit controls. This completed the bilingual public interaction inspection without generating an artificial enquiry.

## PDF-download feedback

The homepage retains distinct English and French public profile URLs. Each interaction now starts an in-place loading state, reports an accessible live status, and then presents a localized success notification that the browser has begun preparing the requested edition. Because attachment completion is browser-managed and cannot be safely synthesized here, verification covers the component contract, public visible anchor behavior, and the existing direct attachment endpoint checks.

The English control was also activated during browser review. The browser automation remained on the source page and its delayed state capture occurred after the brief handoff notification had reset; it therefore did not preserve a screenshot of the transient loading/success state. The state is nevertheless deterministically covered in the public interaction contract test, including its English and French text, accessible live-status target, loading class, and spinner animation.

The download interaction was subsequently strengthened so its success state follows a completed same-origin PDF retrieval, a non-empty file check, and the browser blob-download handoff; failed or empty responses now show an explicit retry state and error notification. The automation harness did not expose a corresponding resource-timing record after its simulated click, so it cannot independently attest to this browser-managed transfer. Unit tests cover successful French attachment filename handling, non-success HTTP responses, and empty-file rejection; the existing direct public endpoint checks remain in place.
