import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

type RuntimeConfig = { databaseUrl?: string; configuredAt?: string };
let loaded = false;
let runtimeConfig: RuntimeConfig = {};

const configPath = () => process.env.EVEOPS_RUNTIME_CONFIG_PATH || "/var/lib/eveops/runtime-config.json";

export async function hydrateRuntimeConfig() {
  if (loaded) return runtimeConfig;
  loaded = true;
  try { runtimeConfig = JSON.parse(await readFile(configPath(), "utf8")) as RuntimeConfig; } catch { runtimeConfig = {}; }
  return runtimeConfig;
}

export function getRuntimeDatabaseUrl() { return runtimeConfig.databaseUrl; }
export function hasRuntimeDatabaseUrl() { return Boolean(runtimeConfig.databaseUrl); }

export async function persistRuntimeDatabaseUrl(databaseUrl: string) {
  runtimeConfig = { databaseUrl, configuredAt: new Date().toISOString() };
  const destination = configPath();
  await mkdir(path.dirname(destination), { recursive: true, mode: 0o700 });
  await writeFile(destination, JSON.stringify(runtimeConfig, null, 2), { encoding: "utf8", mode: 0o600 });
}
