import { describe, expect, it } from "vitest";
import { buildCompanyProfilePdf } from "./companyProfilePdf";

describe("eveOps Group detailed company profile PDF", () => {
  it("creates substantial reader-ready English and French corporate profiles", async () => {
    const [englishPdf, frenchPdf] = await Promise.all([buildCompanyProfilePdf(), buildCompanyProfilePdf("fr")]);

    expect(englishPdf.subarray(0, 4).toString("utf8")).toBe("%PDF");
    expect(frenchPdf.subarray(0, 4).toString("utf8")).toBe("%PDF");
    expect(englishPdf.length).toBeGreaterThan(40_000);
    expect(frenchPdf.length).toBeGreaterThan(40_000);
    expect((englishPdf.toString("latin1").match(/\/Type \/Page\b/g) ?? []).length).toBe(13);
    expect((frenchPdf.toString("latin1").match(/\/Type \/Page\b/g) ?? []).length).toBe(13);
    expect(englishPdf.toString("latin1")).toContain("eveOps Group | Detailed Company Profile EN");
    expect(frenchPdf.toString("latin1")).toContain("eveOps Group");
    expect(englishPdf.toString("latin1")).toContain("detailed company profile; Unity; EveDev; English edition");
    expect(frenchPdf.equals(englishPdf)).toBe(false);
  });
});
