import { and, count, desc, eq, gte, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { administratorSecurity, auditLogs, capabilityEvents, customers, emailLogs, emailSettings, leads, media, passwordAccounts, projects, serviceRequests, systemSettings, type InsertUser, type User, users } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { getRuntimeDatabaseUrl } from "./runtimeConfig";

let _db: ReturnType<typeof drizzle> | null = null;
let connectedUrl = "";

export async function getDb() {
  const databaseUrl = process.env.DATABASE_URL || getRuntimeDatabaseUrl();
  if (databaseUrl && (!_db || connectedUrl !== databaseUrl)) {
    try { _db = drizzle(databaseUrl); connectedUrl = databaseUrl; } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; connectedUrl = ""; }
  }
  return _db;
}

async function requiredDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable.");
  return db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId, lastSignedIn: new Date() };
  const updateSet: Record<string, unknown> = { lastSignedIn: new Date() };
  (["name", "email", "loginMethod"] as const).forEach(field => { if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; } });
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return result[0]; }
export async function getPasswordSessionUser(userId: number) { const db = await getDb(); if (!db) return undefined; const rows = await db.select({ user: users, account: passwordAccounts, customerStatus: customers.status }).from(passwordAccounts).innerJoin(users, eq(passwordAccounts.userId, users.id)).leftJoin(customers, eq(customers.userId, users.id)).where(eq(passwordAccounts.userId, userId)).limit(1); const row = rows[0]; if (!row || row.customerStatus === "disabled") return undefined; return row.user; }
export async function getPasswordAccountByEmail(email: string) { const db = await requiredDb(); const rows = await db.select({ account: passwordAccounts, user: users, customerStatus: customers.status }).from(passwordAccounts).innerJoin(users, eq(passwordAccounts.userId, users.id)).leftJoin(customers, eq(customers.userId, users.id)).where(eq(passwordAccounts.email, email)).limit(1); return rows[0]; }
export async function getPasswordAccountByUserId(userId: number) { const db = await requiredDb(); const rows = await db.select({ account: passwordAccounts, user: users, customerStatus: customers.status }).from(passwordAccounts).innerJoin(users, eq(passwordAccounts.userId, users.id)).leftJoin(customers, eq(customers.userId, users.id)).where(eq(passwordAccounts.userId, userId)).limit(1); return rows[0]; }
export async function hasAdministrator() { const db = await requiredDb(); const rows = await db.select({ role: users.role }).from(users).limit(100); return rows.some(row => row.role === "admin" || row.role === "super_admin"); }
export async function createPasswordAccount(input: { name: string; email: string; passwordHash: string; role: "customer" | "admin" | "super_admin"; createCustomer: boolean; verificationTokenHash?: string; verificationExpiresAt?: Date }) { const db = await requiredDb(); return db.transaction(async tx => { const existing = await tx.select({ id: passwordAccounts.id }).from(passwordAccounts).where(eq(passwordAccounts.email, input.email)).limit(1); if (existing[0]) throw new Error("An account already exists for this email address."); const [userResult] = await tx.insert(users).values({ openId: `password:${crypto.randomUUID()}`, name: input.name, email: input.email, loginMethod: "password", role: input.role, lastSignedIn: new Date() }); const userId = Number(userResult.insertId); const [accountResult] = await tx.insert(passwordAccounts).values({ userId, email: input.email, passwordHash: input.passwordHash, verificationTokenHash: input.verificationTokenHash ?? null, verificationExpiresAt: input.verificationExpiresAt ?? null }); if (input.createCustomer) await tx.insert(customers).values({ userId, name: input.name, email: input.email, status: "active" }); const rows = await tx.select({ account: passwordAccounts, user: users }).from(passwordAccounts).innerJoin(users, eq(passwordAccounts.userId, users.id)).where(eq(passwordAccounts.id, Number(accountResult.insertId))).limit(1); return rows[0]!; }); }
export async function createCustomerPasswordAccount(input: { name: string; email: string; passwordHash: string; verificationTokenHash?: string; verificationExpiresAt?: Date }) { return createPasswordAccount({ ...input, role: "customer", createCustomer: true }); }
export async function markPasswordAccountLogin(userId: number) { const db = await requiredDb(); const now = new Date(); await Promise.all([db.update(passwordAccounts).set({ lastPasswordLoginAt: now }).where(eq(passwordAccounts.userId, userId)), db.update(users).set({ lastSignedIn: now }).where(eq(users.id, userId))]); }
export async function verifyPasswordAccount(tokenHash: string) { const db = await requiredDb(); const rows = await db.select().from(passwordAccounts).where(eq(passwordAccounts.verificationTokenHash, tokenHash)).limit(1); const account = rows[0]; if (!account || !account.verificationExpiresAt || account.verificationExpiresAt.getTime() < Date.now()) return undefined; await db.update(passwordAccounts).set({ emailVerified: true, verificationTokenHash: null, verificationExpiresAt: null }).where(eq(passwordAccounts.id, account.id)); const usersFound = await db.select().from(users).where(eq(users.id, account.userId)).limit(1); return usersFound[0]; }
export async function getCustomerVerificationRequired() { const setting = await getSystemSetting("customer_email_verification_required"); return setting?.value === "true"; }
export async function setCustomerVerificationRequired(required: boolean, userId: number) { await saveSystemSetting("customer_email_verification_required", String(required), userId); }
export async function verifyExistingPasswordAccounts() { const db = await requiredDb(); await db.update(passwordAccounts).set({ emailVerified: true, verificationTokenHash: null, verificationExpiresAt: null }).where(eq(passwordAccounts.emailVerified, false)); }
export async function listPasswordAccounts(limit = 100) { const db = await requiredDb(); return db.select({ id: passwordAccounts.id, email: passwordAccounts.email, emailVerified: passwordAccounts.emailVerified, createdAt: passwordAccounts.createdAt, lastPasswordLoginAt: passwordAccounts.lastPasswordLoginAt, name: users.name, customerStatus: customers.status }).from(passwordAccounts).innerJoin(users, eq(passwordAccounts.userId, users.id)).leftJoin(customers, eq(customers.userId, users.id)).orderBy(desc(passwordAccounts.createdAt)).limit(limit); }
export async function saveAdministratorPasswordReset(accountId: number, tokenHash: string, expiresAt: Date) { const db = await requiredDb(); await db.update(passwordAccounts).set({ passwordResetTokenHash: tokenHash, passwordResetExpiresAt: expiresAt }).where(eq(passwordAccounts.id, accountId)); }
export async function completeAdministratorPasswordReset(tokenHash: string, passwordHash: string) { const db = await requiredDb(); const rows = await db.select({ account: passwordAccounts, user: users }).from(passwordAccounts).innerJoin(users, eq(passwordAccounts.userId, users.id)).where(eq(passwordAccounts.passwordResetTokenHash, tokenHash)).limit(1); const row = rows[0]; if (!row || !row.account.passwordResetExpiresAt || row.account.passwordResetExpiresAt.getTime() < Date.now() || !["admin", "super_admin"].includes(row.user.role)) return undefined; await db.update(passwordAccounts).set({ passwordHash, passwordResetTokenHash: null, passwordResetExpiresAt: null }).where(eq(passwordAccounts.id, row.account.id)); return row.user; }
export async function getAdministratorSecurity(userId: number) { const db = await requiredDb(); const rows = await db.select().from(administratorSecurity).where(eq(administratorSecurity.userId, userId)).limit(1); return rows[0]; }
export async function savePendingAdministratorTotp(userId: number, encryptedTotpSecret: string) { const db = await requiredDb(); await db.insert(administratorSecurity).values({ userId, encryptedTotpSecret, totpEnabled: false, recoveryCodeHashes: null }).onDuplicateKeyUpdate({ set: { encryptedTotpSecret, totpEnabled: false, recoveryCodeHashes: null } }); }
export async function enableAdministratorTotp(userId: number, recoveryCodeHashes: string[]) { const db = await requiredDb(); await db.update(administratorSecurity).set({ totpEnabled: true, recoveryCodeHashes: JSON.stringify(recoveryCodeHashes) }).where(eq(administratorSecurity.userId, userId)); }
export async function disableAdministratorTotp(userId: number) { const db = await requiredDb(); await db.update(administratorSecurity).set({ encryptedTotpSecret: null, totpEnabled: false, recoveryCodeHashes: null }).where(eq(administratorSecurity.userId, userId)); }
export async function consumeAdministratorRecoveryCode(userId: number, codeHash: string) { const security = await getAdministratorSecurity(userId); const hashes = security?.recoveryCodeHashes ? JSON.parse(security.recoveryCodeHashes) as string[] : []; if (!hashes.includes(codeHash)) return false; const db = await requiredDb(); await db.update(administratorSecurity).set({ recoveryCodeHashes: JSON.stringify(hashes.filter(hash => hash !== codeHash)) }).where(eq(administratorSecurity.userId, userId)); return true; }

export type LeadInput = { name: string; company?: string; email: string; phone?: string; country?: string; division: "unity" | "edevops" | "group"; service?: string; estimatedVolume?: string; deadline?: string; preferredCommunication?: string; message: string; attributionChannel?: "direct" | "capability_cta"; attributedCapability?: string; };

export async function createLead(input: LeadInput) {
  const db = await requiredDb();
  const [result] = await db.insert(leads).values({ ...input, company: input.company || null, phone: input.phone || null, country: input.country || null, service: input.service || null, estimatedVolume: input.estimatedVolume || null, deadline: input.deadline || null, preferredCommunication: input.preferredCommunication || null, attributedCapability: input.attributedCapability || null, attributionChannel: input.attributionChannel ?? "direct", source: "public_form" });
  const created = await db.select().from(leads).where(eq(leads.id, result.insertId)).limit(1);
  return created[0]!;
}

export async function listLeads(limit = 50) { const db = await requiredDb(); return db.select().from(leads).orderBy(desc(leads.createdAt)).limit(limit); }

export async function dashboardOverview() {
  const db = await requiredDb();
  const [[leadCount], [customerCount], [projectCount], [requestCount], recent] = await Promise.all([
    db.select({ value: count() }).from(leads), db.select({ value: count() }).from(customers), db.select({ value: count() }).from(projects), db.select({ value: count() }).from(serviceRequests), db.select().from(leads).orderBy(desc(leads.createdAt)).limit(6),
  ]);
  return { counts: { leads: leadCount?.value ?? 0, customers: customerCount?.value ?? 0, projects: projectCount?.value ?? 0, requests: requestCount?.value ?? 0 }, recent };
}

export async function getLatestEmailSettings() { const db = await requiredDb(); const result = await db.select().from(emailSettings).orderBy(desc(emailSettings.updatedAt)).limit(1); return result[0]; }

export async function saveEmailSettings(input: { smtpHost: string; smtpPort: number; smtpUsername: string; encryptedPassword?: string; secure: boolean; fromName: string; fromEmail: string; replyTo: string; isEnabled: boolean; updatedByUserId: number; }) {
  const db = await requiredDb(); const existing = await getLatestEmailSettings();
  const values = { provider: "smtp" as const, smtpHost: input.smtpHost, smtpPort: input.smtpPort, smtpUsername: input.smtpUsername, secure: input.secure, fromName: input.fromName, fromEmail: input.fromEmail, replyTo: input.replyTo, isEnabled: input.isEnabled, updatedByUserId: input.updatedByUserId, ...(input.encryptedPassword ? { encryptedPassword: input.encryptedPassword } : {}) };
  if (existing) { await db.update(emailSettings).set(values).where(eq(emailSettings.id, existing.id)); }
  else { await db.insert(emailSettings).values(values); }
  return getLatestEmailSettings();
}

export async function createEmailLog(input: { recipient: string; subject: string; status: "queued" | "sent" | "failed"; leadId?: number; errorMessage?: string }) { const db = await requiredDb(); const [result] = await db.insert(emailLogs).values({ ...input, leadId: input.leadId ?? null, errorMessage: input.errorMessage ?? null, sentAt: input.status === "sent" ? new Date() : null }); return result.insertId; }

export async function updateEmailLog(id: number, input: { status: "sent" | "failed"; errorMessage?: string }) { const db = await requiredDb(); await db.update(emailLogs).set({ status: input.status, errorMessage: input.errorMessage ?? null, sentAt: input.status === "sent" ? new Date() : null }).where(eq(emailLogs.id, id)); }

export async function recordAudit(input: { actorUserId?: number; action: string; targetType: string; targetId?: string; metadata?: string }) { const db = await requiredDb(); await db.insert(auditLogs).values({ actorUserId: input.actorUserId ?? null, action: input.action, targetType: input.targetType, targetId: input.targetId ?? null, metadata: input.metadata ?? null }); }

export async function getSystemSetting(key: string) { const db = await requiredDb(); const result = await db.select().from(systemSettings).where(eq(systemSettings.key, key)).limit(1); return result[0]; }
export async function saveSystemSetting(key: string, value: string, userId: number) { const db = await requiredDb(); await db.insert(systemSettings).values({ key, value, updatedByUserId: userId }).onDuplicateKeyUpdate({ set: { value, updatedByUserId: userId } }); }
export async function createMediaRecord(input: { filename: string; fileKey: string; url: string; contentType: string; byteSize: number; uploadedByUserId: number }) { const db = await requiredDb(); const [result] = await db.insert(media).values(input); const created = await db.select().from(media).where(eq(media.id, result.insertId)).limit(1); return created[0]!; }
export async function listMedia(limit = 100) { const db = await requiredDb(); return db.select().from(media).orderBy(desc(media.createdAt)).limit(limit); }
export async function getMediaById(id: number) { const db = await requiredDb(); const rows = await db.select().from(media).where(eq(media.id, id)).limit(1); return rows[0]; }
export async function deleteMediaRecord(id: number) { const db = await requiredDb(); await db.delete(media).where(eq(media.id, id)); }
export async function recordCapabilityEvent(input: { division: "unity" | "edevops"; service: string; capability: string; eventType: "brief_opened" | "template_downloaded" }) { const db = await requiredDb(); await db.insert(capabilityEvents).values(input); }
export async function listCapabilityAnalytics(input: { start?: Date; end?: Date; limit?: number } = {}) {
  const db = await requiredDb();
  const eventFilters = [input.start ? gte(capabilityEvents.createdAt, input.start) : undefined, input.end ? lte(capabilityEvents.createdAt, input.end) : undefined].filter(Boolean);
  const leadFilters = [eq(leads.attributionChannel, "capability_cta"), input.start ? gte(leads.createdAt, input.start) : undefined, input.end ? lte(leads.createdAt, input.end) : undefined].filter(Boolean);
  const [events, attributedLeads] = await Promise.all([
    db.select({
    division: capabilityEvents.division,
    service: capabilityEvents.service,
    capability: capabilityEvents.capability,
    briefOpens: sql<number>`sum(case when ${capabilityEvents.eventType} = 'brief_opened' then 1 else 0 end)`,
    templateDownloads: sql<number>`sum(case when ${capabilityEvents.eventType} = 'template_downloaded' then 1 else 0 end)`,
    total: count(),
    lastSeen: sql<Date>`max(${capabilityEvents.createdAt})`,
    }).from(capabilityEvents).where(eventFilters.length ? and(...eventFilters) : undefined).groupBy(capabilityEvents.division, capabilityEvents.service, capabilityEvents.capability).orderBy(desc(count())).limit(input.limit ?? 50),
    db.select({ division: leads.division, service: leads.service, capability: leads.attributedCapability, attributedLeads: count() }).from(leads).where(and(...leadFilters)).groupBy(leads.division, leads.service, leads.attributedCapability),
  ]);
  return events.map(event => ({ ...event, attributedLeads: attributedLeads.find(lead => lead.division === event.division && lead.service === event.service && lead.capability === event.capability)?.attributedLeads ?? 0 }));
}
export type { User };
