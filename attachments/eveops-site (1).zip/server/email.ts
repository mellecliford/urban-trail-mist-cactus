import crypto from "node:crypto";
import nodemailer from "nodemailer";
import type { EmailSettings } from "../drizzle/schema";

const encryptionSecret = process.env.JWT_SECRET;

function encryptionKey() {
  if (!encryptionSecret) throw new Error("Server encryption is unavailable.");
  return crypto.createHash("sha256").update(encryptionSecret).digest();
}

export function encryptEmailSecret(secret: string) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv.toString("base64"), tag.toString("base64"), encrypted.toString("base64")].join(":");
}

export function decryptEmailSecret(payload: string) {
  const [iv, tag, encrypted] = payload.split(":");
  if (!iv || !tag || !encrypted) throw new Error("Stored email credential is invalid.");
  const decipher = crypto.createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(iv, "base64"));
  decipher.setAuthTag(Buffer.from(tag, "base64"));
  return Buffer.concat([decipher.update(Buffer.from(encrypted, "base64")), decipher.final()]).toString("utf8");
}

function createSmtpTransport(settings: EmailSettings) {
  if (!settings.isEnabled || !settings.smtpHost || !settings.smtpPort || !settings.smtpUsername || !settings.encryptedPassword || !settings.fromEmail) {
    throw new Error("SMTP delivery is not configured yet.");
  }
  return nodemailer.createTransport({
    host: settings.smtpHost,
    port: settings.smtpPort,
    secure: settings.secure,
    auth: { user: settings.smtpUsername, pass: decryptEmailSecret(settings.encryptedPassword) },
  });
}

export async function verifyConfiguredEmail(settings: EmailSettings) {
  const transport = createSmtpTransport(settings);
  await transport.verify();
}

export async function sendOperationalEmail(settings: EmailSettings, message: { to: string; subject: string; html: string; replyTo?: string | null }) {
  if (settings.provider !== "smtp") throw new Error("The selected email provider has not been configured for delivery.");
  const transport = createSmtpTransport(settings);
  const result = await transport.sendMail({
    from: `${settings.fromName || "EveOps Website"} <${settings.fromEmail}>`,
    to: message.to,
    subject: message.subject,
    html: message.html,
    replyTo: message.replyTo || settings.replyTo || undefined,
  });
  return { messageId: result.messageId };
}

export function renderLeadNotification(input: { name: string; email: string; company?: string | null; phone?: string | null; country?: string | null; division: string; service?: string | null; estimatedVolume?: string | null; deadline?: string | null; preferredCommunication?: string | null; message: string; }) {
  const escape = (value: string | null | undefined) => (value || "—").replace(/[&<>'"]/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char] || char);
  const rows = [
    ["Name", input.name], ["Email", input.email], ["Company", input.company], ["Phone", input.phone], ["Country", input.country], ["Division", input.division], ["Service", input.service], ["Estimated volume", input.estimatedVolume], ["Deadline", input.deadline], ["Preferred communication", input.preferredCommunication],
  ].map(([label, value]) => `<tr><td style="padding:8px 14px 8px 0;color:#5c6a61;font-weight:700">${label}</td><td style="padding:8px 0;color:#173b32">${escape(value)}</td></tr>`).join("");
  return `<main style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;padding:32px;background:#f6f0e6;color:#173b32"><p style="margin:0 0 8px;color:#b95c3d;font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase">Unity Integrated Solutions</p><h1 style="margin:0 0 24px;font-size:28px">New service brief</h1><table style="width:100%;border-collapse:collapse;background:#fffdf8;padding:20px">${rows}</table><section style="margin-top:20px;padding:20px;background:#e5eadc"><p style="margin:0 0 7px;color:#b95c3d;font-size:12px;font-weight:700;text-transform:uppercase">Working brief</p><p style="margin:0;white-space:pre-wrap;line-height:1.6">${escape(input.message)}</p></section></main>`;
}

export function renderCustomerVerification(input: { name: string; verifyUrl: string }) {
  const escape = (value: string) => value.replace(/[&<>'"]/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char] || char);
  return `<main style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;padding:32px;background:#f5f3ee;color:#0b1424"><p style="margin:0 0 8px;color:#2765f5;font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase">EveOps customer account</p><h1 style="margin:0 0 18px;font-size:28px">Confirm your email address</h1><p style="line-height:1.65">Hello ${escape(input.name)}, confirm your email to activate your customer workspace.</p><p style="margin:28px 0"><a href="${escape(input.verifyUrl)}" style="display:inline-block;padding:13px 18px;background:#2765f5;color:#fff;text-decoration:none;font-weight:700">Confirm email</a></p><p style="color:#5c6a7e;font-size:13px;line-height:1.6">This one-time link expires in 24 hours. If you did not create an EveOps account, you can ignore this message.</p></main>`;
}

export function renderAdministratorPasswordReset(input: { name: string; resetUrl: string }) {
  const escape = (value: string) => value.replace(/[&<>'"]/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char] || char);
  return `<main style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;padding:32px;background:#f5f3ee;color:#0b1424"><p style="margin:0 0 8px;color:#2765f5;font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase">EveOps Operations security</p><h1 style="margin:0 0 18px;font-size:28px">Reset your administrator password</h1><p style="line-height:1.65">Hello ${escape(input.name)}, use the secure link below to choose a new EveOps administrator password.</p><p style="margin:28px 0"><a href="${escape(input.resetUrl)}" style="display:inline-block;padding:13px 18px;background:#173b32;color:#fff;text-decoration:none;font-weight:700">Reset administrator password</a></p><p style="color:#5c6a7e;font-size:13px;line-height:1.6">This one-time link expires in 60 minutes. If you did not request a password reset, you can ignore this email. Your password will not change.</p></main>`;
}
