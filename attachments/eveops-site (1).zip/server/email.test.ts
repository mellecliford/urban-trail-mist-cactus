import { describe, expect, it } from "vitest";
import { renderLeadNotification } from "./email";

describe("renderLeadNotification", () => {
  it("escapes submitted content before placing it into the service-brief notification", () => {
    const html = renderLeadNotification({
      name: "Melle <script>alert(1)</script>",
      email: "melle@example.com",
      company: "EveOps",
      phone: "+237671361513",
      country: "Cameroon",
      division: "unity",
      service: "Language services",
      message: "A <b>working brief</b>",
    });

    expect(html).toContain("New service brief");
    expect(html).toContain("Melle &lt;script&gt;alert(1)&lt;/script&gt;");
    expect(html).toContain("A &lt;b&gt;working brief&lt;/b&gt;");
    expect(html).not.toContain("<script>alert(1)</script>");
  });
});
