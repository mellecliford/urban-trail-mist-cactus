import { describe, expect, it, vi } from "vitest";

const { storagePut } = vi.hoisted(() => ({ storagePut: vi.fn() }));
vi.mock("./storage", () => ({ storagePut }));

import { decodePublicMediaDataUrl, storePublicMedia } from "./media";

describe("decodePublicMediaDataUrl", () => {
  it("accepts a small PNG data URL and returns its content type and bytes", () => {
    const result = decodePublicMediaDataUrl("data:image/png;base64,aGVsbG8=");
    expect(result.contentType).toBe("image/png");
    expect(result.bytes.toString("utf8")).toBe("hello");
  });

  it("rejects SVG and other unapproved public-upload types", () => {
    expect(() => decodePublicMediaDataUrl("data:image/svg+xml;base64,PHN2Zy8+")).toThrow("Upload a PNG, JPEG, WebP, or PDF file.");
  });

  it("routes approved public media through the configured object-storage helper using a normalized public key", async () => {
    storagePut.mockResolvedValue({ key: "eveops/public/4/brand-mark_abcd1234.png", url: "https://media.example.test/eveops/public/4/brand-mark_abcd1234.png" });
    const result = await storePublicMedia({ userId: 4, filename: "brand mark!.png", contentType: "image/png", bytes: Buffer.from("asset") });
    expect(storagePut).toHaveBeenCalledWith("eveops/public/4/brand-mark-.png", expect.any(Buffer), "image/png");
    expect(result.url).toBe("https://media.example.test/eveops/public/4/brand-mark_abcd1234.png");
  });
});
