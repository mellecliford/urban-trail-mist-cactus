import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ send: vi.fn(), client: vi.fn(), put: vi.fn(), get: vi.fn(), del: vi.fn(), signedUrl: vi.fn() }));
vi.mock("@aws-sdk/client-s3", () => ({ S3Client: mocks.client.mockImplementation(() => ({ send: mocks.send })), PutObjectCommand: mocks.put.mockImplementation(input => input), GetObjectCommand: mocks.get.mockImplementation(input => input), DeleteObjectCommand: mocks.del.mockImplementation(input => input) }));
vi.mock("@aws-sdk/s3-request-presigner", () => ({ getSignedUrl: mocks.signedUrl }));

import { storageDelete, storageGet, storageGetSignedUrl, storagePut } from "./storage";

const previous = { endpoint: process.env.S3_ENDPOINT, bucket: process.env.S3_BUCKET, accessKey: process.env.S3_ACCESS_KEY_ID, secret: process.env.S3_SECRET_ACCESS_KEY, publicUrl: process.env.S3_PUBLIC_BASE_URL };
afterEach(() => { process.env.S3_ENDPOINT = previous.endpoint; process.env.S3_BUCKET = previous.bucket; process.env.S3_ACCESS_KEY_ID = previous.accessKey; process.env.S3_SECRET_ACCESS_KEY = previous.secret; process.env.S3_PUBLIC_BASE_URL = previous.publicUrl; vi.clearAllMocks(); });

describe("S3-compatible storage adapter", () => {
  it("writes media through the configured endpoint and returns a direct portable public URL", async () => {
    process.env.S3_ENDPOINT = "https://minio.internal"; process.env.S3_BUCKET = "eveops-media"; process.env.S3_ACCESS_KEY_ID = "access"; process.env.S3_SECRET_ACCESS_KEY = "secret"; process.env.S3_PUBLIC_BASE_URL = "https://media.example.test";
    mocks.send.mockResolvedValue({}); mocks.signedUrl.mockResolvedValue("https://minio.internal/signed");
    const stored = await storagePut("/eveops/public/4/brand.png", Buffer.from("asset"), "image/png");
    expect(mocks.client).toHaveBeenCalledWith(expect.objectContaining({ endpoint: "https://minio.internal", forcePathStyle: true }));
    expect(mocks.send).toHaveBeenCalledWith(expect.objectContaining({ Bucket: "eveops-media", Key: expect.stringMatching(/^eveops\/public\/4\/brand_[a-f0-9]{8}\.png$/), ContentType: "image/png" }));
    expect(stored.url).toMatch(/^https:\/\/media\.example\.test\/eveops\/public\/4\/brand_[a-f0-9]{8}\.png$/);
    await expect(storageGet("eveops/public/4/brand.png")).resolves.toEqual({ key: "eveops/public/4/brand.png", url: "https://media.example.test/eveops/public/4/brand.png" });
    await expect(storageGetSignedUrl("eveops/public/4/brand.png")).resolves.toBe("https://minio.internal/signed");
    await storageDelete("/eveops/public/4/brand.png");
    expect(mocks.send).toHaveBeenCalledWith({ Bucket: "eveops-media", Key: "eveops/public/4/brand.png" });
  });
});
