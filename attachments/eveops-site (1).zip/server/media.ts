import { storagePut } from "./storage";

const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp", "application/pdf"]);
const MAX_BYTES = 5 * 1024 * 1024;

export function decodePublicMediaDataUrl(dataUrl: string) {
  const match = /^data:(image\/(?:jpeg|png|webp)|application\/pdf);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!match) throw new Error("Upload a PNG, JPEG, WebP, or PDF file.");
  const contentType = match[1]!;
  if (!allowedTypes.has(contentType)) throw new Error("This file type is not allowed.");
  const bytes = Buffer.from(match[2]!, "base64");
  if (!bytes.length || bytes.length > MAX_BYTES) throw new Error("Files must be between 1 byte and 5 MB.");
  return { bytes, contentType };
}

export async function storePublicMedia(input: { userId: number; filename: string; contentType: string; bytes: Buffer }) {
  const safeFilename = input.filename.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/^-+|-+$/g, "") || "asset";
  const { key, url } = await storagePut(`eveops/public/${input.userId}/${safeFilename}`, input.bytes, input.contentType);
  return { key, url };
}
