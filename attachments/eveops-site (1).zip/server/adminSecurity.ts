import crypto from "node:crypto";
import { Secret, TOTP } from "otpauth";

export const ADMIN_TOTP_ISSUER = "EveOps Group";

export function createTotpEnrollment(email: string) {
  const secret = new Secret({ size: 20 }).base32;
  const totp = new TOTP({ issuer: ADMIN_TOTP_ISSUER, label: email, secret, algorithm: "SHA1", digits: 6, period: 30 });
  return { secret, provisioningUri: totp.toString() };
}

export function verifyTotpCode(secret: string, code: string) {
  if (!/^\d{6}$/.test(code)) return false;
  const totp = new TOTP({ issuer: ADMIN_TOTP_ISSUER, secret, algorithm: "SHA1", digits: 6, period: 30 });
  return totp.validate({ token: code, window: 1 }) !== null;
}

export function createRecoveryCodes(count = 8) {
  return Array.from({ length: count }, () => crypto.randomBytes(5).toString("hex").toUpperCase().match(/.{1,5}/g)!.join("-"));
}

export function hashRecoveryCode(code: string) { return crypto.createHash("sha256").update(code.replace(/\s/g, "").toUpperCase()).digest("hex"); }
