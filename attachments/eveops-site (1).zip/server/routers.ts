import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { completeAdministratorPasswordReset, consumeAdministratorRecoveryCode, createCustomerPasswordAccount, createEmailLog, createLead, createMediaRecord, dashboardOverview, deleteMediaRecord, disableAdministratorTotp, enableAdministratorTotp, getAdministratorSecurity, getCustomerVerificationRequired, getLatestEmailSettings, getMediaById, getPasswordAccountByEmail, getPasswordAccountByUserId, listCapabilityAnalytics, listLeads, listMedia, listPasswordAccounts, markPasswordAccountLogin, recordAudit, recordCapabilityEvent, saveAdministratorPasswordReset, saveEmailSettings, savePendingAdministratorTotp, setCustomerVerificationRequired, updateEmailLog, verifyExistingPasswordAccounts, verifyPasswordAccount } from "./db";
import { decryptEmailSecret, encryptEmailSecret, renderAdministratorPasswordReset, renderCustomerVerification, renderLeadNotification, sendOperationalEmail, verifyConfiguredEmail } from "./email";
import { decodePublicMediaDataUrl, storePublicMedia } from "./media";
import { ACCOUNT_SESSION_COOKIE, ADMIN_TWO_FACTOR_CHALLENGE_COOKIE, accountSessionMaxAgeMs, adminTwoFactorChallengeMaxAgeMs, createAccountSession, createAdminTwoFactorChallenge, createVerificationToken, getAdminTwoFactorChallengeUserId, hashCustomerPassword, hashVerificationToken, normalizeAccountEmail, verifyCustomerPassword } from "./passwordAuth";
import { configureFirstLaunch, getFirstLaunchProgress, getFirstLaunchStatus } from "./firstLaunch";
import { storageDelete } from "./storage";
import { createRecoveryCodes, createTotpEnrollment, hashRecoveryCode, verifyTotpCode } from "./adminSecurity";

const leadSchema = z.object({ name: z.string().trim().min(2).max(160), company: z.string().trim().max(200).optional(), email: z.string().trim().email().max(320), phone: z.string().trim().max(50).optional(), country: z.string().trim().max(100).optional(), division: z.enum(["unity", "edevops", "group"]).default("unity"), service: z.string().trim().max(160).optional(), estimatedVolume: z.string().trim().max(160).optional(), deadline: z.string().trim().max(32).optional(), preferredCommunication: z.string().trim().max(80).optional(), attributionChannel: z.enum(["direct", "capability_cta"]).optional(), attributedCapability: z.string().trim().max(160).optional(), message: z.string().trim().min(10).max(10_000) });

const emailSettingsSchema = z.object({ smtpHost: z.string().trim().max(255), smtpPort: z.number().int().min(1).max(65535), smtpUsername: z.string().trim().max(320), smtpPassword: z.string().min(1).max(1000).optional(), secure: z.boolean(), fromName: z.string().trim().min(2).max(120), fromEmail: z.string().trim().email().max(320), replyTo: z.string().trim().email().max(320), isEnabled: z.boolean() });
const customerCredentialsSchema = z.object({ name: z.string().trim().min(2).max(160), email: z.string().trim().email().max(320), password: z.string().min(8).max(128) });
const customerLoginSchema = z.object({ email: z.string().trim().email().max(320), password: z.string().min(8).max(128) });
const firstLaunchSchema = z.object({ setupToken: z.string().min(24).max(256), databaseUrl: z.string().trim().min(16).max(1000), administratorName: z.string().trim().min(2).max(160), administratorEmail: z.string().trim().email().max(320), administratorPassword: z.string().min(12).max(128) });
const twoFactorCodeSchema = z.object({ code: z.string().trim().min(6).max(64) });
const passwordResetRequestSchema = z.object({ email: z.string().trim().email().max(320) });
const passwordResetCompleteSchema = z.object({ token: z.string().min(32).max(256), password: z.string().min(12).max(128) });
const capabilityEventSchema = z.object({ division: z.enum(["unity", "edevops"]), service: z.string().trim().min(2).max(160), capability: z.string().trim().min(2).max(160), eventType: z.enum(["brief_opened", "template_downloaded"]) });
const analyticsRangeSchema = z.object({ start: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), end: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional() }).refine(input => !input.start || !input.end || input.start <= input.end, { message: "The start date must be on or before the end date." });
const resetRateLimits = new Map<string, { count: number; resetsAt: number }>();
const capabilityEventDedupes = new Map<string, number>();

function allowResetRequest(key: string) { const now = Date.now(); const current = resetRateLimits.get(key); if (!current || current.resetsAt < now) { resetRateLimits.set(key, { count: 1, resetsAt: now + 15 * 60 * 1000 }); return true; } if (current.count >= 3) return false; current.count += 1; return true; }
function allowCapabilityEvent(key: string) { const now = Date.now(); const prior = capabilityEventDedupes.get(key); if (prior && now - prior < 15_000) return false; capabilityEventDedupes.set(key, now); if (capabilityEventDedupes.size > 2_000) capabilityEventDedupes.forEach((timestamp, candidate) => { if (now - timestamp > 60_000) capabilityEventDedupes.delete(candidate); }); return true; }
function requestOrigin(ctx: { req: { headers: Record<string, string | string[] | undefined>; protocol: string; get(name: string): string | undefined } }) { const forwardedProto = ctx.req.headers["x-forwarded-proto"]; const protocol = typeof forwardedProto === "string" ? forwardedProto.split(",")[0] : ctx.req.protocol; return `${protocol}://${ctx.req.get("host")}`; }

function safeEmailSettings(settings: Awaited<ReturnType<typeof getLatestEmailSettings>>) {
  if (!settings) return { configured: false, provider: "smtp" as const, smtpHost: "", smtpPort: 465, smtpUsername: "", secure: true, fromName: "EveOps Website", fromEmail: "", replyTo: "support@eveopsgroup.com", isEnabled: false, hasPassword: false };
  return { configured: true, provider: settings.provider, smtpHost: settings.smtpHost || "", smtpPort: settings.smtpPort || 465, smtpUsername: settings.smtpUsername || "", secure: settings.secure, fromName: settings.fromName || "EveOps Website", fromEmail: settings.fromEmail || "", replyTo: settings.replyTo || "support@eveopsgroup.com", isEnabled: settings.isEnabled, hasPassword: Boolean(settings.encryptedPassword), updatedAt: settings.updatedAt };
}

export const appRouter = router({
  system: systemRouter,
  setup: router({ status: publicProcedure.query(() => getFirstLaunchStatus()), progress: publicProcedure.query(() => getFirstLaunchProgress()), complete: publicProcedure.input(firstLaunchSchema).mutation(({ input }) => configureFirstLaunch(input)) }),
  auth: router({ me: publicProcedure.query(opts => opts.ctx.user), logout: publicProcedure.mutation(({ ctx }) => { ctx.res.clearCookie(ACCOUNT_SESSION_COOKIE, { ...getSessionCookieOptions(ctx.req), maxAge: -1 }); return { success: true } as const; }) }),
  adminAuth: router({
    login: publicProcedure.input(customerLoginSchema).mutation(async ({ ctx, input }) => {
      const account = await getPasswordAccountByEmail(normalizeAccountEmail(input.email));
      if (!account || !(await verifyCustomerPassword(input.password, account.account.passwordHash)) || !["admin", "super_admin"].includes(account.user.role)) throw new Error("Administrator email or password is incorrect.");
      const security = await getAdministratorSecurity(account.user.id);
      if (security?.totpEnabled && security.encryptedTotpSecret) {
        const challenge = await createAdminTwoFactorChallenge(account.user.id);
        ctx.res.cookie(ADMIN_TWO_FACTOR_CHALLENGE_COOKIE, challenge, { ...getSessionCookieOptions(ctx.req), maxAge: adminTwoFactorChallengeMaxAgeMs });
        return { requiresTwoFactor: true as const };
      }
      await markPasswordAccountLogin(account.user.id);
      const session = await createAccountSession(account.user.id);
      ctx.res.cookie(ACCOUNT_SESSION_COOKIE, session, { ...getSessionCookieOptions(ctx.req), maxAge: accountSessionMaxAgeMs });
      return { requiresTwoFactor: false as const, user: account.user };
    }),
    verifyTwoFactor: publicProcedure.input(twoFactorCodeSchema).mutation(async ({ ctx, input }) => {
      const userId = await getAdminTwoFactorChallengeUserId(ctx.req);
      if (!userId) throw new Error("Your administrator security check expired. Sign in with your password again.");
      const account = await getPasswordAccountByUserId(userId); const security = await getAdministratorSecurity(userId);
      if (!account || !["admin", "super_admin"].includes(account.user.role) || !security?.totpEnabled || !security.encryptedTotpSecret) throw new Error("Two-factor authentication is not available for this account.");
      const totpValid = verifyTotpCode(decryptEmailSecret(security.encryptedTotpSecret), input.code);
      const recoveryValid = totpValid ? false : await consumeAdministratorRecoveryCode(userId, hashRecoveryCode(input.code));
      if (!totpValid && !recoveryValid) throw new Error("That authentication code is invalid. Check your authenticator or use an unused recovery code.");
      await markPasswordAccountLogin(userId);
      const session = await createAccountSession(userId);
      ctx.res.cookie(ACCOUNT_SESSION_COOKIE, session, { ...getSessionCookieOptions(ctx.req), maxAge: accountSessionMaxAgeMs });
      ctx.res.clearCookie(ADMIN_TWO_FACTOR_CHALLENGE_COOKIE, { ...getSessionCookieOptions(ctx.req), maxAge: -1 });
      await recordAudit({ actorUserId: userId, action: "administrator.two_factor_verified", targetType: "password_account", targetId: String(account.account.id) });
      return { user: account.user };
    }),
    requestPasswordReset: publicProcedure.input(passwordResetRequestSchema).mutation(async ({ ctx, input }) => {
      const normalizedEmail = normalizeAccountEmail(input.email);
      const allowed = allowResetRequest(`${ctx.req.ip}:${normalizedEmail}`);
      const account = allowed ? await getPasswordAccountByEmail(normalizedEmail) : undefined;
      if (account && ["admin", "super_admin"].includes(account.user.role)) {
        try { const settings = await getLatestEmailSettings(); if (settings?.isEnabled) { const token = createVerificationToken(); await saveAdministratorPasswordReset(account.account.id, hashVerificationToken(token), new Date(Date.now() + 60 * 60 * 1000)); await sendOperationalEmail(settings, { to: account.account.email, subject: "Reset your EveOps administrator password", html: renderAdministratorPasswordReset({ name: account.user.name || "Administrator", resetUrl: `${requestOrigin(ctx)}/admin/reset?token=${encodeURIComponent(token)}` }) }); await recordAudit({ actorUserId: account.user.id, action: "administrator.password_reset_requested", targetType: "password_account", targetId: String(account.account.id) }); } } catch { /* Preserve the same public response to prevent account or delivery-state discovery. */ }
      }
      return { accepted: true };
    }),
    completePasswordReset: publicProcedure.input(passwordResetCompleteSchema).mutation(async ({ input }) => {
      const user = await completeAdministratorPasswordReset(hashVerificationToken(input.token), await hashCustomerPassword(input.password));
      if (!user) throw new Error("This reset link is invalid or has expired. Request a new password reset link.");
      await recordAudit({ actorUserId: user.id, action: "administrator.password_reset_completed", targetType: "password_account", targetId: String(user.id) });
      return { success: true };
    }),
  }),
  customerAuth: router({
    policy: publicProcedure.query(async () => ({ requiresEmailVerification: await getCustomerVerificationRequired() })),
    register: publicProcedure.input(customerCredentialsSchema).mutation(async ({ ctx, input }) => {
      const email = normalizeAccountEmail(input.email); const requiresEmailVerification = await getCustomerVerificationRequired(); const existing = await getPasswordAccountByEmail(email); if (existing) throw new Error("An account already exists for this email address."); const settings = requiresEmailVerification ? await getLatestEmailSettings() : undefined; if (requiresEmailVerification && !settings?.isEnabled) throw new Error("Customer verification is temporarily unavailable. Please contact support."); const verificationToken = requiresEmailVerification ? createVerificationToken() : undefined; const account = await createCustomerPasswordAccount({ name: input.name, email, passwordHash: await hashCustomerPassword(input.password), verificationTokenHash: verificationToken ? hashVerificationToken(verificationToken) : undefined, verificationExpiresAt: verificationToken ? new Date(Date.now() + 24 * 60 * 60 * 1000) : undefined }); await recordAudit({ actorUserId: account.user.id, action: "customer_account.created", targetType: "password_account", targetId: String(account.account.id) }); if (requiresEmailVerification && verificationToken && settings) { const forwardedProto = ctx.req.headers["x-forwarded-proto"]; const protocol = typeof forwardedProto === "string" ? forwardedProto.split(",")[0] : ctx.req.protocol; const host = ctx.req.get("host"); const verifyUrl = `${protocol}://${host}/customer/verify?token=${encodeURIComponent(verificationToken)}`; await sendOperationalEmail(settings, { to: email, subject: "Confirm your EveOps customer account", html: renderCustomerVerification({ name: input.name, verifyUrl }) }); return { needsVerification: true }; } const session = await createAccountSession(account.user.id); ctx.res.cookie(ACCOUNT_SESSION_COOKIE, session, { ...getSessionCookieOptions(ctx.req), maxAge: accountSessionMaxAgeMs }); return { needsVerification: false, user: account.user }; }),
    login: publicProcedure.input(customerLoginSchema).mutation(async ({ ctx, input }) => { const account = await getPasswordAccountByEmail(normalizeAccountEmail(input.email)); if (!account || !(await verifyCustomerPassword(input.password, account.account.passwordHash)) || account.user.role !== "customer") throw new Error("Email or password is incorrect."); if (account.customerStatus === "disabled") throw new Error("This customer account is disabled."); if (await getCustomerVerificationRequired() && !account.account.emailVerified) throw new Error("Confirm your email address before signing in."); await markPasswordAccountLogin(account.user.id); const session = await createAccountSession(account.user.id); ctx.res.cookie(ACCOUNT_SESSION_COOKIE, session, { ...getSessionCookieOptions(ctx.req), maxAge: accountSessionMaxAgeMs }); return { user: account.user }; }),
    verifyEmail: publicProcedure.input(z.object({ token: z.string().min(20).max(256) })).mutation(async ({ ctx, input }) => { const user = await verifyPasswordAccount(hashVerificationToken(input.token)); if (!user) throw new Error("This verification link is invalid or has expired."); const session = await createAccountSession(user.id); ctx.res.cookie(ACCOUNT_SESSION_COOKIE, session, { ...getSessionCookieOptions(ctx.req), maxAge: accountSessionMaxAgeMs }); return { success: true, user }; }),
  }),
  conversion: router({ track: publicProcedure.input(capabilityEventSchema).mutation(async ({ ctx, input }) => { const clientKey = `${ctx.req.ip || "anonymous"}:${input.division}:${input.service}:${input.capability}:${input.eventType}`; if (!allowCapabilityEvent(clientKey)) return { recorded: false }; await recordCapabilityEvent(input); return { recorded: true }; }) }),
  leads: router({
    submit: publicProcedure.input(leadSchema).mutation(async ({ input }) => {
      const lead = await createLead(input);
      const settings = await getLatestEmailSettings();
      if (!settings?.isEnabled) return { id: lead.id, emailStatus: "not_configured" as const };
      const logId = await createEmailLog({ recipient: "support@eveopsgroup.com", subject: `New ${lead.division === "unity" ? "Unity" : "EveOps"} service brief — ${lead.name}`, status: "queued", leadId: lead.id });
      try {
        await sendOperationalEmail(settings, { to: "support@eveopsgroup.com", subject: `New ${lead.division === "unity" ? "Unity" : "EveOps"} service brief — ${lead.name}`, html: renderLeadNotification(lead), replyTo: lead.email });
        await updateEmailLog(logId, { status: "sent" });
        return { id: lead.id, emailStatus: "sent" as const };
      } catch (error) {
        await updateEmailLog(logId, { status: "failed", errorMessage: error instanceof Error ? error.message.slice(0, 1000) : "Delivery failed" });
        return { id: lead.id, emailStatus: "failed" as const };
      }
    }),
    list: adminProcedure.query(() => listLeads()),
  }),
  admin: router({
    overview: adminProcedure.query(() => dashboardOverview()),
    conversionAnalytics: adminProcedure.input(analyticsRangeSchema.optional()).query(({ input }) => listCapabilityAnalytics({ start: input?.start ? new Date(`${input.start}T00:00:00.000Z`) : undefined, end: input?.end ? new Date(`${input.end}T23:59:59.999Z`) : undefined })),
    customerAccounts: router({ list: adminProcedure.query(() => listPasswordAccounts()), policy: adminProcedure.query(async () => ({ requiresEmailVerification: await getCustomerVerificationRequired() })), savePolicy: adminProcedure.input(z.object({ requiresEmailVerification: z.boolean() })).mutation(async ({ ctx, input }) => { if (input.requiresEmailVerification) { const settings = await getLatestEmailSettings(); if (!settings?.isEnabled) throw new Error("Enable and verify SMTP delivery before requiring customer email verification."); await verifyExistingPasswordAccounts(); } await setCustomerVerificationRequired(input.requiresEmailVerification, ctx.user.id); await recordAudit({ actorUserId: ctx.user.id, action: "customer_verification_policy.saved", targetType: "system_setting", targetId: "customer_email_verification_required", metadata: JSON.stringify(input) }); return { requiresEmailVerification: input.requiresEmailVerification }; }) }),
    emailSettings: router({
      get: adminProcedure.query(async () => safeEmailSettings(await getLatestEmailSettings())),
      save: adminProcedure.input(emailSettingsSchema).mutation(async ({ ctx, input }) => {
        const existing = await getLatestEmailSettings();
        if (!input.smtpPassword && !existing?.encryptedPassword) throw new Error("Enter the SMTP password before enabling delivery.");
        const settings = await saveEmailSettings({ ...input, encryptedPassword: input.smtpPassword ? encryptEmailSecret(input.smtpPassword) : undefined, updatedByUserId: ctx.user.id });
        await recordAudit({ actorUserId: ctx.user.id, action: "email_settings.saved", targetType: "email_settings", targetId: String(settings?.id || "") });
        return safeEmailSettings(settings);
      }),
      testConnection: adminProcedure.mutation(async ({ ctx }) => { const settings = await getLatestEmailSettings(); if (!settings) throw new Error("Save SMTP settings before testing."); await verifyConfiguredEmail(settings); await recordAudit({ actorUserId: ctx.user.id, action: "email_settings.connection_verified", targetType: "email_settings", targetId: String(settings.id) }); return { success: true }; }),
      sendTest: adminProcedure.input(z.object({ recipient: z.string().email().max(320) })).mutation(async ({ ctx, input }) => { const settings = await getLatestEmailSettings(); if (!settings) throw new Error("Save SMTP settings before sending a test."); const logId = await createEmailLog({ recipient: input.recipient, subject: "EveOps email configuration test", status: "queued" }); try { await sendOperationalEmail(settings, { to: input.recipient, subject: "EveOps email configuration test", html: "<p>Your EveOps email configuration is working.</p>" }); await updateEmailLog(logId, { status: "sent" }); await recordAudit({ actorUserId: ctx.user.id, action: "email_settings.test_sent", targetType: "email_settings", targetId: String(settings.id) }); return { success: true }; } catch (error) { await updateEmailLog(logId, { status: "failed", errorMessage: error instanceof Error ? error.message.slice(0, 1000) : "Delivery failed" }); throw error; } }),
    }),
    security: router({
      status: adminProcedure.query(async ({ ctx }) => { const security = await getAdministratorSecurity(ctx.user.id); return { totpEnabled: Boolean(security?.totpEnabled), recoveryCodesRemaining: security?.recoveryCodeHashes ? JSON.parse(security.recoveryCodeHashes).length : 0 }; }),
      beginTotpEnrollment: adminProcedure.input(z.object({ password: z.string().min(8).max(128) })).mutation(async ({ ctx, input }) => {
        const account = await getPasswordAccountByUserId(ctx.user.id); if (!account || !(await verifyCustomerPassword(input.password, account.account.passwordHash))) throw new Error("Enter your current administrator password to set up two-factor authentication.");
        const enrollment = createTotpEnrollment(account.account.email); await savePendingAdministratorTotp(ctx.user.id, encryptEmailSecret(enrollment.secret)); await recordAudit({ actorUserId: ctx.user.id, action: "administrator.two_factor_enrollment_started", targetType: "administrator_security", targetId: String(ctx.user.id) }); return { provisioningUri: enrollment.provisioningUri, manualKey: enrollment.secret };
      }),
      confirmTotpEnrollment: adminProcedure.input(twoFactorCodeSchema).mutation(async ({ ctx, input }) => {
        const security = await getAdministratorSecurity(ctx.user.id); if (!security?.encryptedTotpSecret || !verifyTotpCode(decryptEmailSecret(security.encryptedTotpSecret), input.code)) throw new Error("That authenticator code could not be verified. Check the current six-digit code and try again.");
        const recoveryCodes = createRecoveryCodes(); await enableAdministratorTotp(ctx.user.id, recoveryCodes.map(hashRecoveryCode)); await recordAudit({ actorUserId: ctx.user.id, action: "administrator.two_factor_enabled", targetType: "administrator_security", targetId: String(ctx.user.id) }); return { recoveryCodes };
      }),
      disableTotp: adminProcedure.input(z.object({ password: z.string().min(8).max(128), code: z.string().trim().min(6).max(64) })).mutation(async ({ ctx, input }) => {
        const account = await getPasswordAccountByUserId(ctx.user.id); const security = await getAdministratorSecurity(ctx.user.id);
        if (!account || !security?.totpEnabled || !security.encryptedTotpSecret || !(await verifyCustomerPassword(input.password, account.account.passwordHash))) throw new Error("Enter your current password and an active authentication code to disable two-factor authentication.");
        const totpValid = verifyTotpCode(decryptEmailSecret(security.encryptedTotpSecret), input.code); const recoveryValid = totpValid ? false : await consumeAdministratorRecoveryCode(ctx.user.id, hashRecoveryCode(input.code)); if (!totpValid && !recoveryValid) throw new Error("That authentication code is invalid.");
        await disableAdministratorTotp(ctx.user.id); await recordAudit({ actorUserId: ctx.user.id, action: "administrator.two_factor_disabled", targetType: "administrator_security", targetId: String(ctx.user.id) }); return { totpEnabled: false };
      }),
    }),
  }),
  media: router({
    list: adminProcedure.query(() => listMedia()),
    upload: adminProcedure.input(z.object({ filename: z.string().trim().min(1).max(255), dataUrl: z.string().min(1).max(7_000_000) })).mutation(async ({ ctx, input }) => {
      const { bytes, contentType } = decodePublicMediaDataUrl(input.dataUrl);
      const stored = await storePublicMedia({ userId: ctx.user.id, filename: input.filename, contentType, bytes });
      const record = await createMediaRecord({ filename: input.filename, fileKey: stored.key, url: stored.url, contentType, byteSize: bytes.byteLength, uploadedByUserId: ctx.user.id });
      await recordAudit({ actorUserId: ctx.user.id, action: "media.uploaded", targetType: "media", targetId: String(record.id), metadata: JSON.stringify({ contentType, byteSize: bytes.byteLength }) });
      return record;
    }),
    delete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const record = await getMediaById(input.id);
      if (!record) throw new Error("This media asset no longer exists.");
      await storageDelete(record.fileKey);
      await deleteMediaRecord(record.id);
      await recordAudit({ actorUserId: ctx.user.id, action: "media.deleted", targetType: "media", targetId: String(record.id), metadata: JSON.stringify({ filename: record.filename, fileKey: record.fileKey }) });
      return { id: record.id, filename: record.filename };
    }),
    bulkDelete: adminProcedure.input(z.object({ ids: z.array(z.number().int().positive()).min(1).max(50).refine(ids => new Set(ids).size === ids.length, "Choose each media asset only once.") })).mutation(async ({ ctx, input }) => {
      const deleted: Array<{ id: number; filename: string }> = []; const failed: Array<{ id: number; reason: string }> = [];
      for (const id of input.ids) {
        const record = await getMediaById(id);
        if (!record) { failed.push({ id, reason: "This media asset no longer exists." }); continue; }
        try { await storageDelete(record.fileKey); await deleteMediaRecord(record.id); await recordAudit({ actorUserId: ctx.user.id, action: "media.bulk_deleted", targetType: "media", targetId: String(record.id), metadata: JSON.stringify({ filename: record.filename, fileKey: record.fileKey }) }); deleted.push({ id: record.id, filename: record.filename }); } catch { failed.push({ id: record.id, reason: "The object could not be removed from storage." }); }
      }
      return { deleted, failed };
    }),
  }),
});

export type AppRouter = typeof appRouter;
