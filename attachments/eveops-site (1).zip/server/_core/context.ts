import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { getPasswordSessionUser } from "../db";
import { getAccountSessionUserId } from "../passwordAuth";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  const accountUserId = await getAccountSessionUserId(opts.req);
  const user = accountUserId ? (await getPasswordSessionUser(accountUserId)) ?? null : null;

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
