import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { bootstrapInitialAdmin } from "../bootstrapAdmin";
import { hydrateRuntimeConfig } from "../runtimeConfig";
import { buildCompanyProfilePdf } from "../companyProfilePdf";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  await hydrateRuntimeConfig();
  await bootstrapInitialAdmin();
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  console.log("[Auth] Self-hosted account authentication is active.");
  app.get("/api/public/company-profile.pdf", async (req, res) => {
    try {
      const locale = req.query.lang === "fr" ? "fr" : "en";
      const pdf = await buildCompanyProfilePdf(locale);
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", locale === "fr" ? 'attachment; filename="eveOps-Group-Profil-Entreprise-FR.pdf"' : 'attachment; filename="eveOps-Group-Company-Profile-EN.pdf"');
      res.setHeader("Cache-Control", "public, max-age=3600");
      res.send(pdf);
    } catch (error) {
      console.error("[Profile PDF] Failed to generate company profile:", error);
      res.status(500).json({ error: "Unable to prepare the company profile right now." });
    }
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
