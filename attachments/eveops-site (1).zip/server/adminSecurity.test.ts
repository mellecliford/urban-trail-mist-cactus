import { TOTP } from "otpauth";
import { describe, expect, it } from "vitest";
import { ADMIN_TOTP_ISSUER, createRecoveryCodes, createTotpEnrollment, hashRecoveryCode, verifyTotpCode } from "./adminSecurity";

describe("administrator two-factor utilities", () => {
  it("creates an authenticator-compatible enrollment and accepts only its current six-digit code", () => {
    const enrollment = createTotpEnrollment("admin@example.com");
    const code = new TOTP({ issuer: ADMIN_TOTP_ISSUER, label: "admin@example.com", secret: enrollment.secret, algorithm: "SHA1", digits: 6, period: 30 }).generate();
    expect(enrollment.provisioningUri).toContain("otpauth://totp/");
    expect(verifyTotpCode(enrollment.secret, code)).toBe(true);
    expect(verifyTotpCode(enrollment.secret, "000000")).toBe(false);
  });

  it("creates distinct recovery codes and hashes normalized input deterministically", () => {
    const codes = createRecoveryCodes();
    expect(codes).toHaveLength(8);
    expect(new Set(codes).size).toBe(8);
    expect(hashRecoveryCode(codes[0])).toBe(hashRecoveryCode(codes[0].toLowerCase()));
  });
});
