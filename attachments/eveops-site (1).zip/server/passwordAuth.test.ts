import { describe, expect, it } from "vitest";
import { createVerificationToken, hashCustomerPassword, hashVerificationToken, normalizeAccountEmail, verifyCustomerPassword } from "./passwordAuth";

describe("customer password authentication helpers", () => {
  it("normalizes account email without changing its address", () => {
    expect(normalizeAccountEmail("  Customer@Example.COM ")).toBe("customer@example.com");
  });

  it("hashes passwords and verifies only the matching password", async () => {
    const passwordHash = await hashCustomerPassword("a-secure-customer-password");
    await expect(verifyCustomerPassword("a-secure-customer-password", passwordHash)).resolves.toBe(true);
    await expect(verifyCustomerPassword("wrong-password", passwordHash)).resolves.toBe(false);
  });

  it("creates a high-entropy verification token that is persisted only as a deterministic hash", () => {
    const token = createVerificationToken();
    expect(token.length).toBeGreaterThan(32);
    expect(hashVerificationToken(token)).toHaveLength(64);
    expect(hashVerificationToken(token)).toBe(hashVerificationToken(token));
  });
});
