import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const { createLead, getLatestEmailSettings, listCapabilityAnalytics, recordCapabilityEvent } = vi.hoisted(() => ({
  createLead: vi.fn(),
  getLatestEmailSettings: vi.fn(),
  listCapabilityAnalytics: vi.fn(),
  recordCapabilityEvent: vi.fn(),
}));

vi.mock("./db", () => ({
  createLead,
  getLatestEmailSettings,
  createEmailLog: vi.fn(),
  dashboardOverview: vi.fn(),
  createMediaRecord: vi.fn(),
  listLeads: vi.fn(),
  listMedia: vi.fn(),
  saveEmailSettings: vi.fn(),
  updateEmailLog: vi.fn(),
  listCapabilityAnalytics,
  recordCapabilityEvent,
}));

vi.mock("./email", () => ({
  encryptEmailSecret: vi.fn(),
  renderLeadNotification: vi.fn(),
  sendOperationalEmail: vi.fn(),
  verifyConfiguredEmail: vi.fn(),
}));

vi.mock("./media", () => ({
  decodePublicMediaDataUrl: vi.fn(),
  storePublicMedia: vi.fn(),
}));

import { appRouter } from "./routers";

function context(user: TrpcContext["user"]): TrpcContext {
  return { user, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("operations routes", () => {
  it("stores a public Unity service brief and reports when email delivery is awaiting administrator configuration", async () => {
    createLead.mockResolvedValue({ id: 42, division: "unity", name: "Melle", email: "melle@example.com" });
    getLatestEmailSettings.mockResolvedValue(undefined);

    const result = await appRouter.createCaller(context(null)).leads.submit({
      name: "Melle",
      email: "melle@example.com",
      division: "unity",
      service: "Language services",
      attributionChannel: "capability_cta",
      attributedCapability: "Translation",
      message: "We need a structured multilingual research and translation delivery brief.",
    });

    expect(createLead).toHaveBeenCalledWith(expect.objectContaining({
      name: "Melle",
      division: "unity",
      service: "Language services",
      attributionChannel: "capability_cta",
      attributedCapability: "Translation",
    }));
    expect(result).toEqual({ id: 42, emailStatus: "not_configured" });
  });

  it.each(["customer", "manager", "staff", "user"] as const)("denies the %s role access to the administrator overview before data is queried", async role => {
    const caller = appRouter.createCaller(context({
      id: 8,
      openId: `${role}-8`,
      name: role,
      email: `${role}@example.com`,
      loginMethod: "manus",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    }));

    await expect(caller.admin.overview()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("records an anonymous capability event without accepting visitor-identifying fields", async () => {
    const result = await appRouter.createCaller(context(null)).conversion.track({ division: "unity", service: "Transcription Services", capability: "Audio transcription", eventType: "template_downloaded" });
    expect(recordCapabilityEvent).toHaveBeenCalledWith({ division: "unity", service: "Transcription Services", capability: "Audio transcription", eventType: "template_downloaded" });
    expect(result).toEqual({ recorded: true });
  });

  it("returns conversion analytics only to an administrator", async () => {
    listCapabilityAnalytics.mockResolvedValue([{ division: "edevops", service: "Web Development", capability: "Corporate websites", briefOpens: 2, templateDownloads: 1, attributedLeads: 1, total: 3, lastSeen: new Date() }]);
    const admin = context({ id: 2, openId: "admin-2", name: "Admin", email: "admin@example.com", loginMethod: "password", role: "admin", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() });
    await expect(appRouter.createCaller(admin).admin.conversionAnalytics()).resolves.toHaveLength(1);
    await expect(appRouter.createCaller(admin).admin.conversionAnalytics({ start: "2026-08-01", end: "2026-08-26" })).resolves.toHaveLength(1);
    expect(listCapabilityAnalytics).toHaveBeenLastCalledWith({ start: new Date("2026-08-01T00:00:00.000Z"), end: new Date("2026-08-26T23:59:59.999Z") });
    const customer = context({ id: 3, openId: "customer-3", name: "Customer", email: "customer@example.com", loginMethod: "password", role: "customer", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() });
    await expect(appRouter.createCaller(customer).admin.conversionAnalytics()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(admin).admin.conversionAnalytics({ start: "2026-08-27", end: "2026-08-01" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
