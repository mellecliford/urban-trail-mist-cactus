import crypto from "node:crypto";
import { compare, hash } from "bcryptjs";
import { parse } from "cookie";
import { SignJWT, jwtVerify } from "jose";
import type { Request } from "express";

export const ACCOUNT_SESSION_COOKIE = "eveops_session";
export const ADMIN_TWO_FACTOR_CHALLENGE_COOKIE = "eveops_admin_2fa";
const LEGACY_CUSTOMER_SESSION_COOKIE = "eveops_customer_session";
const SESSION_AGE_SECONDS = 60 * 60 * 24 * 7;
export const adminTwoFactorChallengeMaxAgeMs = 5 * 60 * 1000;

function sessionSecret() {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("Customer session signing is unavailable.");
  return new TextEncoder().encode(secret);
}

export function normalizeAccountEmail(email: string) {
  return email.trim().toLowerCase();
}

export async function hashCustomerPassword(password: string) {
  return hash(password, 12);
}

export async function verifyCustomerPassword(password: string, passwordHash: string) {
  return compare(password, passwordHash);
}

export function createVerificationToken() {
  return crypto.randomBytes(32).toString("base64url");
}

export function hashVerificationToken(token: string) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function createAccountSession(userId: number) {
  return new SignJWT({ kind: "self_hosted_account" })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(userId))
    .setIssuedAt()
    .setExpirationTime(`${SESSION_AGE_SECONDS}s`)
    .sign(sessionSecret());
}

export async function createAdminTwoFactorChallenge(userId: number) {
  return new SignJWT({ kind: "administrator_two_factor" })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(userId))
    .setIssuedAt()
    .setExpirationTime(`${adminTwoFactorChallengeMaxAgeMs / 1000}s`)
    .sign(sessionSecret());
}

export async function getAdminTwoFactorChallengeUserId(req: Request) {
  const token = parse(req.headers.cookie || "")[ADMIN_TWO_FACTOR_CHALLENGE_COOKIE];
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, sessionSecret());
    return payload.kind === "administrator_two_factor" && payload.sub && /^\d+$/.test(payload.sub) ? Number(payload.sub) : null;
  } catch { return null; }
}

export async function getAccountSessionUserId(req: Request) {
  const cookies = parse(req.headers.cookie || "");
  const token = cookies[ACCOUNT_SESSION_COOKIE] || cookies[LEGACY_CUSTOMER_SESSION_COOKIE];
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, sessionSecret());
    if ((payload.kind !== "self_hosted_account" && payload.kind !== "customer_password") || !payload.sub || !/^\d+$/.test(payload.sub)) return null;
    return Number(payload.sub);
  } catch {
    return null;
  }
}

export const accountSessionMaxAgeMs = SESSION_AGE_SECONDS * 1000;
