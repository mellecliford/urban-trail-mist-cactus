import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ createPasswordAccount: vi.fn(), getPasswordAccountByEmail: vi.fn(), hashCustomerPassword: vi.fn(), normalizeAccountEmail: vi.fn() }));
vi.mock("./db", () => ({ createPasswordAccount: mocks.createPasswordAccount, getPasswordAccountByEmail: mocks.getPasswordAccountByEmail }));
vi.mock("./passwordAuth", () => ({ hashCustomerPassword: mocks.hashCustomerPassword, normalizeAccountEmail: mocks.normalizeAccountEmail }));

import { bootstrapInitialAdmin } from "./bootstrapAdmin";

const original = { email: process.env.INITIAL_ADMIN_EMAIL, password: process.env.INITIAL_ADMIN_PASSWORD, name: process.env.INITIAL_ADMIN_NAME };
afterEach(() => { process.env.INITIAL_ADMIN_EMAIL = original.email; process.env.INITIAL_ADMIN_PASSWORD = original.password; process.env.INITIAL_ADMIN_NAME = original.name; vi.clearAllMocks(); });

describe("initial administrator bootstrap", () => {
  it("does nothing without external administrator configuration", async () => {
    delete process.env.INITIAL_ADMIN_EMAIL; delete process.env.INITIAL_ADMIN_PASSWORD; delete process.env.INITIAL_ADMIN_NAME;
    await bootstrapInitialAdmin();
    expect(mocks.getPasswordAccountByEmail).not.toHaveBeenCalled();
  });

  it("creates one normalized super-administrator only when no account already uses the configured email", async () => {
    process.env.INITIAL_ADMIN_EMAIL = " Admin@Example.com "; process.env.INITIAL_ADMIN_PASSWORD = "a-long-initial-password"; process.env.INITIAL_ADMIN_NAME = "Initial Admin";
    mocks.normalizeAccountEmail.mockReturnValue("admin@example.com"); mocks.getPasswordAccountByEmail.mockResolvedValue(undefined); mocks.hashCustomerPassword.mockResolvedValue("bcrypt-hash");
    await bootstrapInitialAdmin();
    expect(mocks.createPasswordAccount).toHaveBeenCalledWith({ name: "Initial Admin", email: "admin@example.com", passwordHash: "bcrypt-hash", role: "super_admin", createCustomer: false });
  });
});
