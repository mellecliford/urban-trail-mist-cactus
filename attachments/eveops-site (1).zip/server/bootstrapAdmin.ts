import { createPasswordAccount, getPasswordAccountByEmail } from "./db";
import { hashCustomerPassword, normalizeAccountEmail } from "./passwordAuth";

/**
 * External hosting can seed a first administrator with environment variables. It never changes an existing account.
 * Managed Manus deployments omit these values and continue to use the existing OAuth owner administrator path.
 */
export async function bootstrapInitialAdmin() {
  const email = process.env.INITIAL_ADMIN_EMAIL?.trim();
  const password = process.env.INITIAL_ADMIN_PASSWORD;
  const name = process.env.INITIAL_ADMIN_NAME?.trim() || "EveOps Administrator";
  if (!email && !password) return;
  if (!email || !password) { console.warn("[Bootstrap] INITIAL_ADMIN_EMAIL and INITIAL_ADMIN_PASSWORD must be set together."); return; }
  if (password.length < 12) { console.warn("[Bootstrap] Initial administrator password must be at least 12 characters."); return; }
  const normalizedEmail = normalizeAccountEmail(email);
  if (await getPasswordAccountByEmail(normalizedEmail)) return;
  await createPasswordAccount({ name, email: normalizedEmail, passwordHash: await hashCustomerPassword(password), role: "super_admin", createCustomer: false });
  console.log("[Bootstrap] Initial EveOps super administrator created.");
}
