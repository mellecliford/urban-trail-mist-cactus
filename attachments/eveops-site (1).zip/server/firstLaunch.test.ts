import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ createConnection: vi.fn(), drizzle: vi.fn(), migrate: vi.fn(), createPasswordAccount: vi.fn(), getPasswordAccountByEmail: vi.fn(), hasAdministrator: vi.fn(), hashCustomerPassword: vi.fn(), normalizeAccountEmail: vi.fn(), hasRuntimeDatabaseUrl: vi.fn(), persistRuntimeDatabaseUrl: vi.fn() }));
vi.mock("mysql2/promise", () => ({ createConnection: mocks.createConnection }));
vi.mock("drizzle-orm/mysql2", () => ({ drizzle: mocks.drizzle }));
vi.mock("drizzle-orm/mysql2/migrator", () => ({ migrate: mocks.migrate }));
vi.mock("./db", () => ({ createPasswordAccount: mocks.createPasswordAccount, getPasswordAccountByEmail: mocks.getPasswordAccountByEmail, hasAdministrator: mocks.hasAdministrator }));
vi.mock("./passwordAuth", () => ({ hashCustomerPassword: mocks.hashCustomerPassword, normalizeAccountEmail: mocks.normalizeAccountEmail }));
vi.mock("./runtimeConfig", () => ({ hasRuntimeDatabaseUrl: mocks.hasRuntimeDatabaseUrl, persistRuntimeDatabaseUrl: mocks.persistRuntimeDatabaseUrl }));

import { configureFirstLaunch, getFirstLaunchProgress, getFirstLaunchStatus } from "./firstLaunch";

const originalToken = process.env.EVEOPS_SETUP_TOKEN; const originalDatabaseUrl = process.env.DATABASE_URL;
afterEach(() => { process.env.EVEOPS_SETUP_TOKEN = originalToken; process.env.DATABASE_URL = originalDatabaseUrl; vi.clearAllMocks(); });

describe("first-launch setup", () => {
  it("does not claim readiness without a database or configured setup token", async () => {
    delete process.env.DATABASE_URL; delete process.env.EVEOPS_SETUP_TOKEN; mocks.hasRuntimeDatabaseUrl.mockReturnValue(false);
    await expect(getFirstLaunchStatus()).resolves.toEqual({ ready: false, databaseConfigured: false, administratorExists: false, setupTokenConfigured: false });
  });

  it("rejects an incorrect deployment code before touching the database", async () => {
    process.env.EVEOPS_SETUP_TOKEN = "a".repeat(24);
    await expect(configureFirstLaunch({ setupToken: "b".repeat(24), databaseUrl: "mysql://eveops:secret@127.0.0.1:3306/eveops", administratorName: "Owner", administratorEmail: "owner@example.com", administratorPassword: "a-strong-password" })).rejects.toThrow("deployment setup code is incorrect");
    expect(mocks.createConnection).not.toHaveBeenCalled(); expect(mocks.persistRuntimeDatabaseUrl).not.toHaveBeenCalled();
    expect(getFirstLaunchProgress()).toMatchObject({ value: 0, state: "error", label: "Setup code rejected" });
  });

  it("tests the database then persists configuration and creates one super administrator", async () => {
    process.env.EVEOPS_SETUP_TOKEN = "a".repeat(24); mocks.createConnection.mockResolvedValue({ ping: vi.fn(), end: vi.fn() }); mocks.drizzle.mockReturnValue({}); mocks.migrate.mockResolvedValue(undefined); mocks.hasAdministrator.mockResolvedValue(false); mocks.getPasswordAccountByEmail.mockResolvedValue(undefined); mocks.normalizeAccountEmail.mockReturnValue("owner@example.com"); mocks.hashCustomerPassword.mockResolvedValue("bcrypt-hash");
    await expect(configureFirstLaunch({ setupToken: "a".repeat(24), databaseUrl: "mysql://eveops:secret@127.0.0.1:3306/eveops", administratorName: "Owner", administratorEmail: " OWNER@EXAMPLE.COM ", administratorPassword: "a-strong-password" })).resolves.toEqual({ ready: true, administratorEmail: "owner@example.com" });
    expect(mocks.persistRuntimeDatabaseUrl).toHaveBeenCalledWith("mysql://eveops:secret@127.0.0.1:3306/eveops");
    expect(mocks.migrate).toHaveBeenCalled();
    expect(mocks.createPasswordAccount).toHaveBeenCalledWith({ name: "Owner", email: "owner@example.com", passwordHash: "bcrypt-hash", role: "super_admin", createCustomer: false });
    expect(getFirstLaunchProgress()).toMatchObject({ value: 100, state: "success", label: "Setup complete" });
    expect(JSON.stringify(getFirstLaunchProgress())).not.toContain("secret");
  });
});
