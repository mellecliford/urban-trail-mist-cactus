import crypto from "node:crypto";
import path from "node:path";
import { createConnection } from "mysql2/promise";
import { drizzle } from "drizzle-orm/mysql2";
import { migrate } from "drizzle-orm/mysql2/migrator";
import { createPasswordAccount, getPasswordAccountByEmail, hasAdministrator } from "./db";
import { hashCustomerPassword, normalizeAccountEmail } from "./passwordAuth";
import { hasRuntimeDatabaseUrl, persistRuntimeDatabaseUrl } from "./runtimeConfig";

type SetupProgress = { value: number; label: string; detail: string; state: "idle" | "running" | "success" | "error" };
let setupProgress: SetupProgress = { value: 0, label: "Ready for secure setup", detail: "Waiting for deployment configuration.", state: "idle" };
const updateSetupProgress = (next: SetupProgress) => { setupProgress = next; };
export const getFirstLaunchProgress = () => setupProgress;

function tokenMatches(provided: string) {
  const expected = process.env.EVEOPS_SETUP_TOKEN;
  if (!expected || expected.length < 24 || provided.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(expected));
}

export async function getFirstLaunchStatus() {
  const databaseConfigured = Boolean(process.env.DATABASE_URL || hasRuntimeDatabaseUrl());
  if (!databaseConfigured) return { ready: false, databaseConfigured: false, administratorExists: false, setupTokenConfigured: Boolean(process.env.EVEOPS_SETUP_TOKEN && process.env.EVEOPS_SETUP_TOKEN.length >= 24) };
  try {
    const administratorExists = await hasAdministrator();
    return { ready: administratorExists, databaseConfigured: true, administratorExists, setupTokenConfigured: Boolean(process.env.EVEOPS_SETUP_TOKEN && process.env.EVEOPS_SETUP_TOKEN.length >= 24) };
  } catch {
    return { ready: false, databaseConfigured: true, administratorExists: false, setupTokenConfigured: Boolean(process.env.EVEOPS_SETUP_TOKEN && process.env.EVEOPS_SETUP_TOKEN.length >= 24) };
  }
}

export async function configureFirstLaunch(input: { setupToken: string; databaseUrl: string; administratorName: string; administratorEmail: string; administratorPassword: string }) {
  if (!tokenMatches(input.setupToken)) { updateSetupProgress({ value: 0, label: "Setup code rejected", detail: "Enter the current deployment setup code and try again.", state: "error" }); throw new Error("The deployment setup code is incorrect. Check EVEOPS_SETUP_TOKEN on the server and try again."); }
  if (input.administratorPassword.length < 12) { updateSetupProgress({ value: 0, label: "Administrator password rejected", detail: "Use at least 12 characters before continuing.", state: "error" }); throw new Error("Use an administrator password with at least 12 characters."); }
  let url: URL;
  try { url = new URL(input.databaseUrl); } catch { updateSetupProgress({ value: 0, label: "Database URL rejected", detail: "Use a MySQL or MariaDB connection URL.", state: "error" }); throw new Error("Enter a valid MySQL or MariaDB connection URL."); }
  if (!["mysql:", "mysqls:"].includes(url.protocol)) { updateSetupProgress({ value: 0, label: "Database URL rejected", detail: "Use a MySQL or MariaDB connection URL.", state: "error" }); throw new Error("The database URL must begin with mysql:// or mysqls://."); }
  updateSetupProgress({ value: 20, label: "Validating the database connection", detail: "Checking reachability without exposing database credentials.", state: "running" });
  const connection = await createConnection(input.databaseUrl);
  try { await connection.ping(); } catch { updateSetupProgress({ value: 20, label: "Database connection failed", detail: "Review the host, port, database name, and database-user permissions.", state: "error" }); throw new Error("The database could not be reached. Check the host, port, database name, and credentials."); } finally { try { await connection.end(); } catch {} }
  await persistRuntimeDatabaseUrl(input.databaseUrl);
  updateSetupProgress({ value: 55, label: "Applying reviewed database migrations", detail: "Creating or updating the EveOps schema. Connection details remain private.", state: "running" });
  try { await migrate(drizzle(input.databaseUrl), { migrationsFolder: path.resolve(process.cwd(), "drizzle") }); } catch { updateSetupProgress({ value: 55, label: "Database migration failed", detail: "Confirm that the database user can create and alter EveOps tables, then try again.", state: "error" }); throw new Error("The database connection worked, but EveOps could not prepare its schema. Confirm the database user can create and alter tables, then try again."); }
  updateSetupProgress({ value: 82, label: "Creating the initial administrator", detail: "Checking existing access and securely hashing the administrator password.", state: "running" });
  try {
    if (await hasAdministrator()) { updateSetupProgress({ value: 100, label: "Setup is already complete", detail: "An administrator already exists for this deployment.", state: "success" }); throw new Error("Setup is already complete. Sign in with an administrator account."); }
  } catch (error) {
    if (error instanceof Error && error.message === "Setup is already complete. Sign in with an administrator account.") throw error;
    updateSetupProgress({ value: 82, label: "Administrator check failed", detail: "EveOps could not verify the initialized database tables.", state: "error" }); throw new Error("The database connection worked, but the EveOps tables could not be verified. Review the database privileges and try again.");
  }
  const email = normalizeAccountEmail(input.administratorEmail);
  if (await getPasswordAccountByEmail(email)) { updateSetupProgress({ value: 100, label: "Setup is already complete", detail: "An account already exists for this administrator email.", state: "success" }); throw new Error("An account already exists for this administrator email. Sign in instead."); }
  await createPasswordAccount({ name: input.administratorName.trim(), email, passwordHash: await hashCustomerPassword(input.administratorPassword), role: "super_admin", createCustomer: false });
  updateSetupProgress({ value: 100, label: "Setup complete", detail: "The database schema is ready and the administrator is protected by a password hash.", state: "success" });
  return { ready: true, administratorEmail: email };
}
