import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
import { hashCustomerPassword } from "./passwordAuth";

const mocks = vi.hoisted(() => ({
  createCustomerPasswordAccount: vi.fn(),
  getCustomerVerificationRequired: vi.fn(),
  getLatestEmailSettings: vi.fn(),
  getPasswordAccountByEmail: vi.fn(),
  markPasswordAccountLogin: vi.fn(),
  recordAudit: vi.fn(),
  setCustomerVerificationRequired: vi.fn(),
  verifyExistingPasswordAccounts: vi.fn(),
  verifyPasswordAccount: vi.fn(),
  getMediaById: vi.fn(),
  deleteMediaRecord: vi.fn(),
  getAdministratorSecurity: vi.fn(),
  getPasswordAccountByUserId: vi.fn(),
  saveAdministratorPasswordReset: vi.fn(),
  completeAdministratorPasswordReset: vi.fn(),
  consumeAdministratorRecoveryCode: vi.fn(),
  savePendingAdministratorTotp: vi.fn(),
  enableAdministratorTotp: vi.fn(),
  disableAdministratorTotp: vi.fn(),
}));

vi.mock("./db", () => ({
  ...mocks,
  createLead: vi.fn(), createEmailLog: vi.fn(), createMediaRecord: vi.fn(), dashboardOverview: vi.fn(), listLeads: vi.fn(), listMedia: vi.fn(), listPasswordAccounts: vi.fn(), saveEmailSettings: vi.fn(), updateEmailLog: vi.fn(),
}));
vi.mock("./email", () => ({ decryptEmailSecret: vi.fn(), encryptEmailSecret: vi.fn(), renderAdministratorPasswordReset: vi.fn(), renderCustomerVerification: vi.fn(), renderLeadNotification: vi.fn(), sendOperationalEmail: vi.fn(), verifyConfiguredEmail: vi.fn() }));
vi.mock("./media", () => ({ decodePublicMediaDataUrl: vi.fn(), storePublicMedia: vi.fn() }));
const { storageDelete } = vi.hoisted(() => ({ storageDelete: vi.fn() }));
vi.mock("./storage", () => ({ storageDelete }));

import { appRouter } from "./routers";

function context(user: TrpcContext["user"] = null) {
  const cookie = vi.fn();
  return { ctx: { user, req: { protocol: "https", headers: {}, get: () => "example.test" } as TrpcContext["req"], res: { cookie, clearCookie: vi.fn() } as TrpcContext["res"] }, cookie };
}

describe("customer password account routes", () => {
  it("exposes a non-secret first-launch progress payload for the setup wizard", async () => {
    const progress = await appRouter.createCaller(context().ctx).setup.progress();
    expect(progress).toMatchObject({ value: expect.any(Number), label: expect.any(String), detail: expect.any(String), state: expect.any(String) });
    expect(JSON.stringify(progress)).not.toContain("mysql://");
  });

  it("creates an immediately usable customer session when verification is disabled", async () => {
    mocks.getCustomerVerificationRequired.mockResolvedValue(false);
    mocks.getPasswordAccountByEmail.mockResolvedValue(undefined);
    mocks.createCustomerPasswordAccount.mockResolvedValue({ account: { id: 7 }, user: { id: 21, openId: "password:example", name: "Ada", email: "ada@example.com", loginMethod: "password", role: "customer", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() } });
    const { ctx, cookie } = context();
    const result = await appRouter.createCaller(ctx).customerAuth.register({ name: "Ada", email: " ADA@Example.COM ", password: "a-safe-password" });
    expect(mocks.createCustomerPasswordAccount).toHaveBeenCalledWith(expect.objectContaining({ email: "ada@example.com" }));
    expect(result.needsVerification).toBe(false);
    expect(cookie).toHaveBeenCalledWith("eveops_session", expect.any(String), expect.objectContaining({ httpOnly: true, secure: true }));
  });

  it("rejects a customer login with an invalid password without creating a session", async () => {
    mocks.getPasswordAccountByEmail.mockResolvedValue({ account: { passwordHash: await hashCustomerPassword("correct-password"), emailVerified: true }, user: { id: 21, role: "customer" }, customerStatus: "active" });
    const { ctx, cookie } = context();
    await expect(appRouter.createCaller(ctx).customerAuth.login({ email: "ada@example.com", password: "incorrect-password" })).rejects.toThrow("Email or password is incorrect.");
    expect(cookie).not.toHaveBeenCalled();
  });

  it("does not allow an administrator to require verification before SMTP delivery is enabled", async () => {
    mocks.getLatestEmailSettings.mockResolvedValue(undefined);
    const admin = { id: 1, openId: "owner", name: "Owner", email: "owner@example.com", loginMethod: "manus", role: "admin" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    await expect(appRouter.createCaller(context(admin).ctx).admin.customerAccounts.savePolicy({ requiresEmailVerification: true })).rejects.toThrow("Enable and verify SMTP delivery before requiring customer email verification.");
    expect(mocks.setCustomerVerificationRequired).not.toHaveBeenCalled();
  });

  it("reports the default-off verification policy and blocks an unverified customer only when the policy is enabled", async () => {
    mocks.getCustomerVerificationRequired.mockResolvedValueOnce(false);
    await expect(appRouter.createCaller(context().ctx).customerAuth.policy()).resolves.toEqual({ requiresEmailVerification: false });
    mocks.getCustomerVerificationRequired.mockResolvedValueOnce(true);
    mocks.getPasswordAccountByEmail.mockResolvedValue({ account: { passwordHash: await hashCustomerPassword("correct-password"), emailVerified: false }, user: { id: 21, role: "customer" }, customerStatus: "active" });
    const { ctx, cookie } = context();
    await expect(appRouter.createCaller(ctx).customerAuth.login({ email: "ada@example.com", password: "correct-password" })).rejects.toThrow("Confirm your email address before signing in.");
    expect(cookie).not.toHaveBeenCalled();
  });

  it("allows a verified customer and a valid confirmation token to establish the password session", async () => {
    mocks.getCustomerVerificationRequired.mockResolvedValueOnce(true);
    mocks.getPasswordAccountByEmail.mockResolvedValue({ account: { passwordHash: await hashCustomerPassword("correct-password"), emailVerified: true }, user: { id: 21, openId: "password:example", name: "Ada", email: "ada@example.com", loginMethod: "password", role: "customer", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, customerStatus: "active" });
    const signedIn = context();
    await expect(appRouter.createCaller(signedIn.ctx).customerAuth.login({ email: "ada@example.com", password: "correct-password" })).resolves.toMatchObject({ user: { id: 21 } });
    expect(signedIn.cookie).toHaveBeenCalledWith("eveops_session", expect.any(String), expect.objectContaining({ httpOnly: true, secure: true }));
    mocks.verifyPasswordAccount.mockResolvedValue({ id: 21, openId: "password:example", name: "Ada", email: "ada@example.com", loginMethod: "password", role: "customer", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() });
    const confirmed = context();
    await expect(appRouter.createCaller(confirmed.ctx).customerAuth.verifyEmail({ token: "a".repeat(40) })).resolves.toMatchObject({ success: true, user: { id: 21 } });
    expect(confirmed.cookie).toHaveBeenCalledWith("eveops_session", expect.any(String), expect.objectContaining({ httpOnly: true, secure: true }));
  });

  it("keeps customer and administrator password access routes role-separated", async () => {
    const passwordHash = await hashCustomerPassword("correct-password");
    mocks.getPasswordAccountByEmail.mockResolvedValueOnce({ account: { passwordHash, emailVerified: true }, user: { id: 33, role: "admin" }, customerStatus: undefined });
    await expect(appRouter.createCaller(context().ctx).customerAuth.login({ email: "admin@example.com", password: "correct-password" })).rejects.toThrow("Email or password is incorrect.");
    mocks.getPasswordAccountByEmail.mockResolvedValueOnce({ account: { passwordHash, emailVerified: true }, user: { id: 34, role: "customer" }, customerStatus: "active" });
    await expect(appRouter.createCaller(context().ctx).adminAuth.login({ email: "customer@example.com", password: "correct-password" })).rejects.toThrow("Administrator email or password is incorrect.");
    mocks.getPasswordAccountByEmail.mockResolvedValueOnce({ account: { passwordHash, emailVerified: true }, user: { id: 35, role: "super_admin" }, customerStatus: undefined });
    const administrator = context();
    await expect(appRouter.createCaller(administrator.ctx).adminAuth.login({ email: "owner@example.com", password: "correct-password" })).resolves.toMatchObject({ user: { id: 35 } });
    expect(administrator.cookie).toHaveBeenCalledWith("eveops_session", expect.any(String), expect.objectContaining({ httpOnly: true, secure: true }));
  });

  it("requires a short-lived TOTP challenge after a valid administrator password when optional two-factor authentication is enabled", async () => {
    const passwordHash = await hashCustomerPassword("correct-password");
    mocks.getPasswordAccountByEmail.mockResolvedValue({ account: { id: 35, passwordHash, emailVerified: true }, user: { id: 35, role: "super_admin" }, customerStatus: undefined });
    mocks.getAdministratorSecurity.mockResolvedValue({ userId: 35, totpEnabled: true, encryptedTotpSecret: "ciphertext" });
    const administrator = context();
    await expect(appRouter.createCaller(administrator.ctx).adminAuth.login({ email: "owner@example.com", password: "correct-password" })).resolves.toEqual({ requiresTwoFactor: true });
    expect(administrator.cookie).toHaveBeenCalledWith("eveops_admin_2fa", expect.any(String), expect.objectContaining({ httpOnly: true }));
    expect(administrator.cookie).not.toHaveBeenCalledWith("eveops_session", expect.anything(), expect.anything());
  });

  it("returns the same accepted reset response for a non-existent administrator email", async () => {
    mocks.getPasswordAccountByEmail.mockResolvedValue(undefined);
    await expect(appRouter.createCaller(context().ctx).adminAuth.requestPasswordReset({ email: "unknown@example.com" })).resolves.toEqual({ accepted: true });
    expect(mocks.saveAdministratorPasswordReset).not.toHaveBeenCalled();
  });

  it("deletes a media object before removing its database record", async () => {
    const admin = { id: 1, openId: "owner", name: "Owner", email: "owner@example.com", loginMethod: "password", role: "admin" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    mocks.getMediaById.mockResolvedValue({ id: 5, filename: "brand.png", fileKey: "eveops/public/1/brand.png" });
    await expect(appRouter.createCaller(context(admin).ctx).media.delete({ id: 5 })).resolves.toEqual({ id: 5, filename: "brand.png" });
    expect(storageDelete).toHaveBeenCalledWith("eveops/public/1/brand.png");
    expect(mocks.deleteMediaRecord).toHaveBeenCalledWith(5);
  });

  it("bulk-deletes selected media objects independently and reports every completed deletion", async () => {
    const admin = { id: 1, openId: "owner", name: "Owner", email: "owner@example.com", loginMethod: "password", role: "admin" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    mocks.getMediaById.mockResolvedValueOnce({ id: 6, filename: "one.png", fileKey: "eveops/public/1/one.png" }).mockResolvedValueOnce({ id: 7, filename: "two.png", fileKey: "eveops/public/1/two.png" });
    await expect(appRouter.createCaller(context(admin).ctx).media.bulkDelete({ ids: [6, 7] })).resolves.toEqual({ deleted: [{ id: 6, filename: "one.png" }, { id: 7, filename: "two.png" }], failed: [] });
    expect(storageDelete).toHaveBeenCalledWith("eveops/public/1/one.png");
    expect(storageDelete).toHaveBeenCalledWith("eveops/public/1/two.png");
    expect(mocks.deleteMediaRecord).toHaveBeenCalledWith(6);
    expect(mocks.deleteMediaRecord).toHaveBeenCalledWith(7);
  });
});
