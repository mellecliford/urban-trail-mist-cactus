import PDFDocument from "pdfkit";

export type ProfileLocale = "en" | "fr";

type DetailItem = { label: string; title: string; body: string };
type DetailPage = { section: string; kicker: string; title: string; intro: string; items: DetailItem[]; closing: string };

const colors = {
  navy: "#07111F",
  ink: "#122238",
  cobalt: "#2C63E7",
  cyan: "#63D9E6",
  paper: "#F7F7F3",
  mist: "#E9EFF8",
  unity: "#183D33",
  saffron: "#D79935",
  terracotta: "#B95C43",
  muted: "#526274",
  line: "#CBD5E1",
  white: "#FFFFFF",
};

const profiles: Record<ProfileLocale, { coverKicker: string; coverTitle: string[]; coverBody: string; coverNote: string; footer: string; contactTitle: string; contactBody: string; contactPrompt: string; contactRows: DetailItem[]; close: string; pages: DetailPage[] }> = {
  en: {
    coverKicker: "DETAILED COMPANY PROFILE  /  PROFESSIONAL SERVICES + DIGITAL SYSTEMS",
    coverTitle: ["The work behind", "the work, made", "more possible."],
    coverBody: "A detailed introduction to eveOps Group, Unity Integrated Solutions, and EveDev Ops — for teams deciding how to move an operating need into a structured next step.",
    coverNote: "A reader-ready company profile. Not a project brief.",
    footer: "eveOps Group  ·  Detailed company profile  ·  English edition",
    contactTitle: "Bring the context. We will help organize the next step.",
    contactBody: "This profile is designed to be read and shared before a conversation. When you are ready, the first exchange can stay simple: tell us what needs to change, who or what is affected, and what a useful outcome would look like.",
    contactPrompt: "The most useful first conversations begin with the work, not a finished specification.",
    contactRows: [
      { label: "01", title: "The outcome", body: "Name the result you need: a reliable delivery flow, stronger data, a clearer user experience, less manual work, or a system that supports a team better." },
      { label: "02", title: "The operating context", body: "Share the people, workflow, material, systems, markets, or constraints that give the work its real shape." },
      { label: "03", title: "The decision to make", body: "A first conversation can clarify whether the next step is a scoped service, a discovery session, a product plan, or a combination of practices." },
      { label: "04", title: "The route to reach us", body: "eveopsgroup.com/contact  ·  support@eveopsgroup.com  ·  +237 671 361 513" },
    ],
    close: "Professional capacity. Digital systems. A clearer route into the work.",
    pages: [
      {
        section: "THE GROUP", kicker: "01  /  ONE GROUP, TWO PRACTICES", title: "A structure built around what the work needs next.",
        intro: "eveOps Group brings together two distinct practices: Unity Integrated Solutions for structured professional capacity, and EveDev Ops for software, AI, automation, and digital product work. They are deliberately different, but can meet when a challenge needs both people and systems.",
        items: [
          { label: "UNITY", title: "Professional services with a defined delivery path", body: "Unity supports language work, AI data, research, content operations, procurement, and workforce needs. Its value is not simply access to individuals; it is coordinated capacity shaped around a specific brief and a clear handover." },
          { label: "EVEDEV", title: "Digital systems connected to operating reality", body: "EveDev Ops designs websites, platforms, applications, APIs, automation, AI capabilities, and deployment foundations. The work starts with the product, user, workflow, or operating problem the system should improve." },
          { label: "THE SEAM", title: "Independent practices that can work together", body: "Some initiatives need a capable service team, others need an engineered system, and some require both. The group model makes the starting point clearer without forcing every engagement into the same method." },
          { label: "THE PRINCIPLE", title: "Context before catalogue", body: "The aim is to route a conversation by the outcome that matters, the constraints that shape it, and the form of support that can make a useful difference." },
        ], closing: "Two practices, clearly positioned — with a route for work that crosses the boundary between them.",
      },
      {
        section: "UNITY INTEGRATED SOLUTIONS", kicker: "02  /  PROFESSIONAL SERVICES", title: "Coordinated professional capacity for work that requires care, context, and control.",
        intro: "Unity Integrated Solutions is a professional-services practice for organizations that need dependable human expertise and structured operational support. It is designed for work where quality, instructions, specialist judgement, and a usable handover matter as much as throughput.",
        items: [
          { label: "01", title: "A brief-led way of working", body: "Unity begins by understanding the material or task, the intended audience or use, expected quality, review requirements, constraints, and timing. This creates a working route before tasks are assigned or delivery is promised." },
          { label: "02", title: "Capacity shaped to the service", body: "Language, research, data, content, procurement, and support work each require different combinations of subject familiarity, process discipline, quality control, and escalation. Unity organizes the relevant capability around that reality." },
          { label: "03", title: "Defined handovers rather than loose activity", body: "A useful delivery has an agreed format, traceable inputs and outputs, visible quality expectations, and clarity about what has been completed, reviewed, or requires a decision." },
          { label: "04", title: "A practical route for distributed work", body: "For work involving multiple markets, languages, contributors, or recurring cycles, Unity helps turn dispersed activity into an operating flow with clearer coordination and delivery expectations." },
        ], closing: "Unity is not a generic talent marketplace. It is structured professional support designed around the work itself.",
      },
      {
        section: "UNITY INTEGRATED SOLUTIONS", kicker: "03  /  LANGUAGE, COMMUNICATION + TRANSCRIPTION", title: "Language work that respects audience, intent, and the point of use.",
        intro: "Translation is rarely only about changing words. It can involve market context, terminology, tone, review, accessibility, timing, and the systems where content will eventually be published. Unity organizes language and transcription services around those practical conditions.",
        items: [
          { label: "TRANSLATION", title: "From source material to usable target-language content", body: "Translation engagements can begin with files, web content, product strings, support material, learning content, or operational documents. The useful starting context includes source and target languages, intended audience, terminology, volume, review path, and delivery format." },
          { label: "LOCALIZATION", title: "Adapt content for a market, not only a language", body: "Localization considers context such as local conventions, user expectations, product terminology, formatting, interfaces, date or currency handling, and the places where translated content must function alongside the original system." },
          { label: "TRANSCREATION + EDITING", title: "Protect meaning when direct conversion is not enough", body: "Campaign, brand, product, and audience-facing material may need a response that preserves intent and effect rather than wording alone. Review, proofreading, and linguistic QA provide different ways to examine accuracy, consistency, and readiness." },
          { label: "TRANSCRIPTION", title: "Turn audio or video into a structured working asset", body: "A transcription brief becomes more useful when it specifies recording format, languages or speakers, expected accuracy, timestamps, speaker labels, confidentiality considerations, and the downstream use of the transcript." },
        ], closing: "The output should serve a real decision, publication, workflow, or audience — not simply arrive as a completed file.",
      },
      {
        section: "UNITY INTEGRATED SOLUTIONS", kicker: "04  /  AI DATA + RESEARCH", title: "Make data and research work usable for the decision it needs to support.",
        intro: "AI data and research assignments are strongest when the intended use is clear from the start. Whether the work involves annotation, evaluation, collection, verification, enrichment, or research, Unity focuses on the criteria that make an output reliable enough to use.",
        items: [
          { label: "AI DATA", title: "Annotation and evaluation with explicit acceptance criteria", body: "Data work can involve text, images, audio, video, documents, or structured records. A useful brief defines the task, examples of acceptable output, edge cases, reviewer roles, quality checks, privacy boundaries, and volume or cadence." },
          { label: "DATA PREPARATION", title: "Prepare information for a usable downstream workflow", body: "Collection, classification, verification, enrichment, cleansing, and normalization can help turn inconsistent or dispersed material into something a team, model, analyst, or system can assess and work with." },
          { label: "RESEARCH", title: "Find and organize evidence around a practical question", body: "Research support is more valuable when connected to the decision at hand: the market, sources, geographic scope, inclusion rules, fields to collect, comparison structure, validation needs, and desired presentation." },
          { label: "QUALITY", title: "Treat review as part of the work, not an afterthought", body: "Quality control can include samples, guidance calibration, spot checks, exception handling, feedback loops, and defined escalation where a requirement, source, or case needs human judgement." },
        ], closing: "A larger dataset or a longer research list is not automatically better. The useful output is the one that can be trusted in context.",
      },
      {
        section: "UNITY INTEGRATED SOLUTIONS", kicker: "05  /  CONTENT, WORKFORCE + PROCUREMENT", title: "Support operating work with clearer roles, rules, and handovers.",
        intro: "Many recurring operational demands are not difficult because they are small; they are difficult because they repeat, cross teams, require judgement, or arrive without a reliable process. Unity provides structured professional support for those conditions.",
        items: [
          { label: "CONTENT OPS", title: "Content review and moderation with usable guardrails", body: "Content operations can include classification, review, moderation, tagging, quality assurance, or preparation. A responsible brief establishes the content type, decision rules, escalation path, expected volume, sensitivity, and destination workflow." },
          { label: "VIRTUAL WORKFORCE", title: "Support for recurring work that needs accountability", body: "Virtual assistance, customer support, back-office processing, and operational coordination work best with clear task ownership, tools, access boundaries, coverage expectations, reporting, and handover arrangements." },
          { label: "PROCUREMENT", title: "Research and coordination for sourcing decisions", body: "Procurement support can cover supplier discovery, request-for-quotation preparation, comparison, vendor information, sourcing coordination, and logistics-aware research. The relevant criteria, markets, budget context, and decision format should shape the work." },
          { label: "OPERATING DESIGN", title: "Bring the work into a repeatable delivery loop", body: "Across services, Unity can help make the practical rhythm visible: what arrives, who reviews it, what is completed, how exceptions are raised, and what a useful final handover contains." },
        ], closing: "The objective is more than task completion: it is a working path that is easier for the client team to understand and use.",
      },
      {
        section: "EVEDEV OPS", kicker: "06  /  DIGITAL SYSTEMS", title: "Engineering and product work that begins with the operating outcome.",
        intro: "EveDev Ops develops digital products and systems for organizations that need software to improve how work is delivered, experienced, measured, connected, or scaled. Technology choices matter, but they follow the product, workflow, audience, and risk that shape the engagement.",
        items: [
          { label: "PRODUCT THINKING", title: "Define what the system should make possible", body: "Before features are listed, it helps to understand the people involved, the situation they face, the current process, friction points, desired result, measures of usefulness, and constraints such as time, data, access, or legacy systems." },
          { label: "ENGINEERING", title: "Build with an eye on the whole operating picture", body: "Web applications, mobile experiences, portals, internal tools, platforms, APIs, and automation are considered as systems that must function for users, operators, administrators, and the organization that will maintain them." },
          { label: "DELIVERY", title: "Turn decisions into a practical sequence of work", body: "The next step may be discovery, architecture, a focused prototype, a scoped build, an integration plan, a modernization path, or a product roadmap. The appropriate format follows the uncertainty and impact of the decision." },
          { label: "CONTINUITY", title: "Plan beyond the launch moment", body: "A working system also needs visibility, improvement, operational ownership, release discipline, security consideration, and a route for responding when requirements or conditions change." },
        ], closing: "EveDev Ops treats a digital build as an operating capability, not a static deliverable disconnected from the work around it.",
      },
      {
        section: "EVEDEV OPS", kicker: "07  /  PRODUCTS + PLATFORMS", title: "Digital products that give users and teams a clearer path through the work.",
        intro: "A website, application, portal, SaaS product, or internal platform has to work for its intended audience and the people who operate it. EveDev Ops considers the information, interactions, integrations, access, and lifecycle that make a product credible after it is released.",
        items: [
          { label: "WEB", title: "Web experiences built for a defined audience and action", body: "Corporate sites, service platforms, dashboards, commerce experiences, knowledge surfaces, and custom web applications can be shaped around the visitor or user journey, content model, business process, data needs, and conversion or operating goals." },
          { label: "MOBILE", title: "Mobile flows where context and continuity matter", body: "Mobile work starts with a user scenario: who is using the app, on which device, under what conditions, with which permissions or network assumptions, and how the mobile experience connects to the rest of the operating environment." },
          { label: "SAAS + PORTALS", title: "Platforms for roles, workflows, and recurring value", body: "A SaaS platform or portal needs an informed view of users, roles, tenancy or account structures, critical journeys, data lifecycle, administration, support requirements, and the decisions the product should make easier." },
          { label: "INTERNAL SYSTEMS", title: "Tools that reduce friction inside an organization", body: "Internal applications can centralize an operational process, make requests visible, replace fragile manual handoffs, provide traceability, or connect data that teams otherwise rebuild repeatedly across spreadsheets and messages." },
        ], closing: "The strongest product plans describe what should improve for users and operators — before they become a backlog of isolated screens.",
      },
      {
        section: "EVEDEV OPS", kicker: "08  /  APPLIED AI + AUTOMATION", title: "Use automation and AI where they improve a real decision, process, or experience.",
        intro: "Applied AI and automation should be tied to a clear task and operating safeguard. EveDev Ops explores the practical place for these capabilities within a product or workflow: what triggers the work, what information is used, what an acceptable result looks like, and where human review remains important.",
        items: [
          { label: "AI APPLICATIONS", title: "Bring AI into a product with a defined role", body: "AI functionality may help users retrieve information, draft, classify, summarize, extract, evaluate, assist with decisions, or work across documents. The product context determines whether it is useful, how it is presented, and how outputs are reviewed." },
          { label: "AGENTS + WORKFLOWS", title: "Automate a sequence, not only a single task", body: "Agent-like or workflow automation can coordinate retrieval, transformation, routing, notification, approval, and follow-up. A useful design identifies initiating events, connected systems, exceptions, ownership, and the point where a person needs to intervene." },
          { label: "DOCUMENT INTELLIGENCE", title: "Turn documents into structured working information", body: "Document-oriented solutions may extract fields, classify material, identify information for review, support search, or feed a downstream process. Source quality, required accuracy, privacy, auditability, and error handling are part of the early design." },
          { label: "MEASUREMENT", title: "Evaluate usefulness in the operating environment", body: "For AI and automation, performance is more than technical output. The relevant question is whether the capability makes a workflow faster, clearer, safer, more consistent, or more useful for the people responsible for the result." },
        ], closing: "The right AI or automation capability is one that earns its place in the workflow — with clear boundaries and a useful human experience.",
      },
      {
        section: "EVEDEV OPS", kicker: "09  /  CLOUD, SECURITY + INTEGRATION", title: "Create dependable connections between systems, delivery, and operating responsibility.",
        intro: "Digital products do not operate alone. They depend on deployment environments, access rules, data flows, third-party services, monitoring, and teams that need to understand what is happening. EveDev Ops addresses these foundations as part of a coherent operating system.",
        items: [
          { label: "APIS", title: "Connect systems around the information that must move", body: "API and integration work begins with source and destination systems, the data that matters, triggering events, expected reliability, ownership boundaries, authentication, error cases, and the users or operators affected when the connection fails." },
          { label: "CLOUD + DEVOPS", title: "Make delivery and operations more repeatable", body: "Cloud architecture, containers, CI/CD, environments, infrastructure automation, deployment, and monitoring can create a safer path from change to release while giving teams clearer visibility into the software they run." },
          { label: "SECURITY", title: "Consider protection in the context of the system", body: "Application security is shaped by assets, users, roles, access patterns, data sensitivity, threat concerns, and any relevant compliance context. Security work is most useful when it informs a practical risk decision rather than remaining a detached checklist." },
          { label: "RELIABILITY", title: "Prepare for exceptions, not only the happy path", body: "Dependable systems need consideration for failed requests, missing data, degraded services, retries, visibility, escalation, recovery, and the operational information a team needs to respond well." },
        ], closing: "A connected system is only as useful as its ability to be understood, maintained, and trusted under real operating conditions.",
      },
      {
        section: "WORKING ACROSS THE GROUP", kicker: "10  /  WHEN PEOPLE + SYSTEMS MEET", title: "A coordinated route when the work needs both capacity and technology.",
        intro: "Some challenges sit at the seam between professional services and digital systems. A platform may need content operations, a data initiative may need annotation and product design, or a recurring service process may benefit from a better workflow and an integrated system. eveOps Group provides a way to frame that intersection.",
        items: [
          { label: "START WITH THE WORK", title: "Identify the operating change that matters", body: "The starting question is not which division should be used. It is what needs to improve, who is involved, what currently happens, and where human expertise, system design, or both can make the change more achievable." },
          { label: "ROUTE THE PRACTICE", title: "Use Unity, EveDev, or a thoughtful combination", body: "Unity can lead when the core need is structured professional capacity. EveDev can lead when the primary issue is a product, system, integration, or automation. The group can help sequence work when the two areas are connected." },
          { label: "DEFINE THE INTERFACE", title: "Make handoffs between people and systems visible", body: "Combined work benefits from clarity about inputs, outputs, ownership, quality thresholds, user needs, operational data, exception paths, and how the people responsible for delivery will work with the system." },
          { label: "KEEP THE NEXT STEP PROPORTIONATE", title: "Choose a useful level of discovery or scope", body: "Not every situation needs a large programme to begin. A first discussion can identify the smallest informed next step that reduces uncertainty and gives the team a clearer decision path." },
        ], closing: "The group model exists to make a connected challenge easier to approach — not to make a simple challenge unnecessarily complex.",
      },
      {
        section: "HOW WE WORK", kicker: "11  /  FROM CONTEXT TO A USEFUL NEXT STEP", title: "A first conversation that makes the work easier to understand.",
        intro: "An initial contact does not need to solve every requirement. It should establish enough shared context to identify the appropriate practice, ask the useful next questions, and propose a responsible way to proceed. The quality of this early framing affects everything that follows.",
        items: [
          { label: "01", title: "Describe the outcome and the current reality", body: "What is changing or not working? What would a better result make possible? Who is affected? What does the present workflow, system, or service arrangement look like?" },
          { label: "02", title: "Share the information that gives the work shape", body: "Depending on the engagement, that may include source material, data samples, systems, user roles, process maps, volumes, markets, timing, technical constraints, existing tools, or review requirements." },
          { label: "03", title: "Make constraints and quality expectations visible", body: "Delivery standards, confidentiality, access boundaries, approvals, deadlines, escalation needs, handover formats, and measurements of usefulness often determine the right structure for an engagement." },
          { label: "04", title: "Agree the most responsible next step", body: "The outcome may be a focused reply, a service scope, discovery workshop, architecture or product discussion, data-quality approach, operational plan, or a clearer route to the people and information needed next." },
        ], closing: "A useful brief is not a long document. It is enough clarity to make the next decision better than the last one.",
      },
    ],
  },
  fr: {
    coverKicker: "PROFIL DÉTAILLÉ D’ENTREPRISE  /  SERVICES PROFESSIONNELS + SYSTÈMES NUMÉRIQUES",
    coverTitle: ["Le travail derrière", "le travail, rendu", "plus possible."],
    coverBody: "Une présentation détaillée d’eveOps Group, de Unity Integrated Solutions et d’EveDev Ops, destinée aux équipes qui cherchent à transformer un besoin opérationnel en prochaine étape structurée.",
    coverNote: "Un profil d’entreprise conçu pour être lu et partagé. Pas un brief de projet.",
    footer: "eveOps Group  ·  Profil détaillé d’entreprise  ·  Édition française",
    contactTitle: "Apportez le contexte. Nous organiserons la prochaine étape avec vous.",
    contactBody: "Ce profil est conçu pour être lu et partagé avant un premier échange. Lorsque vous êtes prêt, la conversation peut rester simple : dites-nous ce qui doit évoluer, qui ou quoi est concerné, et à quoi ressemblerait un résultat utile.",
    contactPrompt: "Les premiers échanges les plus utiles commencent par le travail, non par un cahier des charges finalisé.",
    contactRows: [
      { label: "01", title: "Le résultat attendu", body: "Présentez le changement recherché : une livraison plus fiable, des données plus solides, une expérience utilisateur plus claire, moins de tâches manuelles ou un système qui soutient mieux une équipe." },
      { label: "02", title: "Le contexte opérationnel", body: "Partagez les personnes, flux de travail, contenus, systèmes, marchés ou contraintes qui donnent au besoin sa forme réelle." },
      { label: "03", title: "La décision à éclairer", body: "Un premier échange peut préciser si la prochaine étape est un service cadré, une session de découverte, un plan produit ou une combinaison de pratiques." },
      { label: "04", title: "Le moyen de nous joindre", body: "eveopsgroup.com/contact?lang=fr  ·  support@eveopsgroup.com  ·  +237 671 361 513" },
    ],
    close: "Capacité professionnelle. Systèmes numériques. Une voie plus claire vers le travail à accomplir.",
    pages: [
      {
        section: "LE GROUPE", kicker: "01  /  UN GROUPE, DEUX PRATIQUES", title: "Une structure construite autour de ce dont le travail a besoin ensuite.",
        intro: "eveOps Group réunit deux pratiques distinctes : Unity Integrated Solutions pour une capacité professionnelle structurée, et EveDev Ops pour les logiciels, l’IA, l’automatisation et les produits numériques. Elles restent volontairement différentes, mais peuvent se rejoindre lorsqu’un enjeu exige à la fois des personnes et des systèmes.",
        items: [
          { label: "UNITY", title: "Des services professionnels avec un parcours de livraison défini", body: "Unity intervient sur les langues, les données IA, la recherche, les opérations de contenu, les achats et les besoins d’équipe. Sa valeur ne réside pas seulement dans l’accès à des personnes, mais dans une capacité coordonnée organisée autour d’un brief précis et d’une remise claire." },
          { label: "EVEDEV", title: "Des systèmes numériques reliés à la réalité opérationnelle", body: "EveDev Ops conçoit des sites, plateformes, applications, API, automatisations, capacités IA et fondations de déploiement. Le travail commence par le produit, l’utilisateur, le flux de travail ou le problème opérationnel que le système doit améliorer." },
          { label: "LE POINT DE RENCONTRE", title: "Des pratiques indépendantes qui peuvent travailler ensemble", body: "Certaines initiatives nécessitent une équipe de service compétente, d’autres un système conçu sur mesure, et d’autres encore les deux. Le modèle de groupe clarifie le point de départ sans imposer une méthode unique à chaque engagement." },
          { label: "LE PRINCIPE", title: "Le contexte avant le catalogue", body: "L’objectif est d’orienter l’échange en fonction du résultat recherché, des contraintes qui le façonnent et de la forme de soutien qui peut apporter une amélioration utile." },
        ], closing: "Deux pratiques, clairement positionnées, avec une voie adaptée aux travaux situés entre elles.",
      },
      {
        section: "UNITY INTEGRATED SOLUTIONS", kicker: "02  /  SERVICES PROFESSIONNELS", title: "Une capacité professionnelle coordonnée pour un travail qui exige soin, contexte et contrôle.",
        intro: "Unity Integrated Solutions est une pratique de services professionnels destinée aux organisations qui ont besoin d’expertise humaine fiable et de soutien opérationnel structuré. Elle convient aux travaux où la qualité, les consignes, le jugement spécialisé et une remise exploitable comptent autant que le volume traité.",
        items: [
          { label: "01", title: "Une méthode guidée par le brief", body: "Unity commence par comprendre les contenus ou tâches, l’audience ou l’usage visé, le niveau de qualité attendu, les exigences de révision, les contraintes et le calendrier. Cette étape crée un parcours de travail avant toute attribution ou promesse de livraison." },
          { label: "02", title: "Une capacité adaptée au service", body: "Les langues, la recherche, les données, le contenu, les achats et le soutien opérationnel demandent des combinaisons différentes de connaissance métier, de discipline de processus, de contrôle qualité et d’escalade. Unity organise la capacité pertinente autour de cette réalité." },
          { label: "03", title: "Des remises définies plutôt qu’une activité diffuse", body: "Une livraison utile comprend un format convenu, des entrées et sorties traçables, des attentes de qualité visibles et une clarté sur ce qui est achevé, revu ou nécessite une décision." },
          { label: "04", title: "Un parcours pratique pour le travail distribué", body: "Lorsqu’un travail concerne plusieurs marchés, langues, contributeurs ou cycles récurrents, Unity aide à transformer une activité dispersée en flux plus lisible avec une coordination et des attentes de livraison plus claires." },
        ], closing: "Unity n’est pas une place de marché de talents générique. C’est un soutien professionnel structuré autour du travail réel.",
      },
      {
        section: "UNITY INTEGRATED SOLUTIONS", kicker: "03  /  LANGUES, COMMUNICATION + TRANSCRIPTION", title: "Un travail linguistique attentif à l’audience, à l’intention et au contexte d’usage.",
        intro: "La traduction ne consiste rarement à remplacer des mots. Elle peut engager le contexte d’un marché, la terminologie, le ton, la révision, l’accessibilité, le calendrier et les systèmes où le contenu sera publié. Unity organise les services linguistiques et de transcription autour de ces conditions pratiques.",
        items: [
          { label: "TRADUCTION", title: "Du contenu source à un résultat exploitable dans la langue cible", body: "Les engagements de traduction peuvent partir de fichiers, de contenus web, de chaînes produit, de supports d’assistance, de contenus d’apprentissage ou de documents opérationnels. Les informations utiles comprennent les langues, l’audience, la terminologie, le volume, la révision et le format de remise." },
          { label: "LOCALISATION", title: "Adapter un contenu à un marché, pas seulement à une langue", body: "La localisation tient compte de conventions locales, d’attentes utilisateurs, de terminologie produit, de formats, d’interfaces, de dates ou devises et des endroits où le contenu traduit doit fonctionner avec le système d’origine." },
          { label: "TRANSCREATION + RÉVISION", title: "Préserver le sens lorsqu’une conversion directe ne suffit pas", body: "Les contenus de campagne, de marque, de produit ou destinés au public peuvent demander une réponse qui préserve l’intention et l’effet, plutôt que les mots seuls. La révision, la relecture et l’assurance qualité linguistique offrent des niveaux de contrôle complémentaires." },
          { label: "TRANSCRIPTION", title: "Transformer un enregistrement en ressource de travail structurée", body: "Un brief de transcription devient plus utile lorsqu’il précise le format, les langues ou locuteurs, le niveau de précision, les repères temporels, l’identification des intervenants, la confidentialité et l’usage prévu du document final." },
        ], closing: "Le résultat doit servir une décision, une publication, un flux de travail ou une audience réelle, pas seulement arriver sous la forme d’un fichier achevé.",
      },
      {
        section: "UNITY INTEGRATED SOLUTIONS", kicker: "04  /  DONNÉES IA + RECHERCHE", title: "Rendre les données et la recherche utiles pour la décision qu’elles doivent soutenir.",
        intro: "Les missions de données IA et de recherche sont plus solides lorsque l’usage prévu est clair dès le départ. Qu’il s’agisse d’annotation, d’évaluation, de collecte, de vérification, d’enrichissement ou de recherche, Unity se concentre sur les critères qui rendent un résultat suffisamment fiable pour être utilisé.",
        items: [
          { label: "DONNÉES IA", title: "Annotation et évaluation avec des critères d’acceptation explicites", body: "Le travail sur les données peut concerner du texte, des images, de l’audio, de la vidéo, des documents ou des enregistrements structurés. Un brief utile définit la tâche, des exemples acceptables, les cas limites, les rôles de révision, les contrôles qualité, les limites de confidentialité et le volume." },
          { label: "PRÉPARATION", title: "Préparer l’information pour un flux de travail exploitable", body: "La collecte, la classification, la vérification, l’enrichissement, le nettoyage et la normalisation peuvent transformer des contenus incohérents ou dispersés en informations qu’une équipe, un modèle, un analyste ou un système peut examiner et utiliser." },
          { label: "RECHERCHE", title: "Trouver et organiser des éléments autour d’une question concrète", body: "Le soutien à la recherche prend de la valeur lorsqu’il reste relié à la décision : marché, sources, périmètre géographique, règles d’inclusion, champs à collecter, structure de comparaison, besoins de validation et format de restitution." },
          { label: "QUALITÉ", title: "Intégrer la révision au travail dès le départ", body: "Le contrôle qualité peut inclure des échantillons, l’étalonnage des consignes, des vérifications ponctuelles, la gestion des exceptions, des boucles de retour et une escalade définie lorsqu’un cas demande du jugement humain." },
        ], closing: "Un jeu de données plus grand ou une liste plus longue ne sont pas automatiquement meilleurs. Le résultat utile est celui auquel on peut faire confiance dans son contexte.",
      },
      {
        section: "UNITY INTEGRATED SOLUTIONS", kicker: "05  /  CONTENU, ÉQUIPES + ACHATS", title: "Soutenir le travail opérationnel avec des rôles, règles et remises plus clairs.",
        intro: "De nombreux besoins opérationnels récurrents ne sont pas difficiles parce qu’ils sont modestes, mais parce qu’ils se répètent, traversent des équipes, exigent du jugement ou arrivent sans processus fiable. Unity apporte un soutien professionnel structuré à ces situations.",
        items: [
          { label: "OPÉRATIONS DE CONTENU", title: "Révision et modération de contenu avec des garde-fous utiles", body: "Les opérations de contenu peuvent inclure classification, révision, modération, étiquetage, assurance qualité ou préparation. Un brief responsable précise le type de contenu, les règles de décision, l’escalade, le volume, la sensibilité et le flux de destination." },
          { label: "ÉQUIPES VIRTUELLES", title: "Un soutien au travail récurrent qui demande de la responsabilité", body: "L’assistance virtuelle, le support client, le back-office et la coordination opérationnelle fonctionnent mieux avec une propriété claire des tâches, les outils, les limites d’accès, les attentes de couverture, le suivi et les modalités de transmission." },
          { label: "ACHATS", title: "Recherche et coordination pour les décisions de sourcing", body: "Le soutien aux achats peut couvrir la recherche de fournisseurs, la préparation de demandes de prix, la comparaison, l’information vendeur, la coordination du sourcing et la recherche tenant compte de la logistique. Les critères, marchés, budget et format de décision orientent le travail." },
          { label: "CONCEPTION OPÉRATIONNELLE", title: "Faire entrer le travail dans une boucle de livraison répétable", body: "À travers les services, Unity peut aider à rendre visible le rythme pratique : ce qui arrive, qui le révise, ce qui est achevé, comment les exceptions sont signalées et ce que contient une remise finale utile." },
        ], closing: "L’objectif va au-delà de l’exécution des tâches : il s’agit d’un parcours de travail que l’équipe cliente comprend mieux et peut réellement utiliser.",
      },
      {
        section: "EVEDEV OPS", kicker: "06  /  SYSTÈMES NUMÉRIQUES", title: "Un travail d’ingénierie et de produit qui commence par le résultat opérationnel.",
        intro: "EveDev Ops développe des produits et systèmes numériques pour les organisations qui ont besoin d’améliorer la manière dont le travail est livré, vécu, mesuré, connecté ou développé à l’échelle. Les choix technologiques comptent, mais ils suivent le produit, le flux, l’audience et les risques qui façonnent l’engagement.",
        items: [
          { label: "RÉFLEXION PRODUIT", title: "Définir ce que le système doit rendre possible", body: "Avant d’établir une liste de fonctionnalités, il est utile de comprendre les personnes concernées, leur situation, le processus actuel, les points de friction, le résultat attendu, les mesures d’utilité et les contraintes telles que le temps, les données, les accès ou les systèmes existants." },
          { label: "INGÉNIERIE", title: "Construire avec une vision de l’ensemble opérationnel", body: "Applications web, expériences mobiles, portails, outils internes, plateformes, API et automatisations sont considérés comme des systèmes qui doivent fonctionner pour les utilisateurs, opérateurs, administrateurs et l’organisation qui les maintiendra." },
          { label: "LIVRAISON", title: "Transformer les décisions en séquence de travail concrète", body: "La prochaine étape peut prendre la forme d’une découverte, d’une architecture, d’un prototype ciblé, d’une construction cadrée, d’un plan d’intégration, d’une modernisation ou d’une feuille de route. Le bon format suit le niveau d’incertitude et l’impact de la décision." },
          { label: "CONTINUITÉ", title: "Préparer l’après-lancement", body: "Un système opérationnel a aussi besoin de visibilité, d’amélioration, de responsabilité opérationnelle, de discipline de livraison, de considérations de sécurité et d’une voie de réponse lorsque les exigences ou conditions évoluent." },
        ], closing: "EveDev Ops considère une construction numérique comme une capacité opérationnelle, non comme un livrable statique détaché du travail qui l’entoure.",
      },
      {
        section: "EVEDEV OPS", kicker: "07  /  PRODUITS + PLATEFORMES", title: "Des produits numériques qui offrent aux utilisateurs et aux équipes un parcours plus clair.",
        intro: "Un site, une application, un portail, un produit SaaS ou une plateforme interne doit servir son audience et les personnes qui l’exploitent. EveDev Ops considère l’information, les interactions, les intégrations, les accès et le cycle de vie qui rendent un produit crédible après sa mise en ligne.",
        items: [
          { label: "WEB", title: "Des expériences web construites pour une audience et une action précises", body: "Les sites d’entreprise, plateformes de service, tableaux de bord, expériences e-commerce, bases de connaissances et applications web peuvent être structurés autour du parcours utilisateur, du modèle de contenu, du processus métier, des données et des objectifs de conversion ou d’exploitation." },
          { label: "MOBILE", title: "Des parcours mobiles où le contexte et la continuité comptent", body: "Le travail mobile commence par un scénario utilisateur : qui utilise l’application, sur quel appareil, dans quelles conditions, avec quelles hypothèses de réseau ou de permission, et comment l’expérience mobile se relie au reste de l’environnement opérationnel." },
          { label: "SAAS + PORTAILS", title: "Des plateformes pour les rôles, les flux et une valeur récurrente", body: "Une plateforme SaaS ou un portail demande une compréhension des utilisateurs, rôles, structures de compte, parcours critiques, cycle de vie des données, administration, besoins de support et décisions que le produit doit simplifier." },
          { label: "SYSTÈMES INTERNES", title: "Des outils qui réduisent les frictions dans l’organisation", body: "Les applications internes peuvent centraliser un processus, rendre les demandes visibles, remplacer des transmissions manuelles fragiles, apporter de la traçabilité ou relier des données que les équipes reconstruisent autrement dans des tableurs et des messages." },
        ], closing: "Les meilleurs plans produit décrivent ce qui doit s’améliorer pour les utilisateurs et les opérateurs avant de devenir une liste d’écrans isolés.",
      },
      {
        section: "EVEDEV OPS", kicker: "08  /  IA APPLIQUÉE + AUTOMATISATION", title: "Utiliser l’automatisation et l’IA là où elles améliorent une décision, un processus ou une expérience réelle.",
        intro: "L’IA appliquée et l’automatisation doivent être reliées à une tâche claire et à une protection opérationnelle. EveDev Ops étudie la place pratique de ces capacités dans un produit ou un flux : ce qui déclenche le travail, quelles informations sont utilisées, quel résultat est acceptable et où la révision humaine reste importante.",
        items: [
          { label: "APPLICATIONS IA", title: "Intégrer l’IA à un produit avec un rôle défini", body: "Les fonctions IA peuvent aider à retrouver de l’information, rédiger, classifier, résumer, extraire, évaluer, assister une décision ou travailler à travers des documents. Le contexte produit détermine leur utilité, leur présentation et la façon dont les sorties sont contrôlées." },
          { label: "AGENTS + FLUX", title: "Automatiser une séquence, pas seulement une tâche isolée", body: "Les agents ou flux automatisés peuvent coordonner recherche, transformation, orientation, notification, approbation et suivi. Une conception utile identifie les événements déclencheurs, systèmes connectés, exceptions, responsabilités et moments d’intervention humaine." },
          { label: "INTELLIGENCE DOCUMENTAIRE", title: "Transformer les documents en informations de travail structurées", body: "Les solutions orientées documents peuvent extraire des champs, classifier des contenus, identifier des informations à vérifier, faciliter la recherche ou alimenter un processus aval. Qualité des sources, précision attendue, confidentialité, auditabilité et gestion des erreurs font partie de la conception initiale." },
          { label: "MESURE", title: "Évaluer l’utilité dans l’environnement opérationnel", body: "Pour l’IA et l’automatisation, la performance ne se limite pas à une sortie technique. La bonne question est de savoir si la capacité rend un flux plus rapide, plus clair, plus sûr, plus cohérent ou plus utile pour les personnes responsables du résultat." },
        ], closing: "La bonne capacité IA ou automatisée est celle qui mérite sa place dans le flux de travail, avec des limites claires et une expérience humaine utile.",
      },
      {
        section: "EVEDEV OPS", kicker: "09  /  CLOUD, SÉCURITÉ + INTÉGRATION", title: "Créer des connexions fiables entre les systèmes, la livraison et la responsabilité opérationnelle.",
        intro: "Les produits numériques ne fonctionnent pas seuls. Ils dépendent d’environnements de déploiement, de règles d’accès, de flux de données, de services tiers, de supervision et d’équipes qui ont besoin de comprendre ce qui se passe. EveDev Ops traite ces fondations comme les éléments d’un système opérationnel cohérent.",
        items: [
          { label: "API", title: "Relier les systèmes autour des informations qui doivent circuler", body: "Le travail d’API et d’intégration commence par les systèmes source et cible, les données importantes, les événements déclencheurs, le niveau de fiabilité attendu, les frontières de responsabilité, l’authentification, les cas d’erreur et les personnes affectées lorsqu’une connexion échoue." },
          { label: "CLOUD + DEVOPS", title: "Rendre la livraison et l’exploitation plus répétables", body: "Architecture cloud, conteneurs, CI/CD, environnements, automatisation d’infrastructure, déploiement et supervision peuvent offrir un passage plus sûr entre changement et mise en production, avec une visibilité plus claire sur les logiciels exploités." },
          { label: "SÉCURITÉ", title: "Aborder la protection dans le contexte du système", body: "La sécurité applicative est façonnée par les actifs, utilisateurs, rôles, accès, sensibilité des données, préoccupations de risque et contexte de conformité. Elle est la plus utile lorsqu’elle éclaire une décision de risque concrète plutôt que de rester une liste de contrôle isolée." },
          { label: "FIABILITÉ", title: "Prévoir les exceptions, pas seulement le parcours idéal", body: "Les systèmes fiables prennent en compte les demandes échouées, données manquantes, services dégradés, reprises, visibilité, escalade, récupération et informations opérationnelles dont une équipe a besoin pour bien réagir." },
        ], closing: "Un système connecté ne devient utile que lorsqu’il peut être compris, maintenu et jugé digne de confiance dans des conditions réelles.",
      },
      {
        section: "TRAVAILLER À TRAVERS LE GROUPE", kicker: "10  /  LORSQUE PERSONNES + SYSTÈMES SE RENCONTRENT", title: "Un parcours coordonné lorsque le travail nécessite à la fois capacité humaine et technologie.",
        intro: "Certains défis se situent à l’intersection des services professionnels et des systèmes numériques. Une plateforme peut nécessiter des opérations de contenu, une initiative de données peut demander annotation et conception produit, ou un processus de service récurrent peut bénéficier d’un meilleur flux et d’un système intégré. eveOps Group aide à cadrer cette intersection.",
        items: [
          { label: "PARTIR DU TRAVAIL", title: "Identifier l’évolution opérationnelle qui compte", body: "La première question n’est pas de savoir quelle division utiliser. Il s’agit de comprendre ce qui doit s’améliorer, les personnes concernées, ce qui se passe actuellement et où l’expertise humaine, la conception système ou les deux peuvent rendre le changement plus atteignable." },
          { label: "ORIENTER LA PRATIQUE", title: "Choisir Unity, EveDev ou une combinaison réfléchie", body: "Unity peut mener lorsque le besoin central est une capacité professionnelle structurée. EveDev peut mener lorsque l’enjeu principal est un produit, système, intégration ou automatisation. Le groupe peut aider à séquencer le travail lorsque les deux domaines sont liés." },
          { label: "DÉFINIR L’INTERFACE", title: "Rendre les passages entre personnes et systèmes visibles", body: "Un travail combiné gagne à préciser les entrées, sorties, responsabilités, seuils de qualité, besoins utilisateurs, données opérationnelles, parcours d’exception et la façon dont les personnes responsables de la livraison travailleront avec le système." },
          { label: "GARDER UNE ÉTAPE PROPORTIONNÉE", title: "Choisir le bon niveau de découverte ou de périmètre", body: "Toute situation ne nécessite pas un grand programme pour commencer. Un premier échange peut identifier la plus petite étape informée qui réduit l’incertitude et donne à l’équipe une meilleure voie de décision." },
        ], closing: "Le modèle de groupe existe pour rendre un défi connecté plus facile à aborder, pas pour compliquer inutilement un besoin simple.",
      },
      {
        section: "NOTRE APPROCHE", kicker: "11  /  DU CONTEXTE À UNE PROCHAINE ÉTAPE UTILE", title: "Un premier échange qui rend le travail plus facile à comprendre.",
        intro: "Un premier contact n’a pas besoin de résoudre chaque exigence. Il doit établir assez de contexte partagé pour identifier la pratique adaptée, poser les questions utiles et proposer une façon responsable d’avancer. La qualité de ce cadrage initial influence tout ce qui suit.",
        items: [
          { label: "01", title: "Décrire le résultat et la réalité actuelle", body: "Qu’est-ce qui doit évoluer ou ne fonctionne pas ? Qu’est-ce qu’un meilleur résultat rendrait possible ? Qui est concerné ? À quoi ressemble le flux, système ou organisation de service actuelle ?" },
          { label: "02", title: "Partager les informations qui donnent une forme au travail", body: "Selon l’engagement, il peut s’agir de contenus sources, d’échantillons de données, de systèmes, de rôles utilisateurs, de cartes de processus, de volumes, marchés, calendriers, contraintes techniques, outils existants ou exigences de révision." },
          { label: "03", title: "Rendre visibles contraintes et attentes de qualité", body: "Normes de livraison, confidentialité, limites d’accès, validations, échéances, besoins d’escalade, formats de remise et mesures d’utilité déterminent souvent la bonne structure pour un engagement." },
          { label: "04", title: "Définir la prochaine étape la plus responsable", body: "Le résultat peut être une réponse ciblée, un périmètre de service, un atelier de découverte, une discussion d’architecture ou produit, une approche de qualité des données, un plan opérationnel ou une voie plus claire vers les bonnes personnes et informations." },
        ], closing: "Un brief utile n’est pas un long document. C’est une clarté suffisante pour rendre la prochaine décision meilleure que la précédente.",
      },
    ],
  },
};

function mark(doc: PDFKit.PDFDocument, x: number, y: number, size: number, foreground = colors.cobalt) {
  doc.save().translate(x + size, y).scale(-1, 1);
  doc.lineWidth(size * 0.14).lineCap("square");
  doc.strokeColor(foreground).moveTo(size * 0.79, size * 0.16).lineTo(size * 0.4, size * 0.16).lineTo(size * 0.16, size * 0.5).lineTo(size * 0.4, size * 0.84).lineTo(size * 0.79, size * 0.84).stroke();
  doc.strokeColor(colors.cyan).moveTo(size * 0.74, size * 0.33).lineTo(size * 0.46, size * 0.33).lineTo(size * 0.34, size * 0.5).lineTo(size * 0.46, size * 0.67).lineTo(size * 0.74, size * 0.67).stroke();
  doc.restore();
}

function header(doc: PDFKit.PDFDocument, footer: string, index: string, section: string, dark = false) {
  const fill = dark ? colors.navy : colors.paper;
  const accent = dark ? colors.white : colors.cobalt;
  doc.addPage({ margin: 0, size: "A4" });
  doc.rect(0, 0, 595.28, 841.89).fill(fill);
  mark(doc, 48, 35, 22, accent);
  doc.fillColor(dark ? "#DCE9FA" : colors.muted).font("Helvetica-Bold").fontSize(7.4).text("eveOps GROUP  /  DETAILED COMPANY PROFILE", 80, 43, { characterSpacing: 0.7 });
  doc.text(`${index}  /  ${section}`, 398, 43, { width: 149, align: "right", characterSpacing: 0.45 });
  doc.save().strokeColor(dark ? "#31507A" : colors.line).lineWidth(0.6).moveTo(48, 71).lineTo(547, 71).stroke().restore();
  doc.fillColor(dark ? "#B7CAE7" : colors.muted).font("Helvetica").fontSize(7.3).text(footer, 48, 796, { width: 499, align: "center" });
}

function drawRows(doc: PDFKit.PDFDocument, items: readonly DetailItem[], accent: string, dark: boolean, y: number) {
  let top = y;
  const titleColor = dark ? colors.white : colors.ink;
  const bodyColor = dark ? "#C7D6EB" : colors.muted;
  const line = dark ? "#294967" : colors.line;
  items.forEach((item) => {
    const bodyHeight = doc.font("Helvetica").fontSize(8.8).lineGap(2.7).heightOfString(item.body, { width: 246, lineGap: 2.7 });
    const titleHeight = doc.font("Helvetica-Bold").fontSize(11.4).lineGap(-1.3).heightOfString(item.title, { width: 160, lineGap: -1.3 });
    const height = Math.max(82, Math.max(bodyHeight + 27, titleHeight + 30));
    doc.save().strokeColor(line).lineWidth(0.6).moveTo(48, top).lineTo(547, top).stroke().restore();
    doc.fillColor(accent).font("Helvetica-Bold").fontSize(8.2).text(item.label, 48, top + 14, { width: 42, characterSpacing: 0.8 });
    doc.fillColor(titleColor).font("Helvetica-Bold").fontSize(11.4).lineGap(-1.3).text(item.title, 100, top + 12, { width: 160 });
    doc.fillColor(bodyColor).font("Helvetica").fontSize(8.8).lineGap(2.7).text(item.body, 285, top + 13, { width: 246 });
    top += height;
  });
  doc.save().strokeColor(line).lineWidth(0.6).moveTo(48, top).lineTo(547, top).stroke().restore();
  return top;
}

function drawPage(doc: PDFKit.PDFDocument, profile: (typeof profiles)[ProfileLocale], page: DetailPage, index: number, dark: boolean, accent: string) {
  header(doc, profile.footer, String(index).padStart(2, "0"), page.section, dark);
  const headingColor = dark ? colors.white : colors.ink;
  const introColor = dark ? "#C5D4E9" : colors.muted;
  doc.fillColor(accent).font("Helvetica-Bold").fontSize(7.8).text(page.kicker, 48, 105, { characterSpacing: 1.25 });
  doc.fillColor(headingColor).font("Helvetica-Bold").fontSize(27).lineGap(-3).text(page.title, 48, 130, { width: 455 });
  const titleHeight = doc.heightOfString(page.title, { width: 455, lineGap: -3 });
  const introY = 130 + titleHeight + 16;
  doc.fillColor(introColor).font("Helvetica").fontSize(10).lineGap(3.8).text(page.intro, 48, introY, { width: 447 });
  const introHeight = doc.heightOfString(page.intro, { width: 447, lineGap: 3.8 });
  const rowsBottom = drawRows(doc, page.items, accent, dark, Math.max(278, introY + introHeight + 24));
  const closingY = Math.min(714, rowsBottom + 21);
  doc.save().fillColor(dark ? "#0D2039" : colors.mist).roundedRect(48, closingY, 499, 50, 3).fill().restore();
  doc.fillColor(dark ? "#DCE7F7" : colors.ink).font("Times-Italic").fontSize(11.5).lineGap(1.8).text(page.closing, 67, closingY + 13, { width: 445 });
}

function drawCover(doc: PDFKit.PDFDocument, profile: (typeof profiles)[ProfileLocale]) {
  doc.addPage({ margin: 0, size: "A4" });
  doc.rect(0, 0, 595.28, 841.89).fill(colors.navy);
  doc.save().fillColor("#0C2038").circle(555, 101, 270).fill().restore();
  doc.save().strokeColor("#1E426A").lineWidth(1).circle(555, 101, 206).stroke().circle(555, 101, 252).stroke().restore();
  mark(doc, 49, 48, 34, colors.white);
  doc.fillColor("#D2E3FC").font("Helvetica-Bold").fontSize(7.4).text(profile.coverKicker, 49, 103, { characterSpacing: 1.08, width: 460 });
  doc.fillColor(colors.white).font("Helvetica-Bold").fontSize(40).lineGap(-8).text(profile.coverTitle[0], 49, 157).text(profile.coverTitle[1], 49).text(profile.coverTitle[2], 49);
  doc.fillColor(colors.cyan).rect(49, 339, 82, 2).fill();
  doc.fillColor("#DCE7F7").font("Times-Italic").fontSize(15.5).lineGap(3).text(profile.coverBody, 49, 368, { width: 346 });
  doc.save().fillColor(colors.unity).rect(49, 519, 213, 150).fill();
  doc.save().fillColor("#0E2945").rect(273, 519, 273, 150).fill();
  doc.fillColor(colors.saffron).font("Helvetica-Bold").fontSize(7.3).text("UNITY INTEGRATED SOLUTIONS", 69, 541, { characterSpacing: 1.05 });
  doc.fillColor(colors.white).font("Helvetica-Bold").fontSize(16).text("Professional\nservices", 69, 563);
  doc.fillColor("#DDEADD").font("Helvetica").fontSize(8.6).lineGap(2.8).text("Language · AI data · research · content · procurement · operational support", 69, 620, { width: 160 });
  doc.fillColor(colors.cyan).font("Helvetica-Bold").fontSize(7.3).text("EVEDEV OPS", 294, 541, { characterSpacing: 1.05 });
  doc.fillColor(colors.white).font("Helvetica-Bold").fontSize(16).text("Digital systems", 294, 563);
  doc.fillColor("#DCE7F7").font("Helvetica").fontSize(8.6).lineGap(2.8).text("Software · products · AI · automation · cloud · DevOps · integrations", 294, 620, { width: 204 });
  doc.save().strokeColor("#31507A").lineWidth(0.7).moveTo(49, 718).lineTo(546, 718).stroke().restore();
  doc.fillColor("#AFC6E4").font("Helvetica-Bold").fontSize(8.2).text(profile.coverNote, 49, 741, { width: 497, align: "center", characterSpacing: 0.4 });
  doc.fillColor("#7897BF").font("Helvetica").fontSize(7.8).text("eveopsgroup.com  ·  support@eveopsgroup.com", 49, 773, { width: 497, align: "center" });
}

function drawContactPage(doc: PDFKit.PDFDocument, profile: (typeof profiles)[ProfileLocale], locale: ProfileLocale) {
  header(doc, profile.footer, "13", locale === "fr" ? "CONTACT" : "CONTACT", false);
  doc.fillColor(colors.terracotta).font("Helvetica-Bold").fontSize(7.8).text(locale === "fr" ? "13  /  COMMENCER LA CONVERSATION" : "13  /  START A CONVERSATION", 48, 105, { characterSpacing: 1.25 });
  doc.fillColor(colors.ink).font("Helvetica-Bold").fontSize(27).lineGap(-3).text(profile.contactTitle, 48, 130, { width: 470 });
  const titleHeight = doc.heightOfString(profile.contactTitle, { width: 470, lineGap: -3 });
  doc.fillColor(colors.muted).font("Helvetica").fontSize(10).lineGap(3.8).text(profile.contactBody, 48, 130 + titleHeight + 16, { width: 447 });
  doc.save().fillColor(colors.navy).roundedRect(48, 286, 499, 104, 3).fill().restore();
  mark(doc, 73, 312, 30, colors.white);
  doc.fillColor(colors.cyan).font("Helvetica-Bold").fontSize(7.2).text(locale === "fr" ? "UN POINT DE DÉPART UTILE" : "A USEFUL STARTING POINT", 128, 312, { characterSpacing: 1.1 });
  doc.fillColor(colors.white).font("Times-Italic").fontSize(15).lineGap(2).text(profile.contactPrompt, 128, 334, { width: 355 });
  const rowsBottom = drawRows(doc, profile.contactRows, colors.terracotta, false, 430);
  doc.save().fillColor(colors.mist).roundedRect(48, Math.min(740, rowsBottom + 17), 499, 44, 3).fill().restore();
  doc.fillColor(colors.ink).font("Times-Italic").fontSize(11).text(profile.close, 67, Math.min(740, rowsBottom + 31), { width: 440, align: "center" });
}

export function buildCompanyProfilePdf(locale: ProfileLocale = "en"): Promise<Buffer> {
  const profile = profiles[locale];
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ autoFirstPage: false, compress: false, info: { Title: locale === "fr" ? "eveOps Group | Profil détaillé d’entreprise FR" : "eveOps Group | Detailed Company Profile EN", Author: "eveOps Group", Subject: locale === "fr" ? "Présentation détaillée des services professionnels et systèmes numériques" : "Detailed professional services and digital systems company profile", Keywords: locale === "fr" ? "eveOps Group; profil détaillé; Unity; EveDev; French edition" : "eveOps Group; detailed company profile; Unity; EveDev; English edition" } });
    const chunks: Buffer[] = [];
    doc.on("data", chunk => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);

    drawCover(doc, profile);
    profile.pages.forEach((page, pageOffset) => {
      const unityPage = pageOffset >= 1 && pageOffset <= 4;
      const eveDevPage = pageOffset >= 5 && pageOffset <= 8;
      drawPage(doc, profile, page, pageOffset + 2, eveDevPage, unityPage ? colors.terracotta : eveDevPage ? colors.cyan : colors.cobalt);
    });
    drawContactPage(doc, profile, locale);
    doc.end();
  });
}
