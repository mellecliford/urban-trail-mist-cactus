# EveOps on a Debian VPS

## Application stack

EveOps is **not PHP or Laravel**. It is a TypeScript application with a React 19 and Vite browser interface, a Node.js/Express server, tRPC procedures, and Drizzle ORM against a MySQL-compatible database. Both customers and administrators use self-hosted email-and-password accounts. No hosted OAuth service is required at runtime.

| Layer | Technology | VPS responsibility |
|---|---|---|
| Web interface | React 19, Vite, TypeScript | Built as static files by `pnpm build` |
| Application API | Node.js, Express, tRPC | Runs continuously through systemd |
| Data | MySQL 8 or MariaDB 10.11+ | Users, leads, projects, settings, audit history, and media metadata |
| Account security | bcryptjs and signed HTTP-only cookie | Customer and administrator password access, protected by `JWT_SECRET` |
| Media | S3-compatible object storage | Operations media uploads; MinIO is the self-hosted option below |
| Email | SMTP | Form delivery and optional customer email confirmation |

> The core public brand images are now bundled under `client/public/assets`, so the public website does not rely on a managed media URL. New Operations uploads use configurable S3-compatible storage.

## Security first

Use a Debian 12 VPS and point a domain name to its public IP. This guide uses `eveops.example.com` for the application and `media.example.com` for public media. Replace both names with your own domain names.

Do **not** use `1234` for any password, database account, JWT secret, SMTP credential, or object-storage credential. Create distinct values, save them in a password manager, and generate the session secret with:

```bash
openssl rand -base64 48
```

## 1. Prepare Debian

Log in as a sudo-enabled user and install the required base software:

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y ca-certificates curl git nginx certbot python3-certbot-nginx mariadb-server
sudo adduser --system --group --home /srv/eveops eveops
```

Install Node.js 22 and pnpm, then verify both commands work. EveOps requires Node 22 or newer.

```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
sudo corepack enable
corepack prepare pnpm@10.4.1 --activate
node --version
pnpm --version
```

## 2. Create the database

The application works with MySQL 8 or MariaDB. This example creates a local MariaDB database. Substitute a unique database password.

```bash
sudo mariadb
```

```sql
CREATE DATABASE eveops CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'eveops_app'@'127.0.0.1' IDENTIFIED BY 'REPLACE_WITH_A_LONG_UNIQUE_DATABASE_PASSWORD';
GRANT ALL PRIVILEGES ON eveops.* TO 'eveops_app'@'127.0.0.1';
FLUSH PRIVILEGES;
EXIT;
```

## 3. Install and configure EveOps

Export the project to a **private** Git repository or upload the downloaded project archive securely. Do not commit real secret files.

```bash
sudo -u eveops git clone <your-private-repository-url> /srv/eveops
cd /srv/eveops
sudo -u eveops pnpm install --frozen-lockfile
```

Create a restricted production environment file:

```bash
sudo install -d -m 750 -o root -g eveops /etc/eveops
sudo install -d -m 700 -o eveops -g eveops /var/lib/eveops
sudo nano /etc/eveops/eveops.env
sudo chown root:eveops /etc/eveops/eveops.env
sudo chmod 640 /etc/eveops/eveops.env
```

Use the following template. Replace every `REPLACE_...` value with a unique secret saved in your password manager.

```dotenv
NODE_ENV=production
PORT=3000
DATABASE_URL=mysql://eveops_app:REPLACE_WITH_A_LONG_UNIQUE_DATABASE_PASSWORD@127.0.0.1:3306/eveops
JWT_SECRET=REPLACE_WITH_OUTPUT_FROM_OPENSSL_RAND_BASE64_48

# Enables the one-time browser setup wizard at /setup. Generate and store a unique 24+-character value.
EVEOPS_SETUP_TOKEN=REPLACE_WITH_A_UNIQUE_24_PLUS_CHARACTER_SETUP_CODE
EVEOPS_RUNTIME_CONFIG_PATH=/var/lib/eveops/runtime-config.json

# Optional non-interactive alternative: creates the first self-hosted super administrator on server start.
INITIAL_ADMIN_NAME=EveOps Administrator
INITIAL_ADMIN_EMAIL=admin@your-domain.example
INITIAL_ADMIN_PASSWORD=REPLACE_WITH_A_UNIQUE_16_PLUS_CHARACTER_PASSWORD

# Required only after MinIO or another S3-compatible service is ready.
S3_ENDPOINT=http://127.0.0.1:9000
S3_REGION=us-east-1
S3_BUCKET=eveops-media
S3_ACCESS_KEY_ID=REPLACE_WITH_A_MINIO_ACCESS_KEY
S3_SECRET_ACCESS_KEY=REPLACE_WITH_A_MINIO_SECRET_KEY
S3_PUBLIC_BASE_URL=https://media.your-domain.example/eveops-media
```

> Choose **one** first-administrator method. Either use `INITIAL_ADMIN_*` for non-interactive bootstrap, or leave those three variables out and open `https://your-domain.example/setup` to supply the database URL and initial administrator through the protected setup wizard. The wizard validates the database, applies the project’s reviewed Drizzle migrations, and then creates the account. In both cases, protect `EVEOPS_SETUP_TOKEN` like a password and remove it from the environment after setup completes.

> **Credential ownership:** the owner creates and stores the initial administrator email and password during this first-run step. EveOps does not ship with a default administrator account, cannot reveal a password later, and does not require SMTP to create the first administrator. Configure SMTP after the first sign-in so password-reset and form-delivery email can operate.

### Administrator recovery and two-factor authentication

Administrator password resets are delivered only through the SMTP configuration in **Operations → Email settings**. Keep SMTP delivery enabled and tested before relying on `/admin/reset`; the public reset page deliberately returns the same confirmation message for every email address. After the administrator signs in, **Operations → Security** can enroll a compatible authenticator app with an optional time-based one-time password. Save the displayed recovery codes in a password manager: they are shown once, stored only as hashes, and each works once.

The TOTP secret is encrypted using `JWT_SECRET`. Do not rotate `JWT_SECRET` without a planned maintenance window, because existing sessions and encrypted security secrets will no longer be readable. If a rotation is unavoidable, have an administrator disable and re-enroll two-factor authentication after the change.

Apply the schema and create the production build:

```bash
cd /srv/eveops
sudo -u eveops bash -c 'set -a; source /etc/eveops/eveops.env; set +a; pnpm drizzle-kit migrate'
sudo -u eveops pnpm test
sudo -u eveops pnpm check
sudo -u eveops pnpm build
```

## 4. Run the Node.js server with systemd

Create `/etc/systemd/system/eveops.service`:

```ini
[Unit]
Description=EveOps Node.js application
After=network.target mariadb.service

[Service]
Type=simple
User=eveops
Group=eveops
WorkingDirectory=/srv/eveops
EnvironmentFile=/etc/eveops/eveops.env
Environment=NODE_ENV=production
ExecStart=/usr/bin/env pnpm start
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ReadWritePaths=/var/lib/eveops

[Install]
WantedBy=multi-user.target
```

Enable the service and check startup output:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now eveops
sudo systemctl status eveops
sudo journalctl -u eveops -f
```

On its first successful start, the application creates one super-administrator from `INITIAL_ADMIN_EMAIL` and `INITIAL_ADMIN_PASSWORD` if no password account already uses that email. Then remove **only** `INITIAL_ADMIN_PASSWORD` from `/etc/eveops/eveops.env` and restart the service. Keep `JWT_SECRET` unchanged because it protects account sessions and encrypted SMTP settings.

Administrators sign in at `https://eveops.example.com/login?mode=administrator`. Customers use `https://eveops.example.com/login?mode=customer`. The server rejects customer credentials on the administrator route and administrator credentials on the customer route.

## 5. Add Nginx and HTTPS

Create `/etc/nginx/sites-available/eveops`:

```nginx
server {
    listen 80;
    server_name eveops.example.com;
    client_max_body_size 10m;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

After DNS resolves to the VPS, enable Nginx and request a certificate:

```bash
sudo ln -s /etc/nginx/sites-available/eveops /etc/nginx/sites-enabled/eveops
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d eveops.example.com
```

The `X-Forwarded-Proto` header is required so HTTPS requests receive secure HTTP-only account cookies.

## 6. Self-host MinIO for Operations media uploads

MinIO is an S3-compatible storage server. It runs separately from EveOps. Install Docker using the official Docker documentation, then create `/opt/eveops-storage/compose.yml`:

```yaml
services:
  minio:
    image: minio/minio:latest
    restart: unless-stopped
    command: server /data --console-address ":9001"
    environment:
      MINIO_ROOT_USER: REPLACE_WITH_A_UNIQUE_MINIO_ROOT_USER
      MINIO_ROOT_PASSWORD: REPLACE_WITH_A_UNIQUE_MINIO_ROOT_PASSWORD
    volumes:
      - /var/lib/eveops-minio:/data
    ports:
      - "127.0.0.1:9000:9000"
      - "127.0.0.1:9001:9001"
```

Start it with:

```bash
sudo docker compose -f /opt/eveops-storage/compose.yml up -d
```

Use the MinIO console through an SSH tunnel or a protected administrator-only proxy to create the `eveops-media` bucket and a least-privilege service account. Permit **anonymous download only** for this public-media bucket. Do not grant anonymous upload, list, or administrative access.

Expose only the S3 API, not the MinIO console, through a second Nginx host:

```nginx
server {
    listen 80;
    server_name media.example.com;
    client_max_body_size 10m;

    location / {
        proxy_pass http://127.0.0.1:9000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

Enable this host, issue its certificate, then restart EveOps:

```bash
sudo ln -s /etc/nginx/sites-available/media /etc/nginx/sites-enabled/media
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d media.example.com
sudo systemctl restart eveops
```

`S3_ENDPOINT` is used only by the server for authenticated writes. `S3_PUBLIC_BASE_URL` is used for browser-facing media URLs. With the example configuration, `eveops/public/1/logo.png` is delivered from `https://media.example.com/eveops-media/eveops/public/1/logo.png`.

## 7. Post-deployment checks and backups

Sign in with the initial administrator credentials, configure SMTP in Operations, and test it. Customer email confirmation is off by default; enable it only after SMTP succeeds. Existing Operations media records pointing to legacy managed URLs should be re-uploaded through the Media section once MinIO is running. The public site’s core brand assets are already portable.

Back up both MySQL/MariaDB and the MinIO volume before upgrades:

```bash
sudo mariadb-dump --single-transaction eveops | gzip > /var/backups/eveops-$(date +%F).sql.gz
sudo tar -C /var/lib -czf /var/backups/eveops-minio-$(date +%F).tar.gz eveops-minio
```

Test a restore on a non-production server. Keep the firewall open only for SSH, HTTP, and HTTPS; both the EveOps application port and MinIO ports stay bound to `127.0.0.1`.
