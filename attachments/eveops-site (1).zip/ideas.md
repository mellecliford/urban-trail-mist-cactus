# EveOps Design Direction

## Three initial directions

### 1. Meridian Convergence
**Very Brief Intro:** A dual-world corporate gateway in which human operational systems and engineered digital systems meet along one decisive editorial seam. It feels confident, international, and quietly exacting.

**Probability:** 0.07

### 2. Atlas Exchange
**Very Brief Intro:** A warm, modernist services house built around navigational lines, cartographic margins, and calm paper-like surfaces. It foregrounds global coordination and considered human expertise.

**Probability:** 0.03

### 3. System / Signal
**Very Brief Intro:** A dark, technical research-studio direction where modular frames and system signals establish an infrastructure-first identity. It emphasizes engineering rigor and composure over spectacle.

**Probability:** 0.09

## Chosen direction: Meridian Convergence

### Design Movement
**Editorial modernism meets systems architecture.** The parent brand is treated as an intelligent connective layer, with the two divisions expressed as distinctly controlled visual territories rather than interchangeable product cards.

### Core Principles

1. **One deliberate seam:** Every major parent-brand composition acknowledges the meeting point between people-led operations and engineered systems.
2. **Earned visual contrast:** Unity stays light, precise, and human-centered; EveDev Ops stays dark, structural, and technical. Both share the same type rhythm, geometry, and navigation logic.
3. **Operational clarity:** Information is arranged as routes, capabilities, and working systems—not generic marketing stacks or decorative feature grids.
4. **Quiet confidence:** Use a limited color palette, roomy hierarchy, and specific copy. Avoid fabricated proof points, buzzwords, and visual noise.

### Color Philosophy

The EveOps parent layer uses **ink black, soft bone, and a controlled electric blue** to establish authority and continuity. Unity carries a deep ocean navy with porcelain, pale blue, and a restrained copper point to signal trust, people, and global coordination. EveDev Ops uses carbon, near-black, cobalt, cyan, and an occasional violet reflection to signal engineered capability. The two palettes meet only at the parent-brand seam and in shared blue focus states.

### Layout Paradigm

**The routed editorial canvas.** Parent and division pages use asymmetric column relationships, side labels, anchored rails, and controlled overlaps. Pages should read like a designed operating system: primary narrative at one edge, supporting context on another, and no reliance on a centered stack of uniform rounded cards.

### Signature Elements

1. **The convergence seam:** a vertical or angled rule where Unity and EveDev Ops worlds meet.
2. **Latitude rails:** fine route lines, location dots, and small indexed labels that suggest global coordination without decorative map clichés.
3. **System frames:** dark technical panels, monospace metadata, and measured blue paths for engineering content.

### Interaction Philosophy

Interaction is directional and informative. Division cards expand subtly to affirm a choice; buttons shift with a short, grounded movement; capability rows reveal a concise description on hover or focus. Navigation always leads to a real URL, never swaps foundational content in place.

### Animation

Use 160–280ms transform-and-opacity transitions with strong ease-out curves. The homepage division cards gain only a slight scale and shadow shift on hover. Fine route-lines may drift at very low amplitude on non-reduced-motion devices. Entrance effects use a short, staggered opacity/translate reveal once per page load. Respect `prefers-reduced-motion` by removing non-essential animation.

### Typography System

**Manrope** is the compact, decisive display and interface face: high-weight headlines, all-caps metadata, and clear navigation. **Source Serif 4** is used sparingly for narrative emphasis and selected editorial statements. Body copy remains Manrope at generous line height. Headlines use tight tracking; labels use wide tracking and small caps. Never use Inter.

### Brand Essence

**EveOps connects dependable human operations with production-grade digital engineering for organizations that need both.**

Personality: **assured, exacting, internationally minded.**

### Brand Voice

Headlines are direct and specific. CTAs describe a next working step, not a vague aspiration. Microcopy is concise, informed, and free from hype.

Examples:

> “Bring the right team to the work.”

> “Turn the operating problem into a product plan.”

### Wordmark & Logo

The icon is a strong, modular convergence glyph: two structural paths fold toward a central negative-space aperture. The wordmark uses a custom-set, slightly spaced **EVEOPS** alongside the mark, with the central aperture echoed in the “O” treatment. The icon must function on its own as a favicon and header mark.

### Signature Brand Color

**Signal Cobalt — #2B5CFF.** A controlled blue that travels through the parent brand, interactive states, and the technical division without overwhelming the more human Unity palette.

## Style Decisions

- **Convergence seam rule:** Every parent, contact, and product page includes an unmistakable seam or routed meeting-point composition through indexed rails, angled rules, or split territories.
- **Imagery rule:** Unity visuals receive operational routing and documentation overlays; EveDev Ops visuals receive system frames and infrastructure-path overlays, reducing generic corporate and abstract-tech cues.
- **Logo rule:** The lockup increases the visual authority of the convergence mark and uses a custom-set EVEOPS wordmark with a central aperture treatment in the “O.”

## Unity Integrated Solutions: Independent Brand Revision

Unity must now operate as a visually self-contained destination. Unity pages do not show the EveOps lockup, EveDev Ops switcher, parent-group language, cobalt, dark engineering panels, or technical product-lab motifs.

### Unity Brand Direction: The Steward’s Compass

Unity becomes a warm, operational services brand influenced by modern hospitality, field logistics, and editorial business journals. The feeling is **considered, grounded, and well-coordinated**, rather than technical or corporate-blue.

### Unity Palette

The palette moves entirely away from navy and professional blue. Its foundation is **Evergreen #173B32**, **Parchment #F6F0E6**, **Saffron #DDA543**, **Terracotta #B95C3D**, and **Moss #8EA178**. The colors communicate stewardship, global coordination, and practical care. Saffron identifies action; terracotta marks human judgment and selected details.

### Unity Logo

The dedicated mark is a memorable **Compass Fold**: four rounded directional facets fold inward to create a clear central “U” aperture. It represents well-routed work, worldwide coordination, and integrated support without relying on a generic globe, handshake, or lettermark. The accompanying lockup reads **UNITY / Integrated Solutions** in a high-contrast, editorial arrangement.

### Unity Navigation and Tone

The header carries only the Unity logo and Unity routes: Services, Language, AI Data, Research & Data, Procurement, Workforce, and Contact. The footer reinforces the same standalone information architecture. Headlines describe coordinated, human work; small labels use “Routes”, “Capabilities”, and “Delivery approach.”
