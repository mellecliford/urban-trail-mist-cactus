# Brand, Orientation, Loader, and PDF Verification Notes

- The desktop Unity service route shows the restored standalone orientation cue: “You are at · Unity Integrated Solutions · Language.” It does not restore Unity-to-EveDev or Unity-to-parent navigation prompts.
- The desktop EveDev route retains its existing division route bar and currently reflects the corrected public spelling “eveOps Group home.”
- The revised managed monogram URL rendered as a broken image in the public header during the first desktop review. The public shell must therefore use a reliable inline vector brand mark rather than depend on a managed-image URL for essential identity rendering.
- The public company-profile download asset was uploaded as `/manus-storage/main_cdc57d77.pdf`; the upload tool reported that this project lacks a storage proxy. The final download section must use a self-contained public delivery route rather than leaving a link that may not resolve.

- Mobile review confirmed the inline eveOps Group monogram renders reliably and the Unity “You are at” cue is visible. It also exposed that the initial three-column PDF download layout compressed copy at 375 px; the layout was immediately changed to a two-column mobile arrangement with a full-width action row before final review.

- Browser navigation to the same self-hosted `/api/public/company-profile.pdf` route used by the homepage download action triggered a download named `eveOps-Group-Company-Profile.pdf`. The public endpoint therefore delivers a browser-downloadable PDF without a managed-storage proxy.
- The three route-loader variants are covered by rendered route tests and their CSS motion is explicitly guarded by `prefers-reduced-motion`. Because dynamic route modules resolve before the static browser capture is taken, the short-lived loading frame cannot be reliably captured without deliberately degrading the production loading path.

- The final public refinement regression suite explicitly asserts the parent, Unity, and EveDev loader variants and confirms their animation rules sit inside the `prefers-reduced-motion: no-preference` media query. This provides code-level reduced-motion verification without adding a degraded artificial loader delay to the public experience.
