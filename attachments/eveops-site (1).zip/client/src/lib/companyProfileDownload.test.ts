import { describe, expect, it, vi } from "vitest";
import { companyProfileUrl, requestCompanyProfile } from "./companyProfileDownload";

describe("company profile download", () => {
  it("requests the selected localized profile and preserves the server attachment filename", async () => {
    const request = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      headers: new Headers({ "content-disposition": 'attachment; filename="eveOps-Group-Profil-Entreprise-FR.pdf"' }),
      blob: async () => new Blob(["professional profile"]),
    });

    const result = await requestCompanyProfile("fr", request);

    expect(companyProfileUrl("en")).toBe("/api/public/company-profile.pdf?lang=en");
    expect(request).toHaveBeenCalledWith("/api/public/company-profile.pdf?lang=fr", { credentials: "same-origin" });
    expect(result.file.size).toBeGreaterThan(0);
    expect(result.filename).toBe("eveOps-Group-Profil-Entreprise-FR.pdf");
  });

  it("returns an explicit failure when the public profile request is not successful", async () => {
    const request = vi.fn().mockResolvedValue({ ok: false, status: 503 });

    await expect(requestCompanyProfile("en", request)).rejects.toThrow("HTTP 503");
  });

  it("rejects an empty profile response rather than reporting a false download success", async () => {
    const request = vi.fn().mockResolvedValue({ ok: true, status: 200, headers: new Headers(), blob: async () => new Blob() });

    await expect(requestCompanyProfile("en", request)).rejects.toThrow("profile file was empty");
  });
});
