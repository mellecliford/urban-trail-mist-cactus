import { describe, expect, it } from "vitest";
import { getServiceBriefContext } from "./serviceBrief";

describe("getServiceBriefContext", () => {
  it("keeps Unity briefs on the Unity route and preserves the selected service", () => {
    expect(getServiceBriefContext("?service=Language%20Services", true)).toEqual({ route: "unity", service: "Language Services", attributionChannel: "direct", attributedCapability: "", locale: "en" });
  });

  it("selects the EveDev Ops route and preserves an engineering service from the URL", () => {
    expect(getServiceBriefContext("?division=edevops&service=Web%20Development", false)).toEqual({ route: "edevops", service: "Web Development", attributionChannel: "direct", attributedCapability: "", locale: "en" });
  });

  it("defaults the shared contact page to Unity when no route is present", () => {
    expect(getServiceBriefContext("", false)).toEqual({ route: "unity", service: "", attributionChannel: "direct", attributedCapability: "", locale: "en" });
  });

  it("accepts a bounded French capability CTA attribution while rejecting incomplete source fields", () => {
    expect(getServiceBriefContext("?division=edevops&service=Web%20Development&capability=Corporate%20websites&source=capability_cta&lang=fr", false)).toEqual({ route: "edevops", service: "Web Development", attributionChannel: "capability_cta", attributedCapability: "Corporate websites", locale: "fr" });
    expect(getServiceBriefContext("?source=capability_cta&lang=fr", false)).toMatchObject({ attributionChannel: "direct", attributedCapability: "", locale: "fr" });
  });
});
