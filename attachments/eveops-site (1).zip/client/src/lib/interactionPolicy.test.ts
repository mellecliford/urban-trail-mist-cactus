import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

describe("interaction policy", () => {
  const css = fs.readFileSync(path.resolve(process.cwd(), "client/src/index.css"), "utf8");

  it("ships motion only behind an opt-in media query and includes a reduced-motion override", () => {
    expect(css).toContain("@media (prefers-reduced-motion: no-preference)");
    expect(css).toContain("@media (prefers-reduced-motion: reduce)");
    expect(css).toContain("animation-duration: .01ms !important");
  });
});
