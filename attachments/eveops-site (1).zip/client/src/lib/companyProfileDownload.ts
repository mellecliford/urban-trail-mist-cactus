import type { PublicLocale } from "@/lib/publicLocale";

export const companyProfileEndpoint = "/api/public/company-profile.pdf";

export function companyProfileUrl(locale: PublicLocale) {
  return `${companyProfileEndpoint}?lang=${locale}`;
}

function filenameFromDisposition(contentDisposition: string | null, fallback: string) {
  if (!contentDisposition) return fallback;
  const utf8Match = contentDisposition.match(/filename\*=UTF-8''([^;]+)/i);
  if (utf8Match?.[1]) return decodeURIComponent(utf8Match[1]);
  const quotedMatch = contentDisposition.match(/filename="?([^";]+)"?/i);
  return quotedMatch?.[1] || fallback;
}

export async function requestCompanyProfile(locale: PublicLocale, request: typeof fetch = fetch) {
  const response = await request(companyProfileUrl(locale), { credentials: "same-origin" });
  if (!response.ok) throw new Error(`The profile could not be prepared (HTTP ${response.status}).`);
  const file = await response.blob();
  if (file.size === 0) throw new Error("The profile file was empty. Please try again.");
  const fallback = locale === "fr" ? "eveOps-Group-Profil-Entreprise-FR.pdf" : "eveOps-Group-Company-Profile-EN.pdf";
  return { file, filename: filenameFromDisposition(response.headers.get("content-disposition"), fallback) };
}

export function triggerCompanyProfileDownload(file: Blob, filename: string) {
  const objectUrl = URL.createObjectURL(file);
  const anchor = document.createElement("a");
  anchor.href = objectUrl;
  anchor.download = filename;
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 0);
}
