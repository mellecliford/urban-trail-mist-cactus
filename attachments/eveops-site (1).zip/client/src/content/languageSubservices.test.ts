import { describe, expect, it } from "vitest";
import { divisions, getCapabilityBriefTemplate, getCapabilityBriefTemplateFilename, getServiceCapabilityBriefHref, getServiceCapabilityBriefs, languageSubservices } from "./site";

describe("Unity language subservices", () => {
  it("provides a distinct, briefable route for every requested language capability", () => {
    expect(languageSubservices.map(item => item.title)).toEqual(["Translation", "Localization", "Transcreation", "Proofreading & editing", "Linguistic QA", "Subtitling & captioning"]);
    expect(languageSubservices.every(item => item.detail.length > 80 && item.briefLabel.length > 0)).toBe(true);
  });

  it("creates a detailed, distinct prefilled brief for every capability across both divisions", () => {
    (Object.keys(divisions) as Array<keyof typeof divisions>).forEach(division => {
      divisions[division].services.forEach(service => {
        const briefs = getServiceCapabilityBriefs(division, service);
        expect(briefs).toHaveLength(service.capabilities.length);
        expect(briefs.every(brief => brief.canonicalTitle.length > 0 && brief.description.length > 40 && brief.detail.length > 100 && brief.briefLabel.length > 0)).toBe(true);
        const frenchBriefs = getServiceCapabilityBriefs(division, service, "fr");
        expect(frenchBriefs).toHaveLength(service.capabilities.length);
        expect(frenchBriefs.every(brief => brief.canonicalTitle.length > 0 && brief.description.length > 40 && brief.detail.length > 100 && brief.briefLabel.length > 0)).toBe(true);
        frenchBriefs.forEach(brief => {
          const href = getServiceCapabilityBriefHref(division, brief.briefLabel, brief.canonicalTitle, "fr");
          const url = new URL(href, "https://eveops.test");
          expect(url.searchParams.get("lang")).toBe("fr");
          expect(url.searchParams.get("capability")).toBe(brief.canonicalTitle);
        });
        if (!(division === "unity" && service.slug === "translation")) expect(briefs.every(brief => brief.briefLabel.startsWith(`${service.title} — `))).toBe(true);
        briefs.forEach(brief => {
          const href = getServiceCapabilityBriefHref(division, brief.briefLabel, brief.title);
          const url = new URL(href, "https://eveops.test");
          expect(url.searchParams.get("service")).toBe(brief.briefLabel);
          expect(url.searchParams.get("source")).toBe("capability_cta");
          expect(url.searchParams.get("capability")).toBe(brief.title);
          expect(division === "unity" ? url.pathname : url.searchParams.get("division")).toBe(division === "unity" ? "/unity/contact" : "edevops");
        });
      });
    });
  });

  it("creates a portable, service-specific working-brief template for every capability", () => {
    (Object.keys(divisions) as Array<keyof typeof divisions>).forEach(division => {
      divisions[division].services.forEach(service => {
        getServiceCapabilityBriefs(division, service).forEach(brief => {
          const template = getCapabilityBriefTemplate(division, service, brief);
          expect(template).toContain(`**Service:** ${service.title}`);
          expect(template).toContain(`**Capability:** ${brief.title}`);
          expect(getCapabilityBriefTemplateFilename(brief.briefLabel)).toMatch(/-brief-template\.en\.md$/);
          const frenchTemplate = getCapabilityBriefTemplate(division, service, brief, "fr");
          expect(frenchTemplate).toContain("## Questions de départ");
          expect(getCapabilityBriefTemplateFilename(brief.briefLabel, "fr")).toMatch(/-brief-template\.fr\.md$/);
        });
      });
    });
  });
});
