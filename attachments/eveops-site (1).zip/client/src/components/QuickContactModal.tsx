import { useState } from "react";
import { CheckCircle2, MessageCircle, Send, X } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import type { PublicLocale } from "@/lib/publicLocale";

export function QuickContactModal({ locale }: { locale: PublicLocale }) {
  const fr = locale === "fr";
  const [open, setOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const submitLead = trpc.leads.submit.useMutation();

  const handleOpenChange = (nextOpen: boolean) => {
    setOpen(nextOpen);
    if (nextOpen) setSubmitted(false);
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);

    try {
      const result = await submitLead.mutateAsync({
        name: String(form.get("name") || ""),
        email: String(form.get("email") || ""),
        division: "group",
        service: "Homepage quick contact",
        attributionChannel: "direct",
        message: String(form.get("message") || ""),
      });
      formElement.reset();
      setSubmitted(true);
      toast.success(fr ? "Votre message a bien été reçu." : "Your message has been received.", {
        description: result.emailStatus === "sent"
          ? (fr ? "L’équipe eveOps Group a été notifiée." : "The eveOps Group team has been notified.")
          : (fr ? "Il est enregistré de manière sécurisée pour suivi." : "It has been safely recorded for follow-up."),
      });
    } catch (error) {
      toast.error(fr ? "Nous n’avons pas pu envoyer votre message." : "We could not send your message.", {
        description: error instanceof Error ? error.message : (fr ? "Réessayez ou écrivez à support@eveopsgroup.com." : "Please retry or email support@eveopsgroup.com."),
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <button className="home-hero__contact" type="button">
          <MessageCircle size={17} /> {fr ? "Parler à eveOps Group" : "Talk to eveOps Group"}
        </button>
      </DialogTrigger>
      <DialogContent className="quick-contact-modal p-0" showCloseButton={false}>
        <DialogClose className="quick-contact-modal__close" aria-label={fr ? "Fermer la fenêtre de contact" : "Close contact dialog"}>
          <X size={18} />
          <span className="sr-only">{fr ? "Fermer" : "Close"}</span>
        </DialogClose>
        {submitted ? (
          <div className="quick-contact-modal__success" aria-live="polite">
            <div className="quick-contact-modal__success-icon"><CheckCircle2 size={25} /></div>
            <p className="quick-contact-modal__eyebrow">{fr ? "Message reçu" : "Message received"}</p>
            <DialogTitle>{fr ? "Merci de nous avoir écrit." : "Thank you for getting in touch."}</DialogTitle>
            <DialogDescription>{fr ? "Notre équipe dispose maintenant de votre message et reviendra vers vous avec la suite appropriée." : "Our team now has your message and will follow up with the appropriate next step."}</DialogDescription>
            <button className="quick-contact-modal__done" type="button" onClick={() => setOpen(false)}>{fr ? "Fermer" : "Close"}</button>
          </div>
        ) : (
          <div className="quick-contact-modal__body">
            <DialogHeader className="quick-contact-modal__header">
              <p className="quick-contact-modal__eyebrow">{fr ? "Un premier échange simple" : "A simple first conversation"}</p>
              <DialogTitle>{fr ? <>Parlons de ce qui doit <em>avancer.</em></> : <>Let’s discuss what needs to <em>move forward.</em></>}</DialogTitle>
              <DialogDescription>{fr ? "Donnez-nous juste l’essentiel. Nous vous orienterons vers Unity Integrated Solutions, EveDev Ops ou la bonne combinaison." : "Share only the essentials. We will route you to Unity Integrated Solutions, EveDev Ops, or the right combination."}</DialogDescription>
            </DialogHeader>
            <form className="quick-contact-modal__form" onSubmit={handleSubmit}>
              <label>{fr ? "Nom" : "Name"} *<input required name="name" autoComplete="name" placeholder={fr ? "Votre nom" : "Your name"} /></label>
              <label>E-mail *<input required type="email" name="email" autoComplete="email" placeholder="name@company.com" /></label>
              <label>{fr ? "Comment pouvons-nous vous aider ?" : "How can we help?"} *<textarea required name="message" rows={4} minLength={10} placeholder={fr ? "Le besoin, l’objectif ou la question à traiter." : "The need, outcome, or question you would like to address."} /></label>
              <div className="quick-contact-modal__form-footer">
                <p>{fr ? "Vos informations sont utilisées uniquement pour répondre à votre demande." : "Your details are used only to respond to this enquiry."}</p>
                <button className="button button--solid" type="submit" disabled={submitLead.isPending}>{submitLead.isPending ? (fr ? "Envoi…" : "Sending…") : (fr ? "Envoyer le message" : "Send message")} <Send size={16} /></button>
              </div>
            </form>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
