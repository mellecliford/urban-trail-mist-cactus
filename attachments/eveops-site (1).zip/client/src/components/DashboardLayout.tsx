import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/useMobile";
import { ArrowUpRight, LayoutDashboard, LogOut, PanelLeft, ShieldCheck } from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { Link, useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { Button } from "./ui/button";

export type AdminNavItem = { icon: React.ComponentType<{ className?: string }>; label: string; path: string; group?: string };
const SIDEBAR_WIDTH_KEY = "eveops-admin-sidebar-width";
const DEFAULT_WIDTH = 276;
const MIN_WIDTH = 220;
const MAX_WIDTH = 390;

export default function DashboardLayout({ children, menuItems, title = "EveOps Operations" }: { children: React.ReactNode; menuItems: AdminNavItem[]; title?: string }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => Number(localStorage.getItem(SIDEBAR_WIDTH_KEY)) || DEFAULT_WIDTH);
  const { loading, user } = useAuth();
  useEffect(() => { localStorage.setItem(SIDEBAR_WIDTH_KEY, String(sidebarWidth)); }, [sidebarWidth]);
  if (loading) return <DashboardLayoutSkeleton />;
  if (!user) return <div className="min-h-screen bg-[#f5f3ee] grid place-items-center p-6"><div className="max-w-md bg-white p-10 shadow-xl text-center"><ShieldCheck className="mx-auto mb-5 h-10 w-10 text-[#2765f5]" /><p className="text-[10px] font-bold tracking-[.16em] text-[#2765f5] uppercase">EveOps secure area</p><h1 className="mt-3 text-4xl font-bold tracking-[-.05em] text-[#0b1424]">Sign in to continue.</h1><p className="mt-4 text-sm leading-6 text-slate-600">Administrator access is determined on the server after you authenticate.</p><Button onClick={() => window.location.assign("/login?mode=administrator")} className="mt-7 w-full bg-[#0b1424] hover:bg-[#2765f5]">Continue to administrator sign in</Button><Link href="/" className="mt-5 inline-flex items-center gap-2 text-xs font-semibold text-[#0b1424] underline underline-offset-4">Return to public website <ArrowUpRight size={14} /></Link></div></div>;
  if (!["super_admin", "admin"].includes(user.role)) return <div className="min-h-screen bg-[#f5f3ee] grid place-items-center p-6"><div className="max-w-md bg-white p-10 shadow-xl text-center"><ShieldCheck className="mx-auto mb-5 h-10 w-10 text-[#2765f5]" /><p className="text-[10px] font-bold tracking-[.16em] text-[#2765f5] uppercase">Access restricted</p><h1 className="mt-3 text-4xl font-bold tracking-[-.05em] text-[#0b1424]">This account does not have administrator access.</h1><p className="mt-4 text-sm leading-6 text-slate-600">Ask a super administrator to assign an EveOps administrator role before returning here.</p><Link href="/" className="mt-7 inline-flex items-center gap-2 text-xs font-semibold text-[#0b1424] underline underline-offset-4">Return to public website <ArrowUpRight size={14} /></Link></div></div>;
  return <SidebarProvider style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}><DashboardLayoutContent title={title} menuItems={menuItems} setSidebarWidth={setSidebarWidth}>{children}</DashboardLayoutContent></SidebarProvider>;
}

function DashboardLayoutContent({ children, menuItems, title, setSidebarWidth }: { children: React.ReactNode; menuItems: AdminNavItem[]; title: string; setSidebarWidth: (width: number) => void }) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const [isResizing, setIsResizing] = useState(false);
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const sidebarRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const activeItem = menuItems.find(item => location === item.path) || menuItems[0];
  useEffect(() => { const move = (event: MouseEvent) => { if (!isResizing) return; const left = sidebarRef.current?.getBoundingClientRect().left ?? 0; const width = event.clientX - left; if (width >= MIN_WIDTH && width <= MAX_WIDTH) setSidebarWidth(width); }; const stop = () => setIsResizing(false); if (isResizing) { document.addEventListener("mousemove", move); document.addEventListener("mouseup", stop); document.body.style.cursor = "col-resize"; } return () => { document.removeEventListener("mousemove", move); document.removeEventListener("mouseup", stop); document.body.style.cursor = ""; }; }, [isResizing, setSidebarWidth]);
  return <><div className="relative" ref={sidebarRef}><Sidebar collapsible="icon" className="border-r border-[#182744] bg-[#0b1424] text-[#eff4ff]" disableTransition={isResizing}><SidebarHeader className="h-[78px] justify-center border-b border-white/10"><div className="flex items-center gap-3 px-3"><button onClick={toggleSidebar} className="grid h-9 w-9 place-items-center rounded-md text-[#dbe5ff] hover:bg-white/10" aria-label="Toggle administrator navigation"><PanelLeft className="h-4 w-4" /></button>{!isCollapsed && <div className="min-w-0"><p className="truncate text-[10px] font-bold uppercase tracking-[.16em] text-[#6f9dff]">EveOps</p><p className="truncate text-sm font-semibold">Operations</p></div>}</div></SidebarHeader><SidebarContent className="gap-0 bg-[#0b1424]"><SidebarMenu className="px-2 py-4">{menuItems.map((item, index) => <div key={item.path}>{(index === 0 || item.group !== menuItems[index - 1]?.group) && !isCollapsed && <p className="px-3 pb-2 pt-4 text-[9px] font-bold uppercase tracking-[.15em] text-[#8390ab]">{item.group}</p>}<SidebarMenuItem><SidebarMenuButton isActive={location === item.path} onClick={() => setLocation(item.path)} tooltip={item.label} className="h-10 text-[#e1e9f8] hover:bg-white/10 data-[active=true]:bg-[#1c4fb9] data-[active=true]:text-white"><item.icon className="h-4 w-4" /><span>{item.label}</span></SidebarMenuButton></SidebarMenuItem></div>)}</SidebarMenu></SidebarContent><SidebarFooter className="border-t border-white/10 p-3"><DropdownMenu><DropdownMenuTrigger asChild><button className="flex w-full items-center gap-3 rounded-md p-1 text-left hover:bg-white/10"><Avatar className="h-9 w-9 border border-white/10"><AvatarFallback className="bg-[#2765f5] text-xs text-white">{user?.name?.charAt(0).toUpperCase() || "A"}</AvatarFallback></Avatar><div className="min-w-0 flex-1 group-data-[collapsible=icon]:hidden"><p className="truncate text-sm font-medium">{user?.name || "Administrator"}</p><p className="truncate text-[10px] text-[#aebbd3]">{user?.role?.replace("_", " ")}</p></div></button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-48"><DropdownMenuItem onClick={logout} className="cursor-pointer text-destructive focus:text-destructive"><LogOut className="mr-2 h-4 w-4" />Sign out</DropdownMenuItem></DropdownMenuContent></DropdownMenu></SidebarFooter></Sidebar><div className={`absolute right-0 top-0 h-full w-1 cursor-col-resize hover:bg-[#2765f5]/60 ${isCollapsed ? "hidden" : ""}`} onMouseDown={() => setIsResizing(true)} /></div><SidebarInset className="bg-[#f5f3ee]">{isMobile && <div className="sticky top-0 z-40 flex h-14 items-center gap-3 border-b border-[#d6dae2] bg-white/95 px-3 backdrop-blur"><SidebarTrigger className="h-9 w-9 rounded-md" /><span className="text-sm font-semibold text-[#0b1424]">{activeItem?.label || title}</span></div>}<main className="min-h-screen p-5 md:p-8">{children}</main></SidebarInset></>;
}
