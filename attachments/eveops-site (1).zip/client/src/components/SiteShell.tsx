/**
 * Meridian Convergence shell: parent and independently branded Unity navigation systems are selected by real route.
 */
import { Link, useLocation } from "wouter";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { assets, brand, navItems } from "@/content/site";
import { EveOpsBrandMark } from "@/components/EveOpsBrandMark";
import { getPublicLocale, withPublicLocale } from "@/lib/publicLocale";
import { shouldShowDivisionRouteBar } from "@/lib/publicPresentation";

function LanguageControl({ locale }: { locale: "en" | "fr" }) {
  const currentHref = typeof window === "undefined" ? "/" : `${window.location.pathname}${window.location.search}`;
  return <div className="language-control" aria-label="Language"><a href={withPublicLocale(currentHref, "en")} className={locale === "en" ? "language-control__link language-control__link--active" : "language-control__link"} lang="en">EN</a><span aria-hidden="true">/</span><a href={withPublicLocale(currentHref, "fr")} className={locale === "fr" ? "language-control__link language-control__link--active" : "language-control__link"} lang="fr">FR</a></div>;
}

function localizeNavigation(label: string, locale: "en" | "fr") {
  if (locale === "en") return label;
  return ({ Home: "Accueil", Products: "Produits", Portfolio: "Réalisations", About: "À propos", Contact: "Contact", Services: "Services", Language: "Langues", "AI Data": "Données IA", "Research & Data": "Recherche et données", Procurement: "Achats", Workforce: "Équipes" } as Record<string, string>)[label] || label;
}

function DivisionSwitch({ compact = false }: { compact?: boolean }) {
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  return <div className={`division-switch ${compact ? "division-switch--compact" : ""}`} aria-label="Explore an EveOps division"><Link href={withPublicLocale("/unity", locale)} className="division-switch__option division-switch__option--unity"><span>Unity</span>{!compact && <small>{locale === "fr" ? "Services professionnels" : "Professional services"}</small>}</Link><Link href={withPublicLocale("/edevops", locale)} className="division-switch__option division-switch__option--edevops"><span>EveDev Ops</span>{!compact && <small>{locale === "fr" ? "Logiciels et technologie" : "Software & technology"}</small>}</Link></div>;
}

function DivisionRouteBar({ current }: { current: "unity" | "edevops" }) {
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  const other = current === "unity" ? { label: locale === "fr" ? "Explorer EveDev Ops" : "Explore EveDev Ops", href: "/edevops", note: locale === "fr" ? "Logiciels et technologie" : "Software & technology" } : { label: locale === "fr" ? "Explorer Unity" : "Explore Unity", href: "/unity", note: locale === "fr" ? "Services intégrés" : "Integrated services" };
  const currentLabel = current === "unity" ? "Unity Integrated Solutions" : "EveDev Ops";
  return <nav className={`division-route-bar division-route-bar--${current}`} aria-label="Division and group navigation"><div className="container division-route-bar__inner"><span className="division-route-bar__current">{locale === "fr" ? "Vous êtes dans" : "You are in"} <strong>{currentLabel}</strong></span><div className="division-route-bar__links"><Link href={withPublicLocale(other.href, locale)}><span>{other.label}</span><small>{other.note}</small><ArrowUpRight size={14} aria-hidden="true" /></Link><Link href={withPublicLocale("/", locale)} className="division-route-bar__home">{locale === "fr" ? "Accueil eveOps Group" : "eveOps Group home"} <ArrowUpRight size={14} aria-hidden="true" /></Link></div></div></nav>;
}

function EveOpsBrandLockup({ footer = false }: { footer?: boolean }) {
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  return <Link href={withPublicLocale("/", locale)} className={`brand-lockup${footer ? " brand-lockup--footer" : ""}`} aria-label={`${brand.name} home`}><EveOpsBrandMark /><span className="brand-lockup__word"><span>eve</span><span className="wordmark-o">Ops</span></span><span className="brand-lockup__group">Group</span></Link>;
}

export function SiteHeader() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  const isTechnical = location.startsWith("/edevops");
  useEffect(() => setOpen(false), [location]);
  return <header className={`site-header ${isTechnical ? "site-header--dark" : ""}`}><div className="container site-header__inner"><EveOpsBrandLockup /><nav className="site-nav" aria-label="Primary navigation">{navItems.map(([label, href]) => <Link key={href} href={withPublicLocale(href, locale)} className={location === href ? "site-nav__link site-nav__link--active" : "site-nav__link"}>{localizeNavigation(label, locale)}</Link>)}</nav><div className="site-header__actions"><LanguageControl locale={locale} /><Link href="/login" className="header-operations">Operations</Link><DivisionSwitch compact /><Link href={withPublicLocale("/contact", locale)} className="header-cta">{locale === "fr" ? "Démarrer un projet" : "Start a project"} <ArrowUpRight size={15} aria-hidden="true" /></Link><button className="menu-toggle" onClick={() => setOpen((value) => !value)} aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open}>{open ? <X size={22} /> : <Menu size={22} />}</button></div></div>{open && <div className="mobile-nav"><nav aria-label="Mobile navigation" className="mobile-nav__links">{navItems.map(([label, href], index) => <Link href={withPublicLocale(href, locale)} key={href} className="mobile-nav__link"><span className="mobile-nav__index">0{index + 1}</span>{localizeNavigation(label, locale)}</Link>)}</nav><div className="mobile-nav__utility"><LanguageControl locale={locale} /><Link href="/login">Operations sign-in <ArrowUpRight size={15} /></Link><DivisionSwitch /></div></div>}</header>;
}

export function SiteFooter() {
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  const fr = locale === "fr";
  return <footer className="site-footer"><div className="container"><div className="site-footer__top"><div className="site-footer__brand"><EveOpsBrandLockup footer /><p>{fr ? "Des services professionnels et une ingénierie numérique exigeante, réunis au sein d’un même groupe." : "Professional services and production-grade digital engineering, connected through one group."}</p></div><div className="site-footer__columns"><div><p className="footer-label">eveOps</p><Link href={withPublicLocale("/about", locale)}>{fr ? "À propos" : "About"}</Link><Link href={withPublicLocale("/contact", locale)}>Contact</Link><Link href={withPublicLocale("/insights", locale)}>{fr ? "Réflexions" : "Insights"}</Link><Link href="/login">{fr ? "Connexion Operations" : "Operations sign-in"}</Link></div><div><p className="footer-label footer-label--unity">Unity Integrated Solutions</p><Link href={withPublicLocale("/unity/services", locale)}>{fr ? "Services professionnels" : "Professional services"}</Link><Link href={withPublicLocale("/unity/ai-data", locale)}>AI data</Link><Link href={withPublicLocale("/unity/procurement", locale)}>{fr ? "Soutien aux achats" : "Procurement support"}</Link></div><div><p className="footer-label footer-label--edevops">EveDev Ops</p><Link href={withPublicLocale("/edevops/web-development", locale)}>{fr ? "Développement web" : "Web development"}</Link><Link href={withPublicLocale("/edevops/ai-development", locale)}>{fr ? "Développement IA" : "AI development"}</Link><Link href={withPublicLocale("/products", locale)}>{fr ? "Produits" : "Products"}</Link></div></div></div><div className="site-footer__bottom"><span>© {new Date().getFullYear()} eveOps Group</span><div><Link href={withPublicLocale("/privacy", locale)}>{fr ? "Confidentialité" : "Privacy"}</Link><Link href={withPublicLocale("/terms", locale)}>{fr ? "Conditions" : "Terms"}</Link></div></div></div></footer>;
}

const unityNav = [["Services", "/unity/services"], ["Language", "/unity/translation"], ["AI Data", "/unity/ai-data"], ["Research & Data", "/unity/research-data"], ["Procurement", "/unity/procurement"], ["Workforce", "/unity/virtual-workforce"]] as const;

export function UnityHeader() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  useEffect(() => setOpen(false), [location]);
  return <header className="unity-header"><div className="unity-header__topline" aria-hidden="true"><div className="container"><span>{locale === "fr" ? "Services professionnels coordonnés" : "Coordinated professional services"}</span><span>{locale === "fr" ? "Parcours de livraison internationaux" : "Global delivery routes"}</span></div></div><div className="container unity-header__inner"><Link href={withPublicLocale("/unity", locale)} className="unity-lockup" aria-label="Unity Integrated Solutions home"><img src={assets.unityMark} alt="" className="unity-lockup__mark" /><span className="unity-lockup__text"><strong>UNITY</strong><small>Integrated Solutions</small></span></Link><nav className="unity-nav" aria-label="Unity Integrated Solutions navigation">{unityNav.map(([label, href]) => <Link key={href} href={withPublicLocale(href, locale)} className={location === href ? "unity-nav__link unity-nav__link--active" : "unity-nav__link"}>{localizeNavigation(label, locale)}</Link>)}</nav><div className="unity-header__actions"><LanguageControl locale={locale} /><Link href="/login" className="unity-operations">Operations</Link><Link href={withPublicLocale("/unity/contact", locale)} className="unity-header__cta">{locale === "fr" ? "Demander un service" : "Request a service"} <ArrowUpRight size={15} /></Link><button className="unity-menu-toggle" onClick={() => setOpen((value) => !value)} aria-label={open ? "Close Unity navigation" : "Open Unity navigation"} aria-expanded={open}>{open ? <X size={22} /> : <Menu size={22} />}</button></div></div>{open && <div className="unity-mobile-nav"><nav aria-label="Unity mobile navigation">{unityNav.map(([label, href], index) => <Link href={withPublicLocale(href, locale)} key={href}><span>0{index + 1}</span>{localizeNavigation(label, locale)}</Link>)}</nav><div className="unity-mobile-nav__utility"><LanguageControl locale={locale} /><Link href="/login">Operations sign-in <ArrowUpRight size={15} /></Link><Link href={withPublicLocale("/unity/contact", locale)} className="unity-header__cta">{locale === "fr" ? "Demander un service" : "Request a service"} <ArrowUpRight size={15} /></Link></div></div>}</header>;
}

export function UnityFooter() {
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  const fr = locale === "fr";
  return <footer className="unity-footer"><div className="container"><div className="unity-footer__main"><div><Link href={withPublicLocale("/unity", locale)} className="unity-lockup unity-lockup--footer"><img src={assets.unityMark} alt="" className="unity-lockup__mark" /><span className="unity-lockup__text"><strong>UNITY</strong><small>Integrated Solutions</small></span></Link><p>{fr ? "Des services professionnels et un soutien coordonné aux équipes pour un travail qui exige une livraison réfléchie." : "Professional services and coordinated workforce support for work that needs thoughtful delivery."}</p></div><div className="unity-footer__links"><div><span>{fr ? "Services" : "Services"}</span><Link href={withPublicLocale("/unity/translation", locale)}>{fr ? "Langues" : "Language"}</Link><Link href={withPublicLocale("/unity/ai-data", locale)}>AI data</Link><Link href={withPublicLocale("/unity/research-data", locale)}>{fr ? "Recherche et données" : "Research & data"}</Link></div><div><span>{fr ? "Capacités" : "Capabilities"}</span><Link href={withPublicLocale("/unity/procurement", locale)}>{fr ? "Achats" : "Procurement"}</Link><Link href={withPublicLocale("/unity/virtual-workforce", locale)}>{fr ? "Équipes" : "Workforce"}</Link><Link href={withPublicLocale("/unity/contact", locale)}>Contact</Link></div></div></div><div className="unity-footer__bottom"><span>© {new Date().getFullYear()} Unity Integrated Solutions</span><div><Link href={withPublicLocale("/privacy", locale)}>{fr ? "Confidentialité" : "Privacy"}</Link><Link href={withPublicLocale("/terms", locale)}>{fr ? "Conditions" : "Terms"}</Link></div></div></div></footer>;
}

export function AppShell({ children }: { children: React.ReactNode }) { const [location] = useLocation(); const isEveDev = location.startsWith("/edevops"); const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search); return <div className="app-shell"><a href="#main-content" className="skip-link">{locale === "fr" ? "Aller au contenu" : "Skip to content"}</a><SiteHeader />{isEveDev && shouldShowDivisionRouteBar("edevops") && <DivisionRouteBar current="edevops" />}<main id="main-content">{children}</main><SiteFooter /></div>; }

export function UnityShell({ children }: { children: React.ReactNode }) { const [location] = useLocation(); const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search); const route = unityNav.find(([, href]) => location === href)?.[0] ?? (location === "/unity" ? "Unity" : "Services"); return <div className="unity-shell"><a href="#main-content" className="skip-link">{locale === "fr" ? "Aller au contenu" : "Skip to content"}</a><UnityHeader /><DivisionRouteBar current="unity" /><aside className="unity-location-cue" aria-label={locale === "fr" ? "Position actuelle dans Unity" : "Current Unity location"}><div className="container"><span>{locale === "fr" ? "Vous êtes ici" : "You are at"}</span><strong>Unity Integrated Solutions</strong><i aria-hidden="true" /><small>{localizeNavigation(route, locale)}</small></div></aside><main id="main-content">{children}</main><UnityFooter /></div>; }

export { DivisionSwitch };
