import { useEffect, useRef, useState } from "react";
import { CheckCircle2, CircleAlert, Download, FileText, LoaderCircle, Share2 } from "lucide-react";
import { toast } from "sonner";
import { getPublicLocale, type PublicLocale } from "@/lib/publicLocale";
import { companyProfileUrl, requestCompanyProfile, triggerCompanyProfileDownload } from "@/lib/companyProfileDownload";

type DownloadState = "idle" | "loading" | "success" | "error";

export function CompanyProfileDownload() {
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  const fr = locale === "fr";
  const activeHref = companyProfileUrl(locale);
  const alternateLocale: PublicLocale = fr ? "en" : "fr";
  const alternateHref = companyProfileUrl(alternateLocale);
  const [downloadLocale, setDownloadLocale] = useState<PublicLocale | null>(null);
  const [downloadState, setDownloadState] = useState<DownloadState>("idle");
  const clearTimer = useRef<number | undefined>(undefined);

  useEffect(() => () => window.clearTimeout(clearTimer.current), []);

  const clearFeedbackLater = () => {
    window.clearTimeout(clearTimer.current);
    clearTimer.current = window.setTimeout(() => {
      setDownloadLocale(null);
      setDownloadState("idle");
    }, 4800);
  };

  const beginDownload = async (event: React.MouseEvent<HTMLAnchorElement>, edition: PublicLocale) => {
    event.preventDefault();
    if (downloadState === "loading") return;
    window.clearTimeout(clearTimer.current);
    setDownloadLocale(edition);
    setDownloadState("loading");

    try {
      const { file, filename } = await requestCompanyProfile(edition);
      triggerCompanyProfileDownload(file, filename);
      setDownloadState("success");
      toast.success(edition === "fr" ? "Le profil français est prêt à télécharger." : "Your English profile is ready to download.", {
        description: edition === "fr" ? "L’édition professionnelle a été récupérée avec succès." : "The professional edition was retrieved successfully.",
      });
    } catch (error) {
      setDownloadState("error");
      toast.error(edition === "fr" ? "Le profil n’a pas pu être téléchargé." : "The profile could not be downloaded.", {
        description: error instanceof Error ? error.message : (edition === "fr" ? "Veuillez réessayer dans un instant." : "Please try again in a moment."),
      });
    }
    clearFeedbackLater();
  };

  const statusText = !downloadLocale || downloadState === "idle"
    ? (fr ? "Conçu pour être partagé" : "Designed to be shared")
    : downloadState === "loading"
      ? (downloadLocale === "fr" ? "Préparation du profil…" : "Preparing your profile…")
      : downloadState === "success"
        ? (downloadLocale === "fr" ? "Téléchargement prêt" : "Download ready")
        : (downloadLocale === "fr" ? "Réessayez le téléchargement" : "Please try the download again");

  const downloadClass = (edition: PublicLocale, baseClass: string) => `${baseClass}${downloadLocale === edition ? " company-profile-download__link--active" : ""}${downloadLocale === edition && downloadState === "loading" ? " company-profile-download__link--loading" : ""}${downloadLocale === edition && downloadState === "success" ? " company-profile-download__link--ready" : ""}${downloadLocale === edition && downloadState === "error" ? " company-profile-download__link--error" : ""}`;
  const iconFor = (edition: PublicLocale, size: number) => {
    if (downloadLocale !== edition) return <Download size={size} />;
    if (downloadState === "loading") return <LoaderCircle className="company-profile-download__spinner" size={size} />;
    if (downloadState === "success") return <CheckCircle2 size={size} />;
    if (downloadState === "error") return <CircleAlert size={size} />;
    return <Download size={size} />;
  };

  return <section className="company-profile-download" aria-labelledby="company-profile-title"><div className="container company-profile-download__grid"><div className="company-profile-download__signal" aria-hidden="true"><FileText size={27} /><span>PDF</span></div><div className="company-profile-download__copy"><p className="eyebrow eyebrow--parent">{fr ? "Document professionnel à partager" : "A professional document to share"}</p><h2 id="company-profile-title">{fr ? <>Présentez <em>eveOps Group</em> avec un profil conçu pour la décision.</> : <>Introduce <em>eveOps Group</em> with a profile made for decisions.</>}</h2><p>{fr ? "Téléchargez une présentation éditoriale de nos deux divisions, de nos capacités et de notre manière de démarrer un brief utile. Les éditions française et anglaise sont prêtes à être partagées avec une équipe, un partenaire ou un décideur." : "Download an editorial introduction to our two divisions, capabilities, and practical route into a useful brief. English and French editions are ready to share with a team, partner, or decision-maker."}</p></div><div className="company-profile-download__action"><a href={activeHref} onClick={(event) => void beginDownload(event, locale)} className={downloadClass(locale, "company-profile-download__button")} aria-describedby="company-profile-download-status" aria-busy={downloadLocale === locale && downloadState === "loading"}>{iconFor(locale, 17)} {downloadLocale === locale ? statusText : (fr ? "Télécharger le profil français" : "Download English profile")}</a><a href={alternateHref} onClick={(event) => void beginDownload(event, alternateLocale)} className={downloadClass(alternateLocale, "company-profile-download__alternate")} aria-describedby="company-profile-download-status" aria-busy={downloadLocale === alternateLocale && downloadState === "loading"}>{iconFor(alternateLocale, 13)} {downloadLocale === alternateLocale ? statusText : (fr ? "English edition" : "Édition française")}</a><span id="company-profile-download-status" aria-live="polite">{downloadState === "error" && downloadLocale ? <CircleAlert size={13} /> : downloadState === "success" && downloadLocale ? <CheckCircle2 size={13} /> : <Share2 size={13} />} {statusText}</span></div></div></section>;
}
