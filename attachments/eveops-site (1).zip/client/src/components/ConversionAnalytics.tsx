import React, { useMemo, useState } from "react";
import { ChartNoAxesColumnIncreasing, Download, Filter } from "lucide-react";
import { trpc } from "@/lib/trpc";

function csvCell(value: unknown) {
  const text = String(value ?? "");
  const formulaSafe = /^[=+\-@]/.test(text) ? `'${text}` : text;
  return `"${formulaSafe.replace(/"/g, '""')}"`;
}

export function ConversionAnalytics() {
  const [draft, setDraft] = useState({ start: "", end: "" });
  const [range, setRange] = useState({ start: "", end: "" });
  const queryInput = useMemo(() => ({ start: range.start || undefined, end: range.end || undefined }), [range]);
  const analytics = trpc.admin.conversionAnalytics.useQuery(queryInput);
  const total = (analytics.data || []).reduce((sum, event) => sum + Number(event.total), 0);
  const opens = (analytics.data || []).reduce((sum, event) => sum + Number(event.briefOpens), 0);
  const downloads = (analytics.data || []).reduce((sum, event) => sum + Number(event.templateDownloads), 0);
  const attributedLeads = (analytics.data || []).reduce((sum, event) => sum + Number(event.attributedLeads), 0);

  const exportCsv = () => {
    const headers = ["Division", "Service", "Capability", "Brief starts", "Template downloads", "Attributed leads", "Total actions", "Last signal"];
    const rows = (analytics.data || []).map(event => [event.division, event.service, event.capability, event.briefOpens, event.templateDownloads, event.attributedLeads, event.total, event.lastSeen ? new Date(event.lastSeen).toISOString() : ""]);
    const blob = new Blob([[headers, ...rows].map(row => row.map(csvCell).join(",")).join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `eveops-conversion-signals${range.start ? `-${range.start}` : ""}${range.end ? `-to-${range.end}` : ""}.csv`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
  };

  return <>
    <div className="flex flex-wrap items-end justify-between gap-5"><div><p className="text-[10px] font-bold uppercase tracking-[.15em] text-[#b95c3d]">Conversion signals</p><h1 className="mt-2 font-serif text-4xl text-[#173b32]">Capability interest</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-slate-600">This reports anonymous capability actions and attributed submitted briefs. It does not persist visitor IP addresses or browser fingerprints.</p></div><button type="button" onClick={exportCsv} disabled={!analytics.data?.length} className="inline-flex items-center gap-2 border border-[#173b32] px-4 py-3 text-xs font-bold text-[#173b32] transition hover:bg-[#e5eadc] disabled:cursor-not-allowed disabled:opacity-50"><Download size={15} /> Export CSV</button></div>
    <form className="mt-7 flex flex-wrap items-end gap-3 bg-white p-5 shadow-sm ring-1 ring-[#dbe3de]" onSubmit={event => { event.preventDefault(); setRange(draft); }}><Filter className="mb-2 h-4 w-4 text-[#b95c3d]" /><label className="grid gap-1 text-xs font-semibold text-[#173b32]"><span>From</span><input type="date" value={draft.start} onChange={event => setDraft(current => ({ ...current, start: event.target.value }))} /></label><label className="grid gap-1 text-xs font-semibold text-[#173b32]"><span>To</span><input type="date" min={draft.start || undefined} value={draft.end} onChange={event => setDraft(current => ({ ...current, end: event.target.value }))} /></label><button type="submit" className="bg-[#173b32] px-4 py-3 text-xs font-bold text-white transition hover:bg-[#b95c3d]">Apply range</button><button type="button" onClick={() => { setDraft({ start: "", end: "" }); setRange({ start: "", end: "" }); }} className="px-2 py-3 text-xs font-bold text-slate-500 underline underline-offset-4">Clear</button></form>
    <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><Metric label="Tracked actions" value={total} loading={analytics.isLoading} /><Metric label="Brief starts" value={opens} loading={analytics.isLoading} /><Metric label="Template downloads" value={downloads} loading={analytics.isLoading} /><Metric label="Attributed leads" value={attributedLeads} loading={analytics.isLoading} /></div>
    <section className="mt-8 overflow-hidden bg-white shadow-sm ring-1 ring-[#dbe3de]">{analytics.isLoading ? <p className="p-8 text-sm text-slate-500">Loading conversion signals…</p> : analytics.data?.length ? <div className="overflow-x-auto"><table className="w-full min-w-[850px] text-left"><thead className="border-b border-[#dbe3de] bg-[#f7f9f7] text-[10px] font-bold uppercase tracking-[.12em] text-slate-500"><tr><th className="px-5 py-4">Capability</th><th>Division</th><th>Brief starts</th><th>Templates</th><th>Attributed leads</th><th>Last signal</th></tr></thead><tbody>{analytics.data.map(event => <tr key={`${event.division}-${event.service}-${event.capability}`} className="border-b border-[#edf1ef] text-sm"><td className="px-5 py-4"><strong className="block text-[#173b32]">{event.capability}</strong><span className="block text-xs text-slate-500">{event.service}</span></td><td className="py-4 capitalize text-[#173b32]">{event.division === "edevops" ? "EveDev Ops" : "Unity"}</td><td className="py-4 text-[#173b32]">{event.briefOpens}</td><td className="py-4 text-[#173b32]">{event.templateDownloads}</td><td className="py-4 text-[#173b32]">{event.attributedLeads}</td><td className="py-4 text-xs text-slate-500">{event.lastSeen ? new Date(event.lastSeen).toLocaleString() : "—"}</td></tr>)}</tbody></table></div> : <div className="p-12 text-center"><ChartNoAxesColumnIncreasing className="mx-auto h-7 w-7 text-[#8ea178]" /><h2 className="mt-3 text-sm font-semibold text-[#173b32]">No capability signals yet</h2><p className="mt-1 text-xs text-slate-500">Capability CTA openings, template downloads, and the resulting attributed briefs will appear here.</p></div>}</section>
  </>;
}

function Metric({ label, value, loading }: { label: string; value: number; loading: boolean }) {
  return <article className="bg-white p-5 shadow-sm ring-1 ring-[#dbe3de]"><p className="text-3xl font-semibold tracking-tight text-[#173b32]">{loading ? "—" : value}</p><p className="mt-1 text-xs font-semibold uppercase tracking-[.1em] text-slate-500">{label}</p></article>;
}
