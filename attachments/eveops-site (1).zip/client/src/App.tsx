/**
 * Meridian Convergence application router: real, shareable routes make all commercial content independently reachable.
 */
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, useLocation } from "wouter";
import { lazy, Suspense } from "react";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AppShell, UnityShell } from "./components/SiteShell";
import { getPublicLocale } from "./lib/publicLocale";
const Home = lazy(() => import("./pages/Home"));
const DivisionPage = lazy(() => import("./pages/DivisionPage"));
const ServiceDetailPage = lazy(() => import("./pages/ServiceDetailPage"));
const ProductsPage = lazy(() => import("./pages/ProductsPage"));
const ShwengPage = lazy(() => import("./pages/ShwengPage"));
const PortfolioPage = lazy(() => import("./pages/PortfolioPage"));
const AboutPage = lazy(() => import("./pages/AboutPage"));
const ContactPage = lazy(() => import("./pages/ContactPage"));
const InsightsPage = lazy(() => import("./pages/InsightsPage"));
const LegalPage = lazy(() => import("./pages/LegalPage"));
const NotFound = lazy(() => import("./pages/NotFound"));
const LoginPage = lazy(() => import("./pages/LoginPage"));
const AdminArea = lazy(() => import("./pages/AdminArea"));
const CustomerArea = lazy(() => import("./pages/CustomerArea"));
const CustomerVerificationPage = lazy(() => import("./pages/CustomerVerificationPage"));
const SetupPage = lazy(() => import("./pages/SetupPage"));
const AdminPasswordResetPage = lazy(() => import("./pages/AdminPasswordResetPage"));

export function RouteLoading() {
  const [location] = useLocation();
  const section = location.startsWith("/unity") ? "unity" : location.startsWith("/edevops") ? "edevops" : "parent";
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  const fr = locale === "fr";
  const label = section === "unity" ? (fr ? "Préparation du parcours de service Unity" : "Preparing the Unity service route") : section === "edevops" ? (fr ? "Préparation du parcours système EveDev Ops" : "Mapping the EveDev Ops system route") : (fr ? "Préparation des parcours eveOps Group" : "Bringing the eveOps Group routes together");
  return <main className={`route-loading route-loading--${section}`} aria-live="polite"><span className="route-loading__animation" aria-hidden="true"><i /><i /><i /></span><p>{label}</p><span className="sr-only">{fr ? "Chargement de la page" : "Loading current page"}</span></main>;
}
function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/unity" component={() => <DivisionPage division="unity" />} />
      <Route path="/unity/services" component={() => <DivisionPage division="unity" />} />
      <Route path="/unity/contact" component={() => <ContactPage scope="unity" />} />
      <Route path="/unity/:slug" component={() => <ServiceDetailPage division="unity" />} />
      <Route path="/edevops" component={() => <DivisionPage division="edevops" />} />
      <Route path="/edevops/services" component={() => <DivisionPage division="edevops" />} />
      <Route path="/edevops/:slug" component={() => <ServiceDetailPage division="edevops" />} />
      <Route path="/products" component={ProductsPage} />
      <Route path="/products/shweng" component={ShwengPage} />
      <Route path="/portfolio" component={PortfolioPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/contact" component={() => <ContactPage />} />
      <Route path="/insights" component={InsightsPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/setup" component={SetupPage} />
      <Route path="/admin/reset" component={AdminPasswordResetPage} />
      <Route path="/admin" component={AdminArea} />
      <Route path="/admin/leads" component={AdminArea} />
      <Route path="/admin/analytics" component={AdminArea} />
      <Route path="/admin/customers" component={AdminArea} />
      <Route path="/admin/projects" component={AdminArea} />
      <Route path="/admin/settings/email" component={AdminArea} />
      <Route path="/admin/settings/security" component={AdminArea} />
      <Route path="/admin/media" component={AdminArea} />
      <Route path="/admin/settings" component={AdminArea} />
      <Route path="/customer" component={CustomerArea} />
      <Route path="/customer/verify" component={CustomerVerificationPage} />
      <Route path="/privacy" component={() => <LegalPage type="privacy" />} />
      <Route path="/terms" component={() => <LegalPage type="terms" />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function RoutedShell() {
  const [location] = useLocation();
  if (location === "/login" || location.startsWith("/setup") || location.startsWith("/admin") || location.startsWith("/customer")) return <Router />;
  const Shell = location.startsWith("/unity") ? UnityShell : AppShell;
  return <Shell><Router /></Shell>;
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster position="top-right" richColors />
          <Suspense fallback={<RouteLoading />}><RoutedShell /></Suspense>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
