import { renderToStaticMarkup } from "react-dom/server";
import React from "react";
import { describe, expect, it, vi } from "vitest";

const useQuery = vi.hoisted(() => vi.fn());

vi.mock("@/lib/trpc", () => ({ trpc: { admin: { conversionAnalytics: { useQuery } } } }));
import { ConversionAnalytics } from "@/components/ConversionAnalytics";

describe("ConversionAnalytics", () => {
  it("renders anonymous capability metrics returned by Operations", () => {
    useQuery.mockReturnValue({ isLoading: false, data: [{ division: "edevops", service: "Web Development", capability: "Corporate websites", briefOpens: 4, templateDownloads: 2, attributedLeads: 1, total: 6, lastSeen: new Date("2026-08-26T10:00:00Z") }] });
    const html = renderToStaticMarkup(<ConversionAnalytics />);
    expect(html).toContain("Capability interest");
    expect(html).toContain("Corporate websites");
    expect(html).toContain("Web Development");
    expect(html).toContain("Tracked actions");
    expect(html).toContain("Attributed leads");
    expect(html).toContain("Export CSV");
    expect(html).toContain(">6<");
  });
});
