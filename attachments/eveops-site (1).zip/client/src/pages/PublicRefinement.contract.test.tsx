import { describe, expect, it } from "vitest";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { readFileSync } from "node:fs";
import { Router } from "wouter";
import { getContactRoutePresentation, getDivisionHeroHeadline, shouldShowDivisionRouteBar } from "@/lib/publicPresentation";
import { UnityShell } from "@/components/SiteShell";
import { CompanyProfileDownload } from "@/components/CompanyProfileDownload";
import { brand } from "@/content/site";
import { RouteLoading } from "@/App";
import DivisionPage from "./DivisionPage";

function renderAt(path: string, node: React.ReactNode) {
  return renderToStaticMarkup(<Router ssrPath={path}>{node}</Router>);
}

const publicStyles = readFileSync(new URL("../index.css", import.meta.url), "utf8");
const profileDownloadSource = readFileSync(new URL("../components/CompanyProfileDownload.tsx", import.meta.url), "utf8");
const quickContactSource = readFileSync(new URL("../components/QuickContactModal.tsx", import.meta.url), "utf8");
const homepageSource = readFileSync(new URL("./Home.tsx", import.meta.url), "utf8");
const shellSource = readFileSync(new URL("../components/SiteShell.tsx", import.meta.url), "utf8");
const brandMarkSource = readFileSync(new URL("../components/EveOpsBrandMark.tsx", import.meta.url), "utf8");
const divisionPageSource = readFileSync(new URL("./DivisionPage.tsx", import.meta.url), "utf8");

describe("public refinement contracts", () => {
  it("keeps Unity visually distinct while offering a clear route to EveDev Ops and the eveOps Group home", () => {
    expect(shouldShowDivisionRouteBar("unity")).toBe(true);
    expect(shouldShowDivisionRouteBar("edevops")).toBe(true);
    const unityMarkup = renderAt("/unity", <UnityShell><p>Unity content</p></UnityShell>);
    expect(unityMarkup).toContain("Unity content");
    expect(unityMarkup).toContain("Unity Integrated Solutions");
    expect(unityMarkup).toContain("You are at");
    expect(unityMarkup).toContain("Explore EveDev Ops");
    expect(unityMarkup).toContain("eveOps Group home");
  });

  it("provides complete Unity and EveDev contact route presentation states", () => {
    expect(getContactRoutePresentation("unity", "en")).toEqual(expect.objectContaining({ className: "contact-page--route-unity", eyebrow: "Project brief", headlineLead: "Start with a" }));
    expect(getContactRoutePresentation("edevops", "fr")).toEqual(expect.objectContaining({ className: "contact-page--route-edevops", eyebrow: "Brief de projet", headlineEmphasis: "brief utile." }));
  });

  it("uses a direct operational EveDev hero statement", () => {
    expect(getDivisionHeroHeadline("edevops", "en")).toBe("Plan the systems that move the work forward.");
    expect(getDivisionHeroHeadline("edevops", "fr")).toBe("Planifiez les systèmes qui font avancer le travail.");
    const eveDevMarkup = renderAt("/edevops", <DivisionPage division="edevops" />);
    expect(eveDevMarkup).toContain("Plan the systems that move the work forward.");
  });

  it("provides a distinct route-aware loader for each public operating territory", () => {
    expect(renderAt("/unity/translation", <RouteLoading />)).toContain("route-loading--unity");
    expect(renderAt("/edevops/web-development", <RouteLoading />)).toContain("route-loading--edevops");
    expect(renderAt("/products", <RouteLoading />)).toContain("route-loading--parent");
    expect(publicStyles).toContain(".route-loading--unity");
    expect(publicStyles).toContain(".route-loading--edevops");
    expect(publicStyles).toContain(".route-loading--parent");
    expect(publicStyles).toContain("@media (prefers-reduced-motion: no-preference)");
  });

  it("publishes the corrected eveOps Group identity and a shareable company-profile download", () => {
    expect(brand.name).toBe("eveOps Group");
    const profileMarkup = renderAt("/", <CompanyProfileDownload />);
    expect(profileMarkup).toContain("/api/public/company-profile.pdf?lang=en");
    expect(profileMarkup).toContain("/api/public/company-profile.pdf?lang=fr");
    expect(profileMarkup).toContain("Download English profile");
    expect(profileMarkup).toContain("Édition française");
  });

  it("gives each company-profile edition a smooth, localized download-handoff state and success notification", () => {
    const profileMarkup = renderAt("/", <CompanyProfileDownload />);
    expect(profileMarkup).toContain("company-profile-download-status");
    expect(profileDownloadSource).toContain("beginDownload");
    expect(profileDownloadSource).toContain("Preparing your profile…");
    expect(profileDownloadSource).toContain("Préparation du profil…");
    expect(profileDownloadSource).toContain("requestCompanyProfile");
    expect(profileDownloadSource).toContain("triggerCompanyProfileDownload");
    expect(profileDownloadSource).toContain("Your English profile is ready to download.");
    expect(profileDownloadSource).toContain("Le profil français est prêt à télécharger.");
    expect(publicStyles).toContain("profile-download-spin");
  });

  it("uses reliable document navigation for language changes and keeps major division content localized", () => {
    expect(shellSource).toContain('<a href={withPublicLocale(currentHref, "en")}');
    expect(shellSource).toContain('<a href={withPublicLocale(currentHref, "fr")}');
    expect(shellSource).not.toContain('<Link href={withPublicLocale(currentHref, "fr")}');
    expect(divisionPageSource).toContain("Écosystème technologique");
    expect(divisionPageSource).toContain("La raison d’être de cette division");
    expect(divisionPageSource).toContain("Apportez la bonne capacité humaine au travail.");
  });

  it("mirrors the recognizable eveOps monogram as requested", () => {
    expect(brandMarkSource).toContain('transform="translate(48 0) scale(-1 1)"');
  });

  it("adds a bilingual homepage quick-contact modal using the existing public lead workflow", () => {
    expect(homepageSource).toContain("<QuickContactModal locale={locale} />");
    expect(quickContactSource).toContain("trpc.leads.submit.useMutation()");
    expect(quickContactSource).toContain('division: "group"');
    expect(quickContactSource).toContain("Talk to eveOps Group");
    expect(quickContactSource).toContain("Parler à eveOps Group");
    expect(quickContactSource).toContain("Thank you for getting in touch.");
    expect(quickContactSource).toContain("Merci de nous avoir écrit.");
    expect(publicStyles).toContain(".quick-contact-modal");
  });
});
