/**
 * Contextual intake: service routes carry the selected capability into a concise, progressive-disclosure brief.
 */
import { useMemo, useState } from "react";
import { CheckCircle2, Send } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { Eyebrow } from "@/components/ContentBlocks";
import { useDocumentMeta } from "@/hooks/useDocumentMeta";
import { trpc } from "@/lib/trpc";
import { getServiceBriefContext } from "@/lib/serviceBrief";
import { localeText } from "@/lib/publicLocale";
import { getContactRoutePresentation } from "@/lib/publicPresentation";

type Intake = "unity" | "edevops";

const unityServices = ["Language Services", "Transcription Services", "Data Annotation & AI Training", "Research & Data Services", "Virtual Workforce", "Content Operations", "Procurement Support"];
const engineeringServices = ["Web Development", "Mobile Development", "Software Engineering", "AI Development", "Automation", "Cloud & DevOps", "Application Security", "API & Integrations"];

export default function ContactPage({ scope = "eveops" }: { scope?: "eveops" | "unity" }) {
  const isUnityScope = scope === "unity";
  const [location] = useLocation();
  const briefContext = useMemo(() => getServiceBriefContext(location.split("?")[1] || window.location.search, isUnityScope), [location, isUnityScope]);
  const initialRoute: Intake = briefContext.route;
  const [route, setRoute] = useState<Intake>(initialRoute);
  const prefilledService = briefContext.service;
  const locale = briefContext.locale;
  const fr = locale === "fr";
  const text = localeText[locale];
  const hasPrefilledService = Boolean(prefilledService) && route === initialRoute;
  const submitLead = trpc.leads.submit.useMutation();
  const serviceOptions = route === "unity" ? unityServices : engineeringServices;
  const routeName = route === "unity" ? "Unity Integrated Solutions" : "EveDev Ops";
  const routePresentation = getContactRoutePresentation(route, locale);

  useDocumentMeta(isUnityScope ? "Contact Unity Integrated Solutions | Request a Service" : "Contact EveOps | Start a Project Conversation", isUnityScope ? "Tell Unity Integrated Solutions about your professional service requirement and start a service intake." : "Tell EveOps whether you need professional services or software development and start a project intake conversation.");

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    try {
      const result = await submitLead.mutateAsync({
        name: String(form.get("name") || ""),
        company: String(form.get("company") || "") || undefined,
        email: String(form.get("email") || ""),
        phone: String(form.get("phone") || "") || undefined,
        country: String(form.get("country") || "") || undefined,
        division: route,
        service: String(form.get("service") || "") || undefined,
        estimatedVolume: String(form.get("volume") || "") || undefined,
        deadline: String(form.get("deadline") || "") || undefined,
        preferredCommunication: String(form.get("communication") || "") || undefined,
        attributionChannel: briefContext.attributionChannel,
        attributedCapability: briefContext.attributedCapability || undefined,
        message: String(form.get("description") || ""),
      });
      event.currentTarget.reset();
      if (result.emailStatus === "sent") toast.success(locale === "fr" ? "Votre brief a bien été reçu." : "Your brief has been received.", { description: locale === "fr" ? "Une notification a été envoyée à l’équipe d’assistance EveOps." : "A notification has been delivered to the EveOps support team." });
      else toast.success(locale === "fr" ? "Votre brief a bien été reçu." : "Your brief has been received.", { description: locale === "fr" ? "Il est enregistré de manière sécurisée dans le tableau de bord Operations pour un suivi." : "It is securely stored in the EveOps operations dashboard for follow-up." });
    } catch (error) {
      toast.error(locale === "fr" ? "Nous n’avons pas pu envoyer le brief." : "We could not submit the brief.", { description: error instanceof Error ? error.message : locale === "fr" ? "Veuillez réessayer ou contacter support@eveopsgroup.com." : "Please try again or contact support@eveopsgroup.com." });
    }
  };

  return <div className={`${isUnityScope ? "contact-page contact-page--unity" : "contact-page"} ${routePresentation.className}`}>
    <section className="contact-hero"><div className="container contact-hero__grid"><div><Eyebrow>{hasPrefilledService ? `${routeName} · ${locale === "fr" ? "brief de service" : "service brief"}` : isUnityScope ? locale === "fr" ? "Demande de service Unity" : "Unity service intake" : routePresentation.eyebrow}</Eyebrow><h1>{hasPrefilledService ? <>{locale === "fr" ? "Parlez-nous de votre besoin en " : "Tell us about your "}<em>{prefilledService}</em>.</> : isUnityScope ? <>{locale === "fr" ? <>Comment Unity peut-elle soutenir le <em>travail&nbsp;?</em></> : <>How can Unity support the <em>work?</em></>}</> : <>{routePresentation.headlineLead} <em>{routePresentation.headlineEmphasis}</em></>}</h1></div><p>{hasPrefilledService ? locale === "fr" ? "Le service est déjà sélectionné. Partagez uniquement le contexte nécessaire pour rendre notre première réponse utile." : "The service is already selected. Share only the context that will help us make the first response useful." : isUnityScope ? locale === "fr" ? "Un premier brief clair reste court : le travail, votre e-mail et le contexte de livraison que vous connaissez déjà." : "A clear first brief is short: the work, your email, and the delivery context you already know." : routePresentation.description}</p>{isUnityScope ? <div className="contact-hero__field-note" aria-hidden="true"><span>{locale === "fr" ? "Note terrain / 01" : "Field note / 01"}</span><i /><small>{locale === "fr" ? "Les briefs utiles commencent par le résultat, non par une spécification parfaite." : "Useful briefs begin with the outcome, not a perfect specification."}</small></div> : <div className="contact-hero__route-rail" aria-hidden="true"><span>01</span><i /><span>02</span><small>{locale === "fr" ? "Point de rencontre" : "Meeting point"}</small></div>}</div></section>
    <section className="contact-intake section-pad"><div className="container contact-intake__grid"><aside className="contact-intake__aside"><p className="contact-intake__label">{isUnityScope ? fr ? "Parcours de travail" : "Working route" : fr ? "Choisissez un parcours" : "Choose a route"}</p><button type="button" className={route === "unity" ? "intake-route intake-route--active intake-route--unity" : "intake-route intake-route--unity"} onClick={() => setRoute("unity")}><span>01</span><strong>{isUnityScope ? fr ? "Brief de service" : "Service brief" : fr ? "Services professionnels" : "Professional services"}</strong><small>Unity Integrated Solutions</small></button>{!isUnityScope && <button type="button" className={route === "edevops" ? "intake-route intake-route--active intake-route--edevops" : "intake-route intake-route--edevops"} onClick={() => setRoute("edevops")}><span>02</span><strong>{fr ? "Développement logiciel" : "Software development"}</strong><small>EveDev Ops</small></button>}<div className="contact-intake__note"><CheckCircle2 size={18} /><p>{fr ? "Trois éléments suffisent pour commencer : votre nom, votre e-mail et une description concise du travail." : "Three essentials are enough to begin: your name, email, and a concise description of the work."}</p></div>{isUnityScope && <div className="unity-contact-details"><span>{fr ? "Échanger avec Unity" : "Speak with Unity"}</span><a href="mailto:support@eveopsgroup.com">support@eveopsgroup.com</a><a href="tel:+237671361513">+237 671 361 513</a></div>}</aside>
      <form className={`intake-form intake-form--${route}`} onSubmit={handleSubmit}>
        <div className="intake-form__heading"><span>{hasPrefilledService ? `${routeName} · ${prefilledService}` : `${routeName} · ${locale === "fr" ? "Premier brief" : "First brief"}`}</span><h2>{hasPrefilledService ? `${text.brief} ${prefilledService}.` : route === "unity" ? locale === "fr" ? "Qu’est-ce qui doit avancer ?" : "What needs to move forward?" : locale === "fr" ? "Qu’est-ce qui doit mieux fonctionner ?" : "What needs to work better?"}</h2><p>{locale === "fr" ? "Les champs obligatoires sont marqués d’un astérisque. Ajoutez les détails de livraison uniquement s’ils sont utiles maintenant." : "Required fields are marked with an asterisk. Add delivery detail only if it is useful now."}</p></div>
        <div className="form-grid form-grid--essential"><label>{locale === "fr" ? "Nom" : "Name"} *<input required name="name" autoComplete="name" placeholder={locale === "fr" ? "Votre nom" : "Your name"} /></label><label>E-mail *<input required type="email" name="email" autoComplete="email" placeholder="name@company.com" /></label></div>
        {hasPrefilledService ? <input type="hidden" name="service" value={prefilledService} /> : <label className="form-service">{route === "unity" ? fr ? "Service souhaité *" : "Service needed *" : fr ? "Que souhaitez-vous construire ? *" : "What are you looking to build? *"}<select required name="service" defaultValue=""><option value="" disabled>{route === "unity" ? fr ? "Sélectionnez un service" : "Select a service" : fr ? "Sélectionnez un domaine de service" : "Select a service area"}</option>{serviceOptions.map(option => <option key={option}>{option}</option>)}</select></label>}
        <label className="form-textarea">{route === "unity" ? fr ? "Que faut-il livrer ? *" : "What needs to be delivered? *" : fr ? "Qu’est-ce qui doit mieux fonctionner ? *" : "What needs to work better? *"}<textarea required name="description" rows={5} placeholder={route === "unity" ? fr ? "Par exemple : le matériel, le périmètre, les langues, le niveau de qualité attendu et le résultat recherché." : "For example: the material, scope, languages, expected quality, and the outcome you need." : fr ? "Par exemple : le processus ou le problème, les personnes concernées et le résultat recherché." : "For example: the workflow or problem, the people involved, and the outcome you need."} /></label>
        <details className="intake-details"><summary>{fr ? "Ajouter des détails de livraison" : "Add delivery details"} <span>{fr ? "Facultatif" : "Optional"}</span></summary><div className="form-grid"><label>{fr ? "Organisation" : "Company"}<input name="company" autoComplete="organization" placeholder={fr ? "Entreprise ou organisation" : "Company or organization"} /></label><label>{fr ? "Téléphone" : "Phone"}<input name="phone" autoComplete="tel" placeholder={fr ? "Indicatif pays et numéro" : "Country code and phone number"} /></label><label>{fr ? "Pays" : "Country"}<input name="country" autoComplete="country-name" placeholder={fr ? "Pays" : "Country"} /></label><label>{fr ? "Volume ou budget estimé" : "Expected volume or budget"}<input name="volume" placeholder={route === "unity" ? fr ? "Fichiers, heures ou volume" : "Files, hours, or volume" : fr ? "Fourchette ou échelle facultative" : "Optional range or scale"} /></label><label>{fr ? "Calendrier idéal" : "Ideal timing"}<input type="date" name="deadline" /></label><label>{fr ? "Mode de communication préféré" : "Preferred communication"}<select name="communication" defaultValue=""><option value="">{fr ? "Aucune préférence" : "No preference"}</option><option>E-mail</option><option>{fr ? "Appel vidéo" : "Video call"}</option><option>{fr ? "Messagerie" : "Messaging"}</option></select></label></div></details>
        <button className="button button--solid" type="submit" disabled={submitLead.isPending}>{submitLead.isPending ? locale === "fr" ? "Envoi du brief…" : "Sending brief…" : locale === "fr" ? "Envoyer le brief" : "Send the brief"} <Send size={16} /></button>
      </form></div></section>
  </div>;
}
