/**
 * Meridian Convergence insights hub: an extendable crawlable foundation for future editorial content.
 */
import { Link } from "wouter";
import { ArrowRight, BookOpenText } from "lucide-react";
import { Eyebrow } from "@/components/ContentBlocks";
import { useDocumentMeta } from "@/hooks/useDocumentMeta";
import { getPublicLocale, withPublicLocale } from "@/lib/publicLocale";

export default function InsightsPage() {
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  const fr = locale === "fr";
  useDocumentMeta(fr ? "Réflexions | EveOps" : "Insights | EveOps", fr ? "Le futur espace éditorial EveOps pour les services professionnels, les données IA, l’ingénierie logicielle, l’automatisation, le cloud et les produits numériques." : "A future-focused EveOps editorial hub for professional services, AI data, software engineering, automation, cloud, and product development insights.");
  return <><section className="insights-hero"><div className="container insights-hero__grid"><div><Eyebrow>{fr ? "Réflexions" : "Insights"}</Eyebrow><h1>{fr ? <>Des réflexions pratiques pour le travail qui relie <em>les personnes et les systèmes.</em></> : <>Practical thinking for work that connects <em>people and systems.</em></>}</h1></div><BookOpenText size={44} /></div></section><section className="insights-empty section-pad"><div className="container insights-empty__grid"><div><span>{fr ? "Fondation éditoriale" : "Editorial foundation"}</span><h2>{fr ? "Un espace prêt pour le SEO et des idées utiles, précises." : "An SEO-ready home for useful, specific ideas."}</h2></div><div><p>{fr ? "Les futurs articles pourront aborder les données IA, l’externalisation, les services linguistiques, les équipes, les achats et la recherche avec Unity, ainsi que l’ingénierie logicielle, l’IA, le SaaS, l’automatisation, le cloud, le DevOps et le développement produit avec EveDev Ops." : "Future articles can cover Unity topics such as AI data, outsourcing, language services, workforce, procurement, and research, alongside EveDev Ops topics such as software engineering, AI, SaaS, automation, cloud, DevOps, and product development."}</p><Link href={withPublicLocale("/contact", locale)} className="arrow-link">{fr ? "Échanger sur une capacité EveOps" : "Discuss an EveOps capability"} <ArrowRight size={17} /></Link></div></div></section></>;
}
