import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowUpRight, FolderKanban, MessageSquareText, ShieldCheck } from "lucide-react";
import { useEffect } from "react";
import { Link, useLocation } from "wouter";

export default function CustomerArea() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  useEffect(() => {
    if (!loading && ["super_admin", "admin"].includes(user?.role || "")) setLocation("/admin");
  }, [loading, setLocation, user]);
  useEffect(() => {
    document.title = "EveOps Customer Workspace";
    let robots = document.querySelector('meta[name="robots"]');
    if (!robots) { robots = document.createElement("meta"); robots.setAttribute("name", "robots"); document.head.appendChild(robots); }
    robots.setAttribute("content", "noindex,nofollow");
    return () => robots?.setAttribute("content", "index,follow");
  }, []);

  if (loading) return <main className="min-h-screen bg-[#f5f3ee] p-6"><div className="mx-auto mt-20 max-w-5xl animate-pulse"><div className="h-6 w-28 bg-[#dce4f8]" /><div className="mt-5 h-12 w-96 bg-[#dce4f8]" /><div className="mt-10 grid gap-4 md:grid-cols-2"><div className="h-40 bg-white" /><div className="h-40 bg-white" /></div></div></main>;
  if (!user) return <main className="min-h-screen bg-[#f5f3ee] grid place-items-center p-6"><section className="max-w-md bg-white p-10 text-center shadow-xl"><ShieldCheck className="mx-auto h-9 w-9 text-[#2765f5]" /><h1 className="mt-4 text-3xl font-bold tracking-[-.04em] text-[#0b1424]">Sign in to view your workspace.</h1><p className="mt-3 text-sm leading-6 text-slate-600">Customer information is only available after secure email-and-password sign-in.</p><Link href="/login?mode=customer" className="mt-7 inline-flex bg-[#0b1424] px-5 py-3 text-xs font-bold text-white hover:bg-[#2765f5]">Customer sign-in</Link></section></main>;
  return <main className="min-h-screen bg-[#f5f3ee] p-6 md:p-10"><header className="mx-auto flex max-w-5xl items-center justify-between border-b border-[#d6dae2] pb-5"><Link href="/" className="text-xs font-extrabold tracking-[.16em] text-[#0b1424]">EVEOPS <span className="font-normal tracking-normal text-slate-500">Customer workspace</span></Link><Link href="/" className="inline-flex items-center gap-2 text-xs font-semibold text-[#0b1424]">Public site <ArrowUpRight size={14} /></Link></header><section className="mx-auto max-w-5xl pt-14"><p className="text-[10px] font-bold uppercase tracking-[.15em] text-[#2765f5]">Private customer area</p><h1 className="mt-3 text-4xl font-bold tracking-[-.05em] text-[#0b1424]">Welcome, {user.name || "there"}.</h1><p className="mt-3 max-w-xl text-sm leading-6 text-slate-600">Your assigned work, requests, documents, and messages will appear here as your EveOps team creates and shares them.</p><div className="mt-9 grid gap-4 md:grid-cols-2"><article className="bg-white p-6 shadow-sm ring-1 ring-[#dce2ec]"><FolderKanban className="h-6 w-6 text-[#2765f5]" /><h2 className="mt-6 text-lg font-semibold text-[#0b1424]">Projects & requests</h2><p className="mt-2 text-sm leading-6 text-slate-600">No projects or service requests have been shared with this account yet.</p></article><article className="bg-white p-6 shadow-sm ring-1 ring-[#dce2ec]"><MessageSquareText className="h-6 w-6 text-[#2765f5]" /><h2 className="mt-6 text-lg font-semibold text-[#0b1424]">Messages & documents</h2><p className="mt-2 text-sm leading-6 text-slate-600">When your delivery team shares an update, it will appear here securely.</p></article></div></section></main>;
}
