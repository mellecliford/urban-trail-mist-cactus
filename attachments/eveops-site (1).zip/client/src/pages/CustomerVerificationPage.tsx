import { CheckCircle2, LoaderCircle, MailWarning } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function CustomerVerificationPage() {
  const [location, setLocation] = useLocation();
  const token = useMemo(() => new URLSearchParams(location.split("?")[1] || window.location.search).get("token") || "", [location]);
  const attempted = useRef(false);
  const [error, setError] = useState("");
  const utils = trpc.useUtils();
  const verify = trpc.customerAuth.verifyEmail.useMutation({ onSuccess: async () => { await utils.auth.me.invalidate(); setLocation("/customer"); }, onError: result => setError(result.message) });
  useEffect(() => { if (token && !attempted.current) { attempted.current = true; verify.mutate({ token }); } }, [token, verify]);
  return <main className="grid min-h-screen place-items-center bg-[#f5f3ee] p-5 text-[#0b1424]"><section className="w-full max-w-lg border border-[#d6dae2] bg-white p-9 shadow-[14px_14px_0_#dce4f8]"><p className="text-[10px] font-bold uppercase tracking-[.15em] text-[#2765f5]">Customer account</p>{!token ? <><MailWarning className="mt-7 h-8 w-8 text-[#2765f5]" /><h1 className="mt-4 text-3xl font-bold tracking-[-.045em]">This confirmation link is incomplete.</h1><p className="mt-3 text-sm leading-6 text-slate-600">Use the full link from your EveOps account email, or contact support if you need help.</p></> : verify.isPending ? <><LoaderCircle className="mt-7 h-8 w-8 animate-spin text-[#2765f5]" /><h1 className="mt-4 text-3xl font-bold tracking-[-.045em]">Confirming your email…</h1><p className="mt-3 text-sm leading-6 text-slate-600">Please wait while we activate your customer workspace.</p></> : error ? <><MailWarning className="mt-7 h-8 w-8 text-[#b95c3d]" /><h1 className="mt-4 text-3xl font-bold tracking-[-.045em]">We could not confirm this email.</h1><p className="mt-3 text-sm leading-6 text-slate-600">{error}</p><Link href="/login?mode=customer" className="mt-7 inline-flex bg-[#0b1424] px-4 py-3 text-xs font-bold text-white">Return to customer sign-in</Link></> : <><CheckCircle2 className="mt-7 h-8 w-8 text-[#2765f5]" /><h1 className="mt-4 text-3xl font-bold tracking-[-.045em]">Your email is confirmed.</h1><p className="mt-3 text-sm leading-6 text-slate-600">Taking you to your customer workspace now.</p></>}</section></main>;
}
