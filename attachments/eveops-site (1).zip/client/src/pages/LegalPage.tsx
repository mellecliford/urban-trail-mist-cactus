/**
 * Meridian Convergence legal placeholder: clearly scoped content space for future policy text without invented terms.
 */
import { Eyebrow } from "@/components/ContentBlocks";
import { useDocumentMeta } from "@/hooks/useDocumentMeta";
import { getPublicLocale } from "@/lib/publicLocale";

export default function LegalPage({ type }: { type: "privacy" | "terms" }) {
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  const fr = locale === "fr";
  const title = type === "privacy" ? fr ? "Confidentialité" : "Privacy" : fr ? "Conditions" : "Terms";
  useDocumentMeta(`${title} | eveOps Group`, fr ? `Informations relatives à ${title.toLowerCase()} pour eveOps Group.` : `${title} information for eveOps Group.`);
  return <section className="simple-page section-pad"><div className="container simple-page__content"><Eyebrow>{title}</Eyebrow><h1>{fr ? `Les informations ${type === "privacy" ? "de confidentialité" : "relatives aux conditions"} seront publiées ici.` : `${title} information will be published here.`}</h1><p>{fr ? `Cette page est réservée à la ${type === "privacy" ? "politique de confidentialité" : "version formelle des conditions d’utilisation"} d’eveOps Group. Le site actuel n’invente pas de conditions juridiques ni de pratiques de collecte qui n’ont pas été fournies.` : `This page is reserved for eveOps Group’s formal ${type === "privacy" ? "privacy policy" : "terms of use"}. The current site does not invent legal terms or collection practices that have not been provided.`}</p></div></section>;
}
