/**
 * Meridian Convergence products page: owned products are visually and semantically separate from client solutions.
 */
import { Link } from "wouter";
import { ArrowRight, ArrowUpRight, Orbit } from "lucide-react";
import { products } from "@/content/site";
import { Eyebrow } from "@/components/ContentBlocks";
import { useDocumentMeta } from "@/hooks/useDocumentMeta";
import { getPublicLocale, withPublicLocale } from "@/lib/publicLocale";

export default function ProductsPage() {
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  const fr = locale === "fr";
  useDocumentMeta(fr ? "Produits par EveOps | Shweng et futurs produits numériques" : "Products by EveOps | Shweng & Future Digital Products", fr ? "Découvrez les produits développés et opérés par EveOps, dont Shweng, une application d’échange inter-réseaux en cours de développement." : "Explore products built and operated by EveOps, including Shweng, a cross-network exchange application in development.");
  return (
    <>
      <section className="products-hero"><div className="container products-hero__grid"><div><Eyebrow>{fr ? "Produits par EveOps" : "Products by EveOps"}</Eyebrow><h1>{fr ? <>La technologie que nous créons pour le <em>marché.</em></> : <>Technology we build for the <em>market.</em></>}</h1><p>{fr ? "Notre portefeuille de produits est distinct des solutions clients. Il rassemble les logiciels qu’EveOps construit, développe ou opère comme activité produit." : "Our product portfolio is distinct from client solutions. It is the place for software EveOps builds, develops, or operates as a product business."}</p></div><div className="products-hero__orbit"><Orbit size={34} /><span>{fr ? <>Écosystème<br />produit</> : <>Product<br />ecosystem</>}</span></div></div></section>
      <section className="products-list section-pad"><div className="container"><div className="products-list__lead"><span>{fr ? "Produit actuel" : "Current product"}</span><p>{fr ? "Les informations restent volontairement synthétiques tant que le travail est en cours." : "Product information is kept intentionally high-level while work is in progress."}</p></div>{products.map((product, index) => <article className="product-row" key={product.slug}><div className="product-row__index">0{index + 1}</div><div><span className="product-row__status">{fr && product.status === "In development" ? "En développement" : product.status}</span><h2>{product.name}</h2><p className="product-row__category">{fr && product.slug === "shweng" ? "Échange inter-réseaux" : product.category}</p></div><p className="product-row__description">{fr && product.slug === "shweng" ? "Une application d’échange de valeur inter-réseaux actuellement développée par EveDev Ops. Les informations produit évolueront avec le travail vérifié." : product.description}</p><Link href={withPublicLocale(`/products/${product.slug}`, locale)} className="round-arrow" aria-label={`View ${product.name}`}><ArrowUpRight size={20} /></Link></article>)}</div></section>
      <section className="products-note"><div className="container products-note__grid"><p className="products-note__label">{fr ? "Solutions clients" : "Client solutions"}</p><p>{fr ? "Vous avez besoin d’un système numérique pour votre organisation plutôt que d’un produit détenu par EveOps ? Ce travail est présenté séparément comme solution client via EveDev Ops." : "Need a digital system developed for your organization rather than an EveOps-owned product? That work is presented separately as a client solution through EveDev Ops."}</p><Link href={withPublicLocale("/portfolio", locale)}>{fr ? "Voir les réalisations" : "View the portfolio"} <ArrowRight size={17} /></Link></div></section>
    </>
  );
}
