/**
 * Meridian Convergence homepage: an SEO-readable, split-world gateway that never blocks direct division navigation.
 */
import { Link } from "wouter";
import { ArrowRight, ArrowUpRight, ChevronDown, Network, Sparkles, UsersRound } from "lucide-react";
import { assets, divisions } from "@/content/site";
import { ArrowLink, Eyebrow, SectionHeading } from "@/components/ContentBlocks";
import { CompanyProfileDownload } from "@/components/CompanyProfileDownload";
import { QuickContactModal } from "@/components/QuickContactModal";
import { useDocumentMeta } from "@/hooks/useDocumentMeta";
import { getPublicLocale, withPublicLocale } from "@/lib/publicLocale";

export default function Home() {
  const locale = typeof window === "undefined" ? "en" : getPublicLocale(window.location.search);
  const fr = locale === "fr";
  useDocumentMeta(fr ? "eveOps Group | Services professionnels, logiciels et solutions IA" : "eveOps Group | Professional Services, Software & AI Solutions", fr ? "eveOps Group combine solutions de main-d’œuvre, services de données IA, achats et ingénierie logicielle par l’intermédiaire de Unity Integrated Solutions et EveDev Ops." : "eveOps Group combines professional workforce solutions, AI data services, procurement support, and software engineering through Unity Integrated Solutions and EveDev Ops.");

  return (
    <>
      <section className="home-hero" style={{ backgroundImage: `url(${assets.parentHero})` }}>
        <div className="home-hero__veil" />
        <div className="container home-hero__content">
          <div className="home-hero__intro">
            <Eyebrow>{fr ? "Des capacités indépendantes conçues pour travailler ensemble" : "Independent capabilities, designed to work together"}</Eyebrow>
            <h1>{fr ? <>Un groupe.<br /><em>Deux façons</em> de construire la suite.</> : <>One group.<br /><em>Two ways</em> to build what’s next.</>}</h1>
            <p>{fr ? "eveOps Group relie des solutions professionnelles de main-d’œuvre internationale à l’ingénierie logicielle, l’IA et la création de produits numériques." : "eveOps Group connects professional global workforce solutions with software engineering, AI, and digital product development."}</p>
            <QuickContactModal locale={locale} />
          </div>
          <div className="home-hero__anchor" aria-hidden="true">
            <span>01</span>
            <i />
            <span>02</span>
          </div>
          <a className="home-hero__scroll" href="#divisions"><span>{fr ? "Explorer les divisions" : "Explore divisions"}</span><ChevronDown size={16} /></a>
        </div>
      </section>

      <section id="divisions" className="division-gateway">
        <div className="division-gateway__heading container">
          <Eyebrow>{fr ? "Choisissez votre parcours" : "Choose your route"}</Eyebrow>
          <p>{fr ? "Deux modèles opérationnels distincts. Une même organisation, conçue pour les entreprises qui ont besoin d’expertise humaine, de systèmes conçus sur mesure, ou des deux." : "Two distinct operating models. One parent company built for organizations that need human expertise, engineered systems, or both."}</p>
        </div>
        <div className="division-gateway__cards">
          <Link href={withPublicLocale("/unity", locale)} className="division-panel division-panel--unity">
            <div className="division-panel__image" style={{ backgroundImage: `url(${assets.unity})` }} />
            <div className="division-panel__shade" />
            <div className="division-panel__content">
              <span className="division-panel__index">{fr ? "01 — Équipes et opérations" : "01 — People & operations"}</span>
              <h2>Unity<br /><em>Integrated Solutions</em></h2>
              <p>{fr ? "Services professionnels coordonnés" : divisions.unity.eyebrow}</p>
              <span className="division-panel__keywords">{fr ? "Traduction · données IA · recherche · annotation · achats · équipes" : "Translation · AI data · research · annotation · procurement · workforce"}</span>
              <span className="division-panel__cta">{fr ? "Explorer Unity" : "Explore Unity"} <ArrowUpRight size={18} /></span>
            </div>
          </Link>
          <Link href={withPublicLocale("/edevops", locale)} className="division-panel division-panel--edevops">
            <div className="division-panel__image" style={{ backgroundImage: `url(${assets.edevops})` }} />
            <div className="division-panel__shade" />
            <div className="division-panel__content">
              <span className="division-panel__index">{fr ? "02 — Systèmes et produits" : "02 — Systems & products"}</span>
              <h2>EveDev<br /><em>Ops</em></h2>
              <p>{fr ? "Ingénierie logicielle · IA · produits numériques" : divisions.edevops.eyebrow}</p>
              <span className="division-panel__keywords">{fr ? "Logiciel · IA · SaaS · mobile · automatisation · cloud · DevOps" : "Software · AI · SaaS · mobile · automation · cloud · DevOps"}</span>
              <span className="division-panel__cta">{fr ? "Explorer EveDev Ops" : "Explore EveDev Ops"} <ArrowUpRight size={18} /></span>
            </div>
          </Link>
        </div>
      </section>

      <section className="parent-intro section-pad">
        <div className="container parent-intro__grid">
          <div className="parent-intro__rail"><span>Group</span><i /></div>
          <div>
            <SectionHeading eyebrow={fr ? "Qu’est-ce qu’eveOps Group ?" : "What is eveOps Group?"} title={fr ? <>Un partenaire opérationnel pour <em>un travail exigeant.</em></> : <>An operating partner for <em>serious work.</em></>} description={fr ? "eveOps Group est un groupe pluridisciplinaire qui réunit expertise professionnelle, ingénierie logicielle et innovation numérique. Notre structure par division facilite l’accès à la bonne capacité pour le bon enjeu opérationnel." : "eveOps Group is a multidisciplinary group combining professional human expertise with software engineering and digital innovation. Our division structure makes it easier to bring the right capability to the right operating problem."} />
          </div>
          <div className="parent-intro__capabilities">
            <article>
              <div className="parent-intro__icon"><UsersRound size={21} /></div>
              <p className="parent-intro__type">{fr ? "Services professionnels" : "Professional services"}</p>
              <h3>{fr ? "Une expertise humaine structurée pour la livraison." : "Human expertise, structured for delivery."}</h3>
              <p>{fr ? "Unity Integrated Solutions propose un soutien professionnel pour les données IA, les services linguistiques, la recherche, la transcription, les achats et les opérations métiers." : "Unity Integrated Solutions provides professional workforce support across AI data, language services, research, transcription, procurement, and business operations."}</p>
              <ArrowLink href={withPublicLocale("/unity", locale)}>{fr ? "Explorer Unity Integrated Solutions" : "Explore Unity Integrated Solutions"}</ArrowLink>
            </article>
            <article>
              <div className="parent-intro__icon parent-intro__icon--tech"><Network size={21} /></div>
              <p className="parent-intro__type">{fr ? "Technologie et logiciel" : "Technology & software"}</p>
              <h3>{fr ? "Des systèmes numériques conçus pour faire avancer le travail." : "Digital systems designed to move the work forward."}</h3>
              <p>{fr ? "EveDev Ops conçoit et construit des sites web, applications mobiles, plateformes SaaS, API, systèmes d’IA, solutions d’automatisation, infrastructures cloud et produits numériques." : "EveDev Ops designs and builds websites, mobile applications, SaaS platforms, APIs, AI systems, automation solutions, cloud infrastructure, and digital products."}</p>
              <ArrowLink href={withPublicLocale("/edevops", locale)}>{fr ? "Explorer EveDev Ops" : "Explore EveDev Ops"}</ArrowLink>
            </article>
          </div>
        </div>
      </section>

      <section className="connection-band">
        <div className="container connection-band__grid">
          <div className="connection-band__marker"><Sparkles size={22} /><span>{fr ? "Au point de rencontre" : "At the seam"}</span></div>
          <div><p className="connection-band__large">{fr ? <>Les meilleures solutions ont souvent besoin d’une équipe compétente <em>et</em> d’un système capable.</> : <>The best solutions often need both a capable team <em>and</em> a capable system.</>}</p></div>
          <div><p>{fr ? "La structure du groupe ouvre un parcours clair vers chaque division tout en laissant les services professionnels et la technologie se soutenir lorsque le projet l’exige." : "Our group structure creates a clear route into each division while leaving room for professional services and technology work to support one another when a project calls for it."}</p><ArrowLink href={withPublicLocale("/about", locale)} dark>{fr ? "Comment EveOps est organisé" : "How EveOps is organized"}</ArrowLink></div>
        </div>
      </section>

      <CompanyProfileDownload />

      <section className="section-pad parent-products">
        <div className="container parent-products__grid">
          <div>
            <Eyebrow>{fr ? "Produits par EveOps" : "Products by EveOps"}</Eyebrow>
            <h2>{fr ? "Conçus pour le marché, pas seulement pour un brief client." : "Built for the market, not just a client brief."}</h2>
          </div>
          <div className="product-preview">
            <div><span className="product-preview__status">{fr ? "En développement" : "In development"}</span><p className="product-preview__name">Shweng</p><p>{fr ? "Une infrastructure d’échange inter-réseaux actuellement développée par EveDev Ops." : "Cross-network exchange infrastructure currently being developed by EveDev Ops."}</p></div>
            <Link href={withPublicLocale("/products/shweng", locale)} className="round-arrow" aria-label="View Shweng"><ArrowUpRight size={20} /></Link>
          </div>
          <div className="parent-products__link"><Link href={withPublicLocale("/products", locale)}>{fr ? "Voir les produits" : "View products"} <ArrowRight size={16} /></Link></div>
        </div>
      </section>
    </>
  );
}
