import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const pageSource = readFileSync(new URL("./ServiceDetailPage.tsx", import.meta.url), "utf8");
const stylesheet = readFileSync(new URL("../index.css", import.meta.url), "utf8");

describe("all-service capability conversion journey", () => {
  it("renders explanatory content and an exact direct-brief CTA from the shared capability route", () => {
    expect(pageSource).toContain("capability.description");
    expect(pageSource).toContain("capability.detail");
    expect(pageSource).toContain("getServiceCapabilityBriefHref");
    expect(pageSource).toContain('trackCapability(capability, "brief_opened")');
    expect(pageSource).toContain("capability-accordion__open-label");
    expect(pageSource).toContain("Context & direct brief");
    expect(pageSource).toContain("open className=\"capability-accordion__item\"");
  });

  it("keeps explanatory capability content and the direct-brief affordance legible at the mobile breakpoint", () => {
    expect(stylesheet).toContain("@media (max-width: 760px) { .service-scope__hint");
    expect(stylesheet).toContain(".capability-accordion__heading > small");
    expect(stylesheet).toContain(".capability-accordion__open-label");
    expect(stylesheet).toContain(".capability-accordion__cta, .capability-accordion__template");
  });
});
