# Detailed Company Profile Review Notes

## English opening pages

The live English attachment was reviewed after the expanded thirteen-page generator was introduced. The cover now identifies the document as a **Detailed Company Profile**, explicitly distinguishes it from a project brief, presents Unity Integrated Solutions and EveDev Ops as distinct practices, and carries the inverted eveOps Group monogram.

The initial group page was reviewed twice. Its first layout revealed that a longer capability title could approach the explanatory copy column. The row grid was adjusted to introduce a clear column gap and to calculate vertical row height against the narrower explanatory column. The regenerated page now has readable separation across all four group rows, with no title/body collision.

## Verification boundary

Both live attachment endpoints regenerated successfully and report **13 pages** by PDF inspection. Further visual review will focus on long French content pages and the final contact page, where copy density is highest.

## French dense-content pages

The French detailed profile was visually reviewed across pages 4 to 8, covering the language-services, AI-data, content-and-procurement, digital-systems, and products-and-platforms sections. These pages carry the longest localized explanatory copy and remained readable after the row-grid adjustment. Titles, explanatory paragraphs, section kickers, and closing callouts stayed within their intended columns without visible overlap.

The review confirms that the French edition now behaves like a real reader-facing corporate document rather than a sparse brief: each section explains the practical role of the service area, the operating context that shapes the work, and the type of outcome the reader should expect from the engagement.

## French closing pages

Pages 9 to 13 of the French attachment were also reviewed visually. The applied-AI, cloud-and-integration, cross-division, method, and final contact pages all remained legible at the current density. The final contact page correctly presents a reader-facing closing section rather than a short brief, with a substantial introduction, a highlighted starting-point panel, four explanatory rows, and the localized contact route.

Across the full sampled review, the French document now supports the user’s stated goal more closely: the PDF contains materially more explanatory information than the site and reads as a shareable company profile instead of a minimal leave-behind sheet.

## Public language-switch verification

The reported translation defect was reproduced: the prior client-side query-string navigation updated the address bar to `?lang=fr` while leaving the already-rendered English page in place. The language control now uses standard document links for language changes. A live browser click from the English homepage to **FR** reloaded the route and rendered the French homepage, including French navigation, hero, section content, PDF controls, and locale-preserving division links.

The Unity landing page was then checked in French and English. It retains its Compass Fold visual system and its `You are at` orientation cue, while a dedicated contextual route bar now offers direct links to **EveDev Ops** and **eveOps Group home**. The French Unity content rendered in French, and a visible English language-control click reloaded the same Unity page back to English without losing either route.

The Unity-to-EveDev Ops route was also activated from the new Unity switch. On EveDev Ops, a visible **FR** language-control click reloaded the page at `?lang=fr` and rendered the French header, route bar, hero, service cards, technology section, positioning copy, and calls to action. This verifies the repaired full-reload language path on both division families.

## Inverted eveOps Group mark

The updated mirrored monogram was checked in the public header at both a 1280px desktop viewport and a 375px mobile viewport. It remains crisp, recognizable, visually balanced with the `eveOps Group` wordmark on desktop, and readable beside the compact mobile language control. No separate raster logo asset or fragile external image path is used for this public identity.

An additional live browser-header inspection on the public homepage confirmed the rendered inverted mark at the left of the desktop navigation: its opposing blue/navy chevrons remain visually clear, the central cyan detail is present, and the mark retains a readable spatial relationship with the `eveOps Group` wordmark. The companion mobile viewport review confirmed the same treatment remains legible in the condensed header.

The final live browser-view capture shows the monogram rendered directly in the public header (rather than inferred from source code): the blue forward chevron and dark opposing chevron are visibly mirrored from the prior orientation, with the cyan inner accent remaining distinct. The separately captured 375px viewport maintains that same visible mark and keeps it clear of the EN/FR and menu controls.
