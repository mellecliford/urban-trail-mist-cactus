ALTER TABLE `leads` ADD `attributionChannel` enum('direct','capability_cta') DEFAULT 'direct' NOT NULL;--> statement-breakpoint
ALTER TABLE `leads` ADD `attributedCapability` varchar(160);--> statement-breakpoint
CREATE INDEX `leads_attribution_idx` ON `leads` (`division`,`service`,`attributedCapability`);