CREATE TABLE `administratorSecurity` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`encryptedTotpSecret` text,
	`totpEnabled` boolean NOT NULL DEFAULT false,
	`recoveryCodeHashes` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `administratorSecurity_id` PRIMARY KEY(`id`),
	CONSTRAINT `administratorSecurity_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `passwordAccounts` ADD `passwordResetTokenHash` varchar(128);--> statement-breakpoint
ALTER TABLE `passwordAccounts` ADD `passwordResetExpiresAt` timestamp;--> statement-breakpoint
ALTER TABLE `administratorSecurity` ADD CONSTRAINT `administratorSecurity_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;