import { boolean, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core identity records. Authorization derives from these server-side roles; no role is accepted from the browser.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "super_admin", "admin", "manager", "staff", "customer"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/**
 * Email/password credentials are separate from OAuth identity records. Passwords are stored only as salted hashes;
 * verification tokens are stored only as hashes and never returned through the API.
 */
export const passwordAccounts = mysqlTable("passwordAccounts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  emailVerified: boolean("emailVerified").default(false).notNull(),
  verificationTokenHash: varchar("verificationTokenHash", { length: 128 }),
  verificationExpiresAt: timestamp("verificationExpiresAt"),
  passwordResetTokenHash: varchar("passwordResetTokenHash", { length: 128 }),
  passwordResetExpiresAt: timestamp("passwordResetExpiresAt"),
  lastPasswordLoginAt: timestamp("lastPasswordLoginAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("password_accounts_verified_idx").on(table.emailVerified)]);

/** Optional administrator-only TOTP protection. Secrets are encrypted with the server key and never returned after enrollment. */
export const administratorSecurity = mysqlTable("administratorSecurity", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  encryptedTotpSecret: text("encryptedTotpSecret"),
  totpEnabled: boolean("totpEnabled").default(false).notNull(),
  recoveryCodeHashes: text("recoveryCodeHashes"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").unique().references(() => users.id, { onDelete: "set null" }),
  name: varchar("name", { length: 160 }).notNull(),
  company: varchar("company", { length: 200 }),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  country: varchar("country", { length: 100 }),
  status: mysqlEnum("status", ["active", "disabled", "invited"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("customers_email_idx").on(table.email)]);

export const leads = mysqlTable("leads", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  company: varchar("company", { length: 200 }),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  country: varchar("country", { length: 100 }),
  division: mysqlEnum("division", ["unity", "edevops", "group"]).default("unity").notNull(),
  service: varchar("service", { length: 160 }),
  estimatedVolume: varchar("estimatedVolume", { length: 160 }),
  deadline: varchar("deadline", { length: 32 }),
  preferredCommunication: varchar("preferredCommunication", { length: 80 }),
  message: text("message").notNull(),
  source: mysqlEnum("source", ["public_form", "admin", "customer_portal", "product", "quote"]).default("public_form").notNull(),
  attributionChannel: mysqlEnum("attributionChannel", ["direct", "capability_cta"]).default("direct").notNull(),
  attributedCapability: varchar("attributedCapability", { length: 160 }),
  status: mysqlEnum("status", ["new", "read", "contacted", "qualified", "proposal_sent", "negotiation", "won", "lost", "archived"]).default("new").notNull(),
  priority: mysqlEnum("priority", ["low", "normal", "high", "urgent"]).default("normal").notNull(),
  assignedUserId: int("assignedUserId").references(() => users.id, { onDelete: "set null" }),
  lastContactedAt: timestamp("lastContactedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("leads_division_status_idx").on(table.division, table.status), index("leads_email_idx").on(table.email), index("leads_attribution_idx").on(table.division, table.service, table.attributedCapability)]);

export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  customerId: int("customerId").references(() => customers.id, { onDelete: "restrict" }),
  leadId: int("leadId").references(() => leads.id, { onDelete: "set null" }),
  division: mysqlEnum("division", ["unity", "edevops"]).notNull(),
  service: varchar("service", { length: 160 }),
  description: text("description"),
  status: mysqlEnum("status", ["planning", "submitted", "reviewing", "active", "awaiting_client", "qa", "completed", "cancelled"]).default("planning").notNull(),
  priority: mysqlEnum("priority", ["low", "normal", "high", "urgent"]).default("normal").notNull(),
  assignedUserId: int("assignedUserId").references(() => users.id, { onDelete: "set null" }),
  startDate: timestamp("startDate"),
  targetDate: timestamp("targetDate"),
  completedAt: timestamp("completedAt"),
  budget: varchar("budget", { length: 80 }),
  internalNotes: text("internalNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("projects_customer_status_idx").on(table.customerId, table.status)]);

export const serviceRequests = mysqlTable("serviceRequests", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").references(() => customers.id, { onDelete: "restrict" }),
  leadId: int("leadId").references(() => leads.id, { onDelete: "set null" }),
  division: mysqlEnum("division", ["unity", "edevops"]).notNull(),
  service: varchar("service", { length: 160 }).notNull(),
  description: text("description").notNull(),
  status: mysqlEnum("status", ["submitted", "reviewing", "in_progress", "completed", "cancelled"]).default("submitted").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Credentials are encrypted before persistence. The API deliberately never returns encryptedPassword to the browser.
 */
export const emailSettings = mysqlTable("emailSettings", {
  id: int("id").autoincrement().primaryKey(),
  provider: mysqlEnum("provider", ["smtp", "resend"]).default("smtp").notNull(),
  smtpHost: varchar("smtpHost", { length: 255 }),
  smtpPort: int("smtpPort"),
  smtpUsername: varchar("smtpUsername", { length: 320 }),
  encryptedPassword: text("encryptedPassword"),
  secure: boolean("secure").default(true).notNull(),
  fromName: varchar("fromName", { length: 120 }).default("EveOps Website"),
  fromEmail: varchar("fromEmail", { length: 320 }),
  replyTo: varchar("replyTo", { length: 320 }).default("support@eveopsgroup.com"),
  isEnabled: boolean("isEnabled").default(false).notNull(),
  updatedByUserId: int("updatedByUserId").references(() => users.id, { onDelete: "set null" }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const emailLogs = mysqlTable("emailLogs", {
  id: int("id").autoincrement().primaryKey(),
  recipient: varchar("recipient", { length: 320 }).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["queued", "sent", "failed"]).default("queued").notNull(),
  errorMessage: text("errorMessage"),
  leadId: int("leadId").references(() => leads.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  sentAt: timestamp("sentAt"),
}, (table) => [index("email_logs_status_idx").on(table.status, table.createdAt)]);

export const auditLogs = mysqlTable("auditLogs", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actorUserId").references(() => users.id, { onDelete: "set null" }),
  action: varchar("action", { length: 160 }).notNull(),
  targetType: varchar("targetType", { length: 100 }).notNull(),
  targetId: varchar("targetId", { length: 100 }),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("audit_logs_target_idx").on(table.targetType, table.targetId)]);

export const systemSettings = mysqlTable("systemSettings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 120 }).notNull(),
  value: text("value"),
  updatedByUserId: int("updatedByUserId").references(() => users.id, { onDelete: "set null" }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("system_settings_key_idx").on(table.key)]);

/** Public marketing assets only. Private customer documents remain intentionally disabled until signed, authorization-checked delivery is implemented. */
export const media = mysqlTable("media", {
  id: int("id").autoincrement().primaryKey(),
  filename: varchar("filename", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 600 }).notNull().unique(),
  url: varchar("url", { length: 700 }).notNull(),
  contentType: varchar("contentType", { length: 160 }).notNull(),
  byteSize: int("byteSize").notNull(),
  uploadedByUserId: int("uploadedByUserId").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("media_created_idx").on(table.createdAt)]);

/** Anonymous public conversion events. No email, IP address, or visitor fingerprint is persisted. */
export const capabilityEvents = mysqlTable("capabilityEvents", {
  id: int("id").autoincrement().primaryKey(),
  division: mysqlEnum("division", ["unity", "edevops"]).notNull(),
  service: varchar("service", { length: 160 }).notNull(),
  capability: varchar("capability", { length: 160 }).notNull(),
  eventType: mysqlEnum("eventType", ["brief_opened", "template_downloaded"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("capability_events_created_idx").on(table.createdAt), index("capability_events_route_idx").on(table.division, table.service, table.capability)]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type EmailSettings = typeof emailSettings.$inferSelect;
export type PasswordAccount = typeof passwordAccounts.$inferSelect;
