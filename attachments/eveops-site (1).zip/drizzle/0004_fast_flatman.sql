CREATE TABLE `capabilityEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`division` enum('unity','edevops') NOT NULL,
	`service` varchar(160) NOT NULL,
	`capability` varchar(160) NOT NULL,
	`eventType` enum('brief_opened','template_downloaded') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `capabilityEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `capability_events_created_idx` ON `capabilityEvents` (`createdAt`);--> statement-breakpoint
CREATE INDEX `capability_events_route_idx` ON `capabilityEvents` (`division`,`service`,`capability`);