CREATE TABLE `passwordAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`email` varchar(320) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`emailVerified` boolean NOT NULL DEFAULT false,
	`verificationTokenHash` varchar(128),
	`verificationExpiresAt` timestamp,
	`lastPasswordLoginAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `passwordAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `passwordAccounts_userId_unique` UNIQUE(`userId`),
	CONSTRAINT `passwordAccounts_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
ALTER TABLE `passwordAccounts` ADD CONSTRAINT `passwordAccounts_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `password_accounts_verified_idx` ON `passwordAccounts` (`emailVerified`);